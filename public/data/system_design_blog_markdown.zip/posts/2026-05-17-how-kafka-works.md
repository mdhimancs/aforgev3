---
title: "How Kafka Works?"
date: "2026-05-17T10:59:43+05:30"
slug: "how-kafka-works"
categories: ["system_design", "architecture", "kafka", "technology"]
original_url: "https://rishijeet.github.io/blog/how-kafka-works/"
word_count: 5843
reading_time: "29 min"
author: "Rishijeet Mishra"
---

# How Kafka Works?

*Published on 2026-05-17 by Rishijeet Mishra | [https://rishijeet.github.io/blog/how-kafka-works/](https://rishijeet.github.io/blog/how-kafka-works/)*

> There is a moment in every backend engineer's career when a simple queue stops being enough. Maybe you're logging user activity to a database and the writes start choking the system. Maybe you're moving data between microservices with REST calls and latency starts creeping up. Maybe a product team asks for &ldquo;real-time analytics&rdquo; and you start wondering what that even means at scale.

![Alt text](https://rishijeet.github.io/images/system_design/kafka.avif)

That's when engineers usually discover Kafka.

Apache Kafka was originally built at LinkedIn to solve a very unglamorous problem: moving enormous amounts of log data between systems without breaking everything. What they ended up building wasn't just a message queue. It was a distributed commit log, a unified event backbone, and arguably one of the most influential pieces of infrastructure in modern software engineering.

But here's the thing nobody tells beginners: distributed messaging is genuinely hard. Not hard like &ldquo;this will take an afternoon.&rdquo; Hard like &ldquo;this is a decade of systems research made practical.&rdquo;

Think about what you're actually trying to do when you build a distributed messaging system. You want to accept millions of messages per second from producers that don't know or care about consumers. You want to store those messages durably on disk so nothing gets lost even if half your servers crash. You want to replay old messages if a consumer fails and needs to reprocess. You want ordering guarantees for related events. You want to fan out a single message to dozens of different consumers. You want horizontal scalability so you can throw more hardware at the problem as traffic grows. And you want to do all of this with single-digit millisecond latency.

Every one of those goals pulls in a different direction from the others. Durability requires writing to disk, which is slower. Ordering across multiple consumers requires coordination, which adds latency. Replication for fault tolerance means you're doing more network I/O. Horizontal scalability means you now have a distributed system, which means you need to think about split-brain scenarios, network partitions, and leader elections.

Kafka navigated these tradeoffs in a set of architectural decisions that, looking back, feel almost obvious in their elegance. Almost.

This blog walks through how Kafka actually works, from the high-level concept of a distributed log to the low-level details of how bytes move off disk and across a network. By the end, you should understand not just what Kafka does, but why it was designed the way it is.

## Core Features of Kafka

Before going deep, it helps to have a clear picture of what Kafka's fundamental primitives actually are.

A topic is the basic unit of organization. Think of it as a named feed or channel. You might have a topic called , another called , another called . Producers write to topics. Consumers read from topics. Topics are how you separate different streams of events.

A producer is any client that writes messages to a topic. Producers don't decide which consumer gets their messages. They just send messages and Kafka handles the rest. This decoupling is one of Kafka's most powerful design choices.

A consumer is any client that reads from a topic. Consumers track their own position in the log using something called an offset, which is just a sequential integer. Consumer A and Consumer B can both read the same topic and maintain completely independent positions. One might be at offset 1000, the other at offset 50. Neither one affects the other.

A partition is how Kafka splits a topic across multiple servers. A topic with a single partition is a single ordered log. A topic with ten partitions is ten independent ordered logs, spread across brokers. Partitions are the fundamental unit of parallelism in Kafka.

A consumer group is how you build parallel consumption. Multiple consumers in a group divide up the partitions of a topic. One consumer might handle partitions 0 through 3, another handles 4 through 7. Together they process the whole topic faster than any single consumer could.

Replication means each partition has multiple copies stored on different brokers. If the broker holding the primary copy crashes, another broker that holds a replica can take over. This is Kafka's primary mechanism for fault tolerance.

Retention controls how long messages are kept on disk. Kafka doesn't delete messages the moment a consumer reads them. Messages stay around for a configured period (often 7 days), which means consumers can replay old events, new consumers can catch up from the beginning, and teams can reprocess data after a bug fix.

Stream processing in Kafka refers to the Kafka Streams API and the ecosystem around it, which lets you build stateful, real-time processing pipelines that consume from topics, transform or aggregate data, and write results back to topics.

Also read [Advanced Apache Kafka Anatomy](/blog/advanced-apache-kafka-anatomy-delving-deep-into-the-core-components/) for fundamental concepts.

## High-Level Kafka Architecture

A Kafka cluster looks deceptively simple from the outside. Producers send messages in. Consumers read messages out. Between them sit brokers that store and serve the data.

flowchart TD;
P1[Producer App 1];
P2[Producer App 2];
P3[Producer App 3];
B1[Broker 1];
B2[Broker 2];
B3[Broker 3];
ZK[ZooKeeper or KRaft Controller];
CG1[Consumer Group A];
CG2[Consumer Group B];
P1 &#8211;> B1;
P2 &#8211;> B2;
P3 &#8211;> B3;
B1 &#8211;> ZK;
B2 &#8211;> ZK;
B3 &#8211;> ZK;
B1 &#8211;> CG1;
B2 &#8211;> CG1;
B3 &#8211;> CG1;
B1 &#8211;> CG2;
B2 &#8211;> CG2;
B3 &#8211;> CG2;

Each broker in the cluster is responsible for a subset of partitions. For any given partition, one broker is designated the leader and handles all reads and writes for that partition. The other brokers that hold replicas of that partition are followers.

Historically, Kafka used Apache ZooKeeper as its metadata coordination layer. ZooKeeper tracked which brokers were alive, which broker was the leader for which partition, and stored configuration information. More recently, Kafka introduced KRaft mode, which replaces ZooKeeper with a consensus protocol built directly into Kafka using Raft. This simplifies operations significantly.

The message lifecycle looks like this: A producer connects to any broker (called a bootstrap broker), fetches cluster metadata to learn which broker is the leader for its target partition, then sends messages directly to that leader. The leader writes the messages to its local log, and followers fetch those messages asynchronously. Once enough replicas have confirmed they've stored the message (based on the configured acknowledgment level), the producer gets a success response. Consumers connect to partition leaders and fetch messages using long-polling, tracking their own offset as they go.

flowchart LR;
PR[Producer];
LB[Leader Broker];
F1[Follower 1];
F2[Follower 2];
CO[Consumer];
PR &#8211;>|Send Message| LB;
LB &#8211;>|Replicate| F1;
LB &#8211;>|Replicate| F2;
F1 &#8211;>|Ack| LB;
F2 &#8211;>|Ack| LB;
LB &#8211;>|Ack to Producer| PR;
CO &#8211;>|Fetch by Offset| LB;

## Distributed Log Architecture Deep Dive

The most important mental model for understanding Kafka is this: Kafka is a distributed log. Everything else flows from that.

A log, in the computer science sense, is an append-only, sequentially ordered record of events. You can only add to the end. You never modify or delete entries in the middle. Every entry has a position (an offset). Given an offset, you can find the corresponding entry in O(1) time.

This might sound like a limitation, but it's actually the source of Kafka's performance. Modern spinning hard drives are slow at random I/O but remarkably fast at sequential I/O. SSDs are fast at both, but sequential reads still win. By writing data only to the end of a log, Kafka turns every write into a sequential append. The OS can buffer these writes in page cache and flush them to disk efficiently. There's no seeking around looking for free blocks to write into.

flowchart LR;
W[Incoming Write];
A[Append to Log End];
S[Log Segment File];
I[Index File];
W &#8211;> A;
A &#8211;> S;
A &#8211;> I;

Kafka organizes each partition's log into segments. A segment is a pair of files: a  file that holds the actual message data, and a  file that maps offsets to byte positions in the log file. When a segment grows too large (configurable, often 1 GB), Kafka rolls over to a new segment. Old segments are eligible for retention cleanup.

The index file is sparse, not dense. Kafka doesn't store an index entry for every single message. It stores entries at intervals, so to find offset N, you look up the nearest indexed offset below N, then scan forward linearly from that point. This keeps the index small while still enabling fast lookups.

One of the subtler performance decisions is Kafka's aggressive use of the OS page cache. Kafka doesn't maintain its own in-memory cache of messages. It writes to disk and trusts the OS page cache to keep recently written and recently read data in memory. On a healthy, not-overloaded broker, most reads are served entirely from page cache with no actual disk I/O. The side effect is that brokers should have generous amounts of RAM, not necessarily for the JVM heap, but for the OS to use as page cache.

## Topic and Partition System

A topic is just a logical name. The physical reality is that a topic is implemented as one or more partitions, and each partition is an independent ordered log.

flowchart TD;
T[Topic: user-clicks];
P0[Partition 0 on Broker 1];
P1[Partition 1 on Broker 2];
P2[Partition 2 on Broker 3];
T &#8211;> P0;
T &#8211;> P1;
T &#8211;> P2;

When a producer sends a message, it decides which partition to send to based on one of three strategies. If a partition key is specified, Kafka hashes the key and consistently maps it to a partition. The same key always goes to the same partition, which gives you ordering guarantees for all messages with that key. If no key is specified, Kafka distributes messages round-robin or in batches across partitions. Producers can also implement completely custom partitioning logic.

Key-based partitioning solves a real problem. Imagine you're streaming order events and you need all events for a given order ID to be processed in sequence. If events for the same order can land on different partitions, you lose ordering guarantees because different consumers process different partitions independently. By using the order ID as the partition key, all events for order  always go to partition 4 (for example), and the consumer handling partition 4 sees them in the exact order they were produced.

The tradeoff here is the hotspot problem. If your partition key has poor cardinality or heavily skewed distribution (imagine an e-commerce site where one large enterprise customer generates 60% of all orders), one partition receives a disproportionate share of traffic. That partition's leader broker becomes a bottleneck. Consumer lag grows on the overloaded partition while other partitions sit mostly idle.

Partition count is a design decision that's hard to reverse. You can increase partition count, but you cannot decrease it. Adding partitions to an existing topic doesn't redistribute existing data; only new messages land on the new partitions. And each partition has overhead: memory for the leader broker to track ISR status, file descriptors for the log segments, and metadata stored in the controller.

A practical rule in production: use enough partitions to enable the parallelism you need, but don't over-partition. A commonly cited heuristic is to target about 10 to 20 partitions per broker per topic, adjusting based on throughput requirements.

## Producer Architecture

Producers in Kafka are more sophisticated than they look from the outside.

When you call , you're not immediately making a network request. The producer batches messages in memory before sending them over the wire. It maintains a buffer per partition. When either a batch is full (controlled by ) or a timeout expires (controlled by ), the batch is sent to the broker. This batching dramatically improves throughput because each network round trip carries many messages instead of one.

Producers also support compression. A batch of messages can be compressed as a unit using Snappy, LZ4, GZIP, or Zstd before transmission. The broker stores the compressed batch as-is, and consumers decompress on their end. Compression can reduce network and storage overhead by 3x to 5x for text-heavy payloads like JSON.

The acknowledgment mode () is one of the most important producer configuration choices.

  
    
      
        Acks Setting
        Behavior
        Durability
        Latency
      
    
    
      
        acks=0
        Producer does not wait for any acknowledgment
        Lowest - messages can be lost
        Lowest
      
      
        acks=1
        Leader broker acknowledges after writing to its local log
        Medium - lost if leader crashes before replication
        Medium
      
      
        acks=all
        All in-sync replicas must acknowledge
        Highest - survives broker failures
        Highest
      
    
  

Idempotent producers, introduced to address exactly-once delivery semantics, are worth understanding deeply. By default, if a producer times out waiting for an ack and retries the send, it might produce a duplicate if the original message actually did succeed. With idempotent producers enabled (), the broker assigns each producer a unique ID and sequences all messages. If a duplicate arrives, the broker detects and discards it. This gives you at-least-once delivery behavior with the duplicates silently removed, effectively achieving exactly-once at the producer level.

## Consumer Group Deep Dive

Consumer groups are how Kafka scales consumption horizontally. Each consumer group independently reads a topic. Within a group, partitions are divided among consumers.

flowchart TD;
T[Topic with 6 Partitions];
P0[Partition 0];
P1[Partition 1];
P2[Partition 2];
P3[Partition 3];
P4[Partition 4];
P5[Partition 5];
C1[Consumer 1];
C2[Consumer 2];
C3[Consumer 3];
T &#8211;> P0;
T &#8211;> P1;
T &#8211;> P2;
T &#8211;> P3;
T &#8211;> P4;
T &#8211;> P5;
P0 &#8211;> C1;
P1 &#8211;> C1;
P2 &#8211;> C2;
P3 &#8211;> C2;
P4 &#8211;> C3;
P5 &#8211;> C3;

If a topic has 6 partitions and a consumer group has 3 consumers, each consumer handles 2 partitions. If a consumer dies, Kafka triggers a rebalance: partitions are redistributed among the surviving consumers. If you add a fourth consumer, another rebalance happens. A consumer group can never have more active consumers than partitions, because there's nothing for the extra consumers to do.

Consumers commit their current offset periodically, either automatically or manually. The offset represents &ldquo;I have successfully processed everything up to here.&rdquo; If a consumer crashes before committing, the next consumer assigned to that partition starts from the last committed offset and reprocesses some messages. This is the &ldquo;at-least-once&rdquo; delivery model that most Kafka consumers use.

Rebalances deserve special attention in production systems. During a rebalance, consumption from the affected partitions stops until partition assignments stabilize. In large consumer groups with many partitions, this pause can be several seconds. There are things you can do to reduce rebalance impact: use static group membership with stable consumer IDs so Kafka can avoid rebalancing when a consumer restarts quickly, configure longer session timeouts to avoid false positives on consumer failure detection, and use incremental cooperative rebalancing (the default since Kafka 2.4) which only reassigns partitions that actually need to move rather than revoking everything at once.

Consumer lag is one of the most important metrics in a Kafka-based system. Lag is the difference between the latest offset in a partition and the consumer group's committed offset for that partition. Growing lag means consumers are falling behind. This could mean consumer processing is too slow, the consumer crashed and isn't running, or the upstream producers suddenly increased their write rate. Monitoring lag per consumer group, per topic, per partition gives you early warning of problems before they cascade.

## Replication and Fault Tolerance

Replication is how Kafka survives hardware failures without losing data. Every partition has a configurable replication factor. With , there are three copies of each partition: one leader and two followers.

flowchart TD;
PR[Producer];
LB[Leader Broker - Partition 0];
FB1[Follower Broker A - Replica];
FB2[Follower Broker B - Replica];
PR &#8211;>|Write| LB;
LB &#8211;>|Replicate| FB1;
LB &#8211;>|Replicate| FB2;

The In-Sync Replica (ISR) set is the list of followers that are caught up to the leader within a configurable time window (). A follower that is too far behind falls out of the ISR. This is significant because when , the leader waits for acknowledgment from all replicas in the ISR, not all replicas in total. If a follower is struggling and falls out of the ISR, the remaining ISR members determine the durability guarantee.

The  setting is where things get interesting. If you have  and , Kafka requires at least 2 in-sync replicas (including the leader) before acknowledging writes with . If two brokers go down and only one remains, writes will fail rather than proceed and risk data loss. This is a deliberate consistency-over-availability tradeoff.

When a leader broker crashes, the Kafka controller (either ZooKeeper-mediated or KRaft-based) detects the failure and elects a new leader from the ISR. This happens within seconds, and producers and consumers automatically discover the new leader through metadata refresh. The messages that were committed (acknowledged to ISR) before the crash are safe on the remaining replicas.

The scenario you want to avoid is a follower with significant replication lag being elected as leader. The  setting controls whether Kafka is allowed to elect an out-of-sync replica as leader when no in-sync replica is available. With this disabled (the safe default), Kafka will refuse to elect an unclean leader and the partition will be unavailable until a clean replica comes back. With it enabled, Kafka sacrifices consistency for availability: the out-of-sync leader may have missed some committed messages, causing data loss.

## Storage Internals

The storage layer is where Kafka's performance characteristics come from, and it is worth understanding in detail.

Each partition is stored as a directory on the broker's filesystem. Inside that directory, Kafka writes pairs of files:  files containing message data and  files for offset-to-byte-position lookups. When a segment exceeds the configured size (default 1 GB) or age (default 7 days), Kafka rolls a new segment. The old segments become candidates for retention cleanup.

flowchart TD;
PD[Partition Directory];
S1[Segment 0 Log File];
S1I[Segment 0 Index File];
S2[Segment 1 Log File];
S2I[Segment 1 Index File];
S3[Active Segment Log File];
S3I[Active Segment Index File];
PD &#8211;> S1;
PD &#8211;> S1I;
PD &#8211;> S2;
PD &#8211;> S2I;
PD &#8211;> S3;
PD &#8211;> S3I;

Zero-copy networking is one of the most impactful optimizations in Kafka's read path. Normally, serving data from disk to a network socket involves four copies: disk to kernel buffer, kernel buffer to userspace application buffer, userspace buffer back to kernel socket buffer, socket buffer to network. This is wasteful. Kafka uses the  system call (or its equivalent), which allows the OS to transfer data directly from the page cache to the network socket without involving userspace at all. This reduces CPU usage significantly and allows a single broker to sustain network throughput close to the hardware limit of the NIC.

Combined with page cache behavior, this creates an interesting property: if consumers are reading messages that were recently produced (i.e., they're not far behind), the data is likely still in the OS page cache, and the entire read path involves no disk I/O at all. Data goes from the network receive buffer, into page cache on write, and from page cache out through sendfile to the consumer. The disk is barely involved.

This is why broker memory is often more important than disk speed. Disk throughput matters for catching up from large lags, but for the common case of low-lag consumers, the system is mostly memory-bound.

## Retention and Cleanup System

Kafka keeps messages for a configurable duration regardless of whether they've been consumed. This is fundamentally different from traditional queues that delete messages after delivery. The default retention is 7 days, but this can be set to hours, days, or even set to retain data indefinitely.

There are two retention models. Delete retention removes old log segments once they exceed the configured time or size limit. This is the default and is what you want for high-volume, short-lived event streams.

Log compaction is a more sophisticated mechanism designed for a different use case. With compaction enabled, Kafka guarantees that the log contains at least the most recent message for each key. Think of it as a continuously maintained key-value store built on top of a log. Kafka runs a background compaction thread that merges segments, keeps the latest value per key, and discards older values for the same key. Deleting a key is done by sending a tombstone message: a message with the target key and a null value. Compaction eventually removes the original messages and the tombstone.

Log compaction is perfect for changelog topics that track the current state of something: user profile updates, configuration changes, account balance updates. Consumers who restart can replay the compacted topic to rebuild state without needing years of history.

## Kafka Networking Model

Kafka uses a custom binary protocol over TCP. There is no HTTP, no JSON, no overhead from a generic protocol. Requests and responses have fixed wire formats with tight encoding. This keeps parsing overhead minimal.

Brokers use a non-blocking I/O model internally. A small number of network threads handle all connection I/O, routing requests to request queues, and responses back to clients. A separate pool of request handler threads processes the actual requests (reads and writes). This design allows brokers to handle thousands of concurrent connections without thread-per-connection overhead.

Consumers use long-polling to fetch messages. A  specifies a partition, an offset to start from, a minimum number of bytes to return, and a maximum wait time. If less data than the minimum threshold is available, the broker waits (holds the request) until either enough data arrives or the timeout expires before responding. This reduces empty fetch responses and their associated overhead when topics are relatively quiet.

Producers use a pipeline model. Multiple batches can be in-flight simultaneously without waiting for previous ones to be acknowledged, up to the configured  limit. This keeps producer throughput high without sacrificing ordering (since Kafka processes requests from a given producer in order).

## Stream Processing Architecture

Beyond being a message bus, Kafka is increasingly used as a stream processing platform via Kafka Streams, a client library that runs inside your application process.

flowchart LR;
ST[Source Topic];
KS[Kafka Streams App];
RS[RocksDB State Store];
SK[Sink Topic];
ST &#8211;>|Read Events| KS;
KS &#8211;>|Query and Update| RS;
KS &#8211;>|Write Results| SK;

Kafka Streams processes records one at a time or in windows. For stateful operations like counts, aggregations, or joins, Kafka Streams maintains state in an embedded RocksDB instance on local disk. This is called a state store. The state store is backed by a Kafka changelog topic (a compacted topic), so if the application crashes and restarts, it can rebuild state from the changelog rather than reprocessing the entire history. State stores make stateful stream processing practical at scale.

Windowed aggregations are a common pattern. Imagine counting how many times each user ID appears in a 5-minute tumbling window. Kafka Streams buffers records within the window, aggregates, and emits results when the window closes. Event-time processing (using timestamps embedded in messages rather than wall-clock time) means late-arriving events can be attributed to the correct window, up to a configurable grace period.

Exactly-once semantics in stream processing require coordination between reading, processing, and writing. Kafka Streams achieves this using transactions: reads, state store updates, and writes to output topics are all committed atomically. Either all of it happens or none of it does. This eliminates the scenario where a message is processed, output is written, but the consumer fails before committing its offset and the message gets processed again with a duplicate output.

## Scalability Deep Dive

Kafka scales horizontally at every layer, but each dimension of scaling has its own ceiling and its own set of gotchas.

Broker scaling is the most straightforward. Adding brokers to a cluster gives you more storage capacity and more network bandwidth. But Kafka doesn't automatically rebalance partitions when you add brokers. You need to run a partition reassignment tool to move partition replicas to the new brokers. This reassignment involves inter-broker data copying, which consumes network bandwidth and can affect broker performance during the migration.

Partition scaling is how you increase parallelism. More partitions means more consumers can work in parallel. But each partition has overhead: the Kafka controller tracks leader and ISR state for every partition, and this metadata coordination becomes a bottleneck as partition count grows into the hundreds of thousands. A practical ceiling in most Kafka deployments is around 200,000 to 500,000 partitions per cluster.

Producer scaling is almost unbounded in practice. Producers are stateless and can be scaled independently. The bottleneck is usually partition leaders: each partition leader has a finite throughput capacity. If a single partition receives more writes than the leader can handle, you need to increase partition count to spread load.

Consumer scaling within a group is limited by partition count. If you have 10 partitions and 20 consumers in a group, 10 consumers sit idle. If you need more consumer parallelism, you need more partitions.

  
    
      
        Scaling Dimension
        Mechanism
        Bottleneck
        Practical Ceiling
      
    
    
      
        Brokers
        Add broker nodes to cluster
        Partition reassignment I/O
        Hundreds of brokers
      
      
        Partitions
        Increase partition count per topic
        Controller metadata overhead
        ~200K-500K per cluster
      
      
        Producers
        Add producer instances
        Partition leader throughput
        Effectively unlimited
      
      
        Consumers
        Add consumers to group
        Partition count (hard ceiling)
        One per partition max
      
    
  

## Reliability and Availability

Running Kafka reliably in production requires thinking about several failure modes simultaneously.

For multi-region deployments, Confluent and open-source projects offer MirrorMaker 2, which replicates topics from one Kafka cluster to another. This is asynchronous replication, so there's always some lag between the primary and the secondary. In a disaster recovery scenario, failing over to the secondary cluster means accepting potential data loss for the most recent messages.

Monitoring a Kafka cluster means watching several key metrics. Under-replicated partitions (partitions where not all replicas are in the ISR) are a critical signal: they mean you're operating with reduced durability and one more broker failure could cause data loss. Consumer group lag tells you whether consumers are keeping up. Producer request error rates tell you whether writes are succeeding. Broker disk utilization is important because Kafka brokers need to retain data, and full disks cause write failures.

Request latency on brokers, particularly the produce and fetch latency percentiles (p99, p999), tell you about tail latency that real clients experience but averages miss. A broker where the p999 produce latency is 10 seconds will cause producer timeouts and retries even if the median latency is 5ms.

Alerting strategies that work in practice: alert on under-replicated partitions immediately (this is always a problem), alert on consumer lag crossing a threshold that's relevant to your SLAs, alert on disk utilization above 80% (you want time to react before full disk causes an outage), and alert on producer error rates above a small threshold.

## Performance Optimization

The defaults Kafka ships with are conservative. Production systems frequently tune several parameters.

On the producer side, increasing  and  trades latency for throughput. A producer with  will wait up to 5 milliseconds to accumulate more messages before sending, resulting in larger batches and better network utilization at the cost of 5ms of additional latency. For high-throughput pipelines where a few milliseconds of added latency is acceptable, this is a significant win.

Compression is almost always worth enabling. LZ4 has an excellent compression-to-CPU-cost ratio. Zstd achieves better compression ratios at slightly higher CPU cost. Snappy is a good middle ground. For JSON-heavy payloads, 4x compression ratios are common, which cuts network and storage costs by 75%.

On the broker side, the most impactful thing is ensuring the OS has abundant memory for page cache. Running brokers with JVM heaps of 4-6 GB and leaving the rest of a 64 GB machine as page cache is a common production configuration. Kafka's JVM heap doesn't need to be enormous because Kafka doesn't cache data in Java objects; it relies on the OS.

Disk choice matters when consumers are behind. For consumers close to the head of the log (recent messages), data is likely in page cache and disk is irrelevant. For consumers far behind, they'll be doing actual disk reads. SSDs eliminate disk seek time entirely and are strongly preferred for Kafka brokers, even though sequential read patterns partially mitigate HDD seek penalties.

## Engineering Tradeoffs

Let's talk about the real decisions that engineers make and why.

Durability versus latency: Using  with  gives you strong durability guarantees at the cost of producer latency (waiting for replication). For an analytics pipeline where losing a few events is acceptable,  or even  may be the right call. For a financial events system,  is non-negotiable.

Consistency versus availability: Disabling unclean leader election keeps data consistent but means a partition can go unavailable if all in-sync replicas are down. Enabling it keeps the partition available but risks data loss. Most production systems disable it, accepting reduced availability in exchange for consistency.

Batching versus real-time delivery: Larger batches improve throughput dramatically but add latency. If you're building a fraud detection system where every millisecond matters, you tune for low latency and accept higher per-message overhead. If you're building a clickstream analytics pipeline, you batch aggressively.

Partition count versus operational complexity: More partitions mean more parallelism but also more file descriptors, more leader elections to manage, longer rebalance times, and more metadata overhead in the controller. Starting with fewer partitions and increasing as needed is usually wiser than over-provisioning.

Replayability versus storage cost: Kafka's ability to replay history is incredibly valuable. But storing 90 days of high-volume event data is expensive. The tradeoff is configured per topic. Short-lived operational events might have 24-hour retention. Business-critical events might retain indefinitely with log compaction.

## Real-World Technology Stack

Understanding why each technology in the Kafka stack was chosen illuminates the design philosophy.

Java is the language Kafka is written in. The JVM's mature garbage collector, extensive monitoring ecosystem, and cross-platform reliability make it appropriate for infrastructure software, despite the overhead that sometimes accompanies JVM applications. Kafka mitigates GC pauses by keeping its hot data path in off-heap memory (via page cache) rather than Java objects.

Linux page cache is not a technology Kafka chose so much as a constraint it was designed around. Linux aggressively caches file data in available RAM. Kafka's design, particularly its choice to write to disk rather than maintain an application-level cache, means that the OS's page cache effectively becomes Kafka's cache. This is elegant: Kafka doesn't need to write its own cache eviction logic, and the cache survives Kafka process restarts.

RocksDB backs stateful stream processing in Kafka Streams. RocksDB is an LSM-tree-based embedded key-value store optimized for write-heavy workloads. It persists state durably on local disk and provides fast point lookups, making it suitable for the aggregation state stores that stream processing applications maintain.

KRaft (Kafka's Raft-based metadata mode) replaces ZooKeeper by running a metadata quorum directly inside Kafka brokers. This eliminates an operationally separate ZooKeeper cluster, simplifies deployment, and allows Kafka to scale to more partitions because the KRaft controller is more efficient at handling metadata operations.

TCP/IP with the  optimization forms the core of Kafka's network layer. Unlike HTTP/REST protocols that require parsing overhead, Kafka's binary protocol over raw TCP is as lean as you can get without going to UDP.

## System Design Interview Perspective

Kafka-style questions appear frequently in system design interviews, usually framed as: &ldquo;Design a distributed messaging system&rdquo; or &ldquo;Design a real-time analytics pipeline&rdquo; or &ldquo;How would you design an event-driven order processing system?&rdquo;

Interviewers are not looking for you to recite Kafka's documentation. They want to see how you reason about distributed systems tradeoffs.

Strong answers typically begin by clarifying requirements: How many messages per second? What are the durability requirements? Do consumers need ordering guarantees? What is the acceptable consumer lag? These questions signal that you understand that architectural decisions are driven by requirements, not convention.

Then, walk through the core components one layer at a time. Start with the problem (how to decouple producers from consumers at scale), introduce the concept of a durable log, explain why partitioning is necessary for scalability, explain how replication provides fault tolerance, explain how consumer groups enable parallel consumption. Show that you understand the why behind each decision.

Common mistakes candidates make include conflating Kafka with a traditional message queue (Kafka keeps messages after consumption, queues typically don't), not discussing replication and durability at all (reliability is half of what makes distributed messaging hard), and failing to discuss failure scenarios (what happens when a broker goes down, when a consumer crashes, when a network partition occurs).

For strong answers, discuss the specific tradeoffs you would make given the requirements stated, explain how you would monitor the system in production (what metrics matter, what alerts you would set), and be honest about where the design has weaknesses.

  
    
      
        Interview Topic
        Weak Answer
        Strong Answer
      
    
    
      
        Durability
        Messages are stored on disk
        Explains acks, ISR, min.insync.replicas, and the consistency-availability tradeoff
      
      
        Scalability
        Add more Kafka nodes
        Discusses partition-based parallelism, consumer group limits, partition count tradeoffs
      
      
        Ordering
        Kafka preserves order
        Explains per-partition ordering, key-based partitioning, ordering across partitions is not guaranteed
      
      
        Failure handling
        Kafka automatically recovers
        Describes ISR, leader election, unclean election risks, rebalance behavior
      
      
        Delivery semantics
        At-least-once by default
        Contrasts at-most-once, at-least-once, exactly-once, explains idempotent producers and transactions
      
    
  

One interview tip that separates good candidates from great ones: bring up operational concerns. Mention consumer lag monitoring, under-replicated partition alerting, disk capacity planning, and rebalance overhead. Real distributed systems don't just work in theory; they get deployed, monitored, and debugged in production. Showing that you've thought about the operational dimension of the system tells the interviewer you've operated distributed systems before, not just read about them.

## Closing Thoughts

Kafka feels complex when you first encounter it. There are brokers, partitions, consumer groups, ISRs, offsets, log segments, retention policies. The terminology is dense and the failure modes are subtle.

But underneath all of that is a simple and powerful idea: treat your data as an ordered, durable, replayable log. Let producers write to the end of that log. Let consumers read from any position in that log. Replicate the log across machines so no single failure loses data. Partition the log so the system can scale beyond what a single machine can handle.

Everything in Kafka's architecture is a consequence of that core idea, shaped by the realities of distributed systems: network partitions happen, disk seeks are slow, memory is finite, and consumers sometimes fall behind. Understanding the idea and the constraints that shaped it is what makes Kafka's design not just intelligible but intuitive.

The engineers who built Kafka at LinkedIn were solving a real problem under real production constraints. The result was not the last word in distributed messaging (there are systems with different tradeoffs worth knowing), but it was a remarkably well-considered answer to the question of how you move large amounts of data between systems reliably, at scale, and without tight coupling. That question doesn't go away. If anything, it becomes more pressing as systems grow. Which is probably why Kafka is still here, still evolving, and still worth understanding deeply.
