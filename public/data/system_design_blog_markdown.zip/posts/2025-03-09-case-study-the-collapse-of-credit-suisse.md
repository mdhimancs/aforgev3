---
title: "Case Study: The Collapse of Credit Suisse"
date: "2025-03-09T11:28:00+05:30"
slug: "case-study-the-collapse-of-credit-suisse"
categories: ["case_study", "banks", "fintech"]
original_url: "https://rishijeet.github.io/blog/case-study-the-collapse-of-credit-suisse/"
word_count: 777
reading_time: "4 min"
author: "Rishijeet Mishra"
---

# Case Study: The Collapse of Credit Suisse

*Published on 2025-03-09 by Rishijeet Mishra | [https://rishijeet.github.io/blog/case-study-the-collapse-of-credit-suisse/](https://rishijeet.github.io/blog/case-study-the-collapse-of-credit-suisse/)*

Credit Suisse, one of Switzerland’s most prestigious banks, fell from grace due to years of scandals, mismanagement, and financial instability. Once a symbol of Swiss banking excellence, the bank collapsed in 2023, forcing a historic takeover by UBS. This case study explores the major factors leading to Credit Suisse’s downfall, examining key financial data, regulatory failures, and market reactions.

![Alt text](https://rishijeet.github.io/images/2025/credit_suisse.webp)

Source: Internet

## Background of Credit Suisse

- Founded: 1856

- Headquarters: Zurich, Switzerland

- Peak Market Capitalization: ~$96 billion (2007)

- Core Services: Investment banking, wealth management, asset management

Credit Suisse was once among the most respected global banks, competing with giants like JPMorgan Chase, Goldman Sachs, and Deutsche Bank. However, a series of financial missteps and scandals weakened its standing in the banking industry.

## Key Events Leading to the Collapse

### Archegos Capital Collapse (2021)

What Happened?

- Archegos Capital, a highly leveraged hedge fund run by Bill Hwang, used complex financial instruments called total return swaps to take massive, concentrated positions in stocks like ViacomCBS.

- When stock prices dropped, Archegos defaulted on margin calls, leading to $10 billion in combined losses across multiple banks.

- Credit Suisse was the worst hit, losing $5.5 billion, compared to Nomura ($2 billion) and Goldman Sachs ($0 due to better risk management).

Impact:

- Immediate stock price drop of 14%.

- Credit Suisse's Chief Risk Officer and Head of Investment Banking resigned.

- Regulatory investigations into its risk oversight.

### Greensill Capital Scandal (2021)

What Happened?

- Greensill Capital, a supply-chain finance firm, collapsed in March 2021 after losing investor confidence.

- Credit Suisse had $10 billion in exposure through supply chain finance funds that Greensill managed.

- Investigations revealed that Credit Suisse had overlooked high-risk loans tied to Greensill’s questionable business model.

Impact:

- Credit Suisse was forced to freeze $10 billion in client funds.

- Investors filed lawsuits for mismanagement and negligence.

- Further damage to its reputation and regulatory scrutiny.

### Money Laundering and Legal Issues

Credit Suisse was repeatedly implicated in financial scandals:

- 2022: Cocaine Trafficking Case – Swiss courts found Credit Suisse guilty of failing to prevent money laundering for a Bulgarian cocaine cartel.

- 2014-2022: U.S. Tax Evasion Scandals – The bank paid over $2.6 billion in fines for helping wealthy clients evade U.S. taxes.

- Mozambique “Tuna Bonds” Scandal – Credit Suisse arranged fraudulent loans worth $2 billion, leading to a national debt crisis in Mozambique.

Impact:

- Legal fines exceeding $5 billion over a decade.

- Loss of investor and client confidence.

- Declining reputation and regulatory pressure.

### 2022-2023 Liquidity Crisis & Collapse

What Happened?

- In October 2022, rumors spread about Credit Suisse’s financial instability.

- Wealthy clients withdrew $120 billion in Q4 2022 alone.

- The bank’s stock plunged 75% in 2022.

- The collapse of Silicon Valley Bank (SVB) in March 2023 triggered a broader banking crisis, intensifying fears about Credit Suisse.

- Saudi National Bank, Credit Suisse’s largest investor (9.9% stake), refused to inject more capital, worsening the crisis.

- The Swiss government intervened, brokering a $3.2 billion emergency takeover by UBS in March 2023.

![Alt text](https://rishijeet.github.io/images/2025/cs_chart.png)

Source: Internet

Market Reaction:

- Credit Suisse stock hit an all-time low of $0.82 before the UBS takeover.

- UBS share price surged as markets viewed the deal as a stabilization move.

- Swiss government guaranteed $9 billion in losses for UBS to absorb Credit Suisse’s assets.

## Final Collapse & UBS Takeover

On March 19, 2023, the Swiss government orchestrated a forced merger between UBS and Credit Suisse:

- UBS paid only $3.2 billion, a fraction of Credit Suisse’s former valuation.

- Swiss authorities provided $100 billion in liquidity support.

- The deal wiped out $17 billion in Credit Suisse's AT1 bonds, angering bondholders.

- UBS’s market position strengthened, but thousands of jobs were cut.

## Lessons from the Credit Suisse Crisis

- The Importance of Strong Risk Management

Credit Suisse’s exposure to highly leveraged entities (Archegos, Greensill) without proper risk controls was a
major factor in its downfall.

- Reputation and Trust Are Everything in Banking

Multiple scandals (money laundering, tax evasion, fraud) eroded public trust, leading to massive client withdrawals.

- Government Intervention in Financial Crises

Swiss regulators had to engineer an emergency UBS takeover to prevent systemic risk.

- The End of a Banking Giant

A 167-year-old institution collapsed due to poor management, excessive risk-taking, and legal troubles.

- UBS now dominates Swiss banking, marking a shift in global finance.

## Conclusion

The Credit Suisse crisis serves as a cautionary tale for banks worldwide. Despite being a globally significant institution, its failure to manage risks, handle scandals, and maintain client confidence led to its historic collapse in 2023. With tighter regulations and increased scrutiny, the banking sector must learn from this failure to avoid similar downfalls in the future.
