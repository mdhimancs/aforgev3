---
title: "How YouTube Scaled to Billions of Users Using MySQL?"
date: "2026-05-30T13:26:58+05:30"
slug: "how-youtube-scaled-to-billions-of-users-using-mysql"
categories: ["system_design", "architecture", "google", "youtube", "technology"]
original_url: "https://rishijeet.github.io/blog/how-youtube-scaled-to-billions-of-users-using-mysql/"
word_count: 7738
reading_time: "39 min"
author: "Rishijeet Mishra"
---

# How YouTube Scaled to Billions of Users Using MySQL?

*Published on 2026-05-30 by Rishijeet Mishra | [https://rishijeet.github.io/blog/how-youtube-scaled-to-billions-of-users-using-mysql/](https://rishijeet.github.io/blog/how-youtube-scaled-to-billions-of-users-using-mysql/)*

> There is a common belief in software engineering circles that relational databases cannot scale. The moment you say &ldquo;MySQL&rdquo; in a room full of distributed systems engineers, someone will inevitably raise an eyebrow and say &ldquo;that won't hold up at scale.&rdquo; YouTube's story is one of the most powerful counterarguments to that assumption. At the time of its acquisition by Google in 2006, YouTube was already one of the fastest-growing websites on the internet. And it was running on MySQL.

![Alt text](https://rishijeet.github.io/images/system_design/youtube-mysql.jpg)

Understanding how YouTube built and scaled its database infrastructure is not just a historical curiosity. It is a practical masterclass in how thoughtful engineers take ordinary tools and stretch them far beyond what anyone thought possible. The lessons here apply directly to the systems you are building today.

## The Scale of the Problem

Let's ground this with numbers. YouTube launched in 2005. Within six months it was serving more than two million video views per day. By 2006, that number had climbed to over 100 million views per day. Google acquired it for $1.65 billion in October of that year. By 2012, more than 72 hours of video were being uploaded every minute. Today that number exceeds 500 hours per minute.

Every single one of those uploads, views, likes, comments, subscriptions, and playlist additions generates database traffic. Most of it lands on metadata — who uploaded what, who watched what, who subscribed to whom. And for years, the engine handling that metadata was MySQL.

The engineers at YouTube did not achieve this by luck or brute force. They achieved it through a series of deliberate architectural decisions, each one designed to address a specific bottleneck at a specific moment in time. That is the story worth understanding.

## The Early Architecture

In the beginning, YouTube was a classic LAMP stack application. Linux, Apache, MySQL, and Python. The earliest engineers chose this combination because it was fast to build with, well understood, and cost-effective. There was no budget for exotic distributed systems. There was no team large enough to operate them even if the budget existed.

The data model was straightforward. You had users, videos, comments, and subscriptions. A user had a profile. A video had an owner, a title, a description, tags, and a view count. Comments belonged to videos and users. Subscriptions connected one user to another. None of this was conceptually complicated. It mapped cleanly to relational tables.

A simplified version of the early schema looked something like this:

This schema is clean, normalized, and easy to reason about. It was the right choice for a startup. The mistake would have been to over-engineer it from day one.

## Why MySQL?

The decision to use MySQL was not a random one. MySQL was the dominant open-source relational database in 2005. It had excellent Python and PHP client libraries. Its documentation was thorough. The engineering community knew how to operate it. Hosting providers supported it out of the box.

The alternatives at the time were limited. PostgreSQL existed but had a smaller deployment community. Oracle and DB2 were expensive and designed for enterprise procurement cycles, not startup velocity. The NoSQL movement was not yet a coherent thing — Cassandra was not released until 2008, MongoDB until 2009. The Bigtable paper had been published by Google in 2006, but it was not software you could download and run.

More importantly, MySQL's transactional semantics gave the early YouTube engineers something they needed: confidence. When a user uploaded a video and the metadata write succeeded, it succeeded completely. When a comment was posted, it was either there or it was not. Relational databases handle these kinds of guarantees naturally, and in the early days, correctness mattered more than raw throughput.

There is also the team dynamics angle. The early YouTube team was small. Hiring engineers who already knew MySQL was straightforward. Training new engineers on MySQL was fast. That is not a technical reason to choose a database, but it is a real-world reason that affects how fast you can build and how reliably you can operate.

## What MySQL Actually Stored

This is the section that confuses many engineers when they first learn about YouTube's architecture. MySQL stored metadata. Not video files. Understanding this distinction is essential to understanding why MySQL could scale at all.

Video files are enormous. A single one-minute video at 1080p is several hundred megabytes. At the time of YouTube's peak growth, hundreds of hours of video were being uploaded every minute. Storing those binary blobs in MySQL would have been catastrophic for several reasons.

The replication overhead alone would have been unbearable. MySQL replication works by shipping the binary log from primary to replicas. Every write to the primary gets replicated to every replica. If a video upload writes 500MB to the database, that 500MB gets shipped to every replica in your topology. With multiple replicas, your network bandwidth explodes. Your disk I/O on every replica server maxes out. Your replication lag balloons to the point where replicas become useless for serving reads.

Backup complexity becomes a nightmare. Taking a logical dump of a database that contains hundreds of terabytes of binary blobs is not a reasonable operation. The restore time alone would make recovery objectives impossible to meet.

MySQL's InnoDB storage engine is optimized for row-level operations on structured data. It is not optimized for streaming large blobs to clients. The buffer pool, which is InnoDB's primary caching mechanism, would fill entirely with video data, leaving no room to cache the index and row data that actually needs to be fast.

So YouTube stored video files in a purpose-built distributed object storage system. Google's infrastructure, after the acquisition, ultimately moved these to systems closely related to GFS (Google File System). Before the acquisition, YouTube used their own storage infrastructure. The key design principle was the same in both cases: the database stores a reference to the video file, not the file itself.

The  is just a string. MySQL stores it in microseconds. The actual bytes live somewhere else. This pattern — storing metadata in a relational database and binary content in an object store — is one of the most important architectural lessons from YouTube's history, and it remains the correct approach for virtually every modern system that handles media.

## The Scaling Problem Arrives

Growth that looks like a feature is actually a time bomb if your infrastructure is not ready for it. YouTube's user base did not grow linearly — it grew exponentially. And each new user did not just watch videos. They uploaded videos, left comments, subscribed to channels, created playlists, and clicked like buttons. Every one of those actions generated writes to MySQL.

The first problem to emerge was hot tables. The  table was the center of gravity for almost every operation in the system. Watch a video — read from . Upload a video — write to . Get recommendations — read from . The table became a bottleneck not because MySQL was slow, but because the table was genuinely too hot. Too many concurrent reads and writes hitting the same data structures, the same indexes, the same pages in the buffer pool.

The  column in the  table is worth discussing specifically. Every video view incremented a counter. At peak traffic, popular videos were receiving hundreds of thousands of views per minute. That means hundreds of thousands of  statements per minute, all hitting the same row. InnoDB's row-level locking handles concurrent updates well, but there is a physical limit to how fast you can serialize updates to a single row. This is called write hotspotting, and it is a fundamental distributed systems problem that no amount of hardware can fully solve.

The second problem was index growth. As the number of videos, users, and comments grew into the hundreds of millions, the indexes on the hot tables grew proportionally. An index on  in the  table that once fit entirely in memory no longer fit. Every query that accessed comments for a video now required disk I/O. Disk I/O is orders of magnitude slower than memory access. Query latency climbed.

The third problem was backup windows. MySQL backups take the system offline or put significant load on it. As the dataset grew, the backup window grew with it. What once took minutes started taking hours. Backup complexity became an operational nightmare.

Vertical scaling — adding more RAM, more CPU, faster disks — bought time. But it could not buy enough time. Eventually the team had to confront the reality that a single MySQL server, no matter how powerful, had a ceiling. The ceiling was lower than the load.

## Read Replicas: The First Scaling Move

The first architectural response to the scaling problem was read replicas. This is a technique that is well understood today, but worth explaining precisely because the tradeoffs matter.

MySQL's primary-replica replication works like this: every write to the primary database is recorded in the binary log. Replicas connect to the primary, pull those log entries, and apply them to their own data. The replication is asynchronous — the primary does not wait for replicas to confirm before acknowledging a write to the application.

The practical effect is that you can direct all write traffic to the primary and distribute read traffic across multiple replicas. For YouTube, where the ratio of reads to writes was extremely high (far more people watch videos than upload them), this was an immediate win.

graph TD
    A[Application Servers] &#8211;> B[Primary MySQL]
    A &#8211;> C[Replica 1]
    A &#8211;> D[Replica 2]
    A &#8211;> E[Replica 3]
    B &#8211;> C
    B &#8211;> D
    B &#8211;> E
    style B fill:#c0392b,color:#fff
    style C fill:#2980b9,color:#fff
    style D fill:#2980b9,color:#fff
    style E fill:#2980b9,color:#fff
    style A fill:#27ae60,color:#fff

Adding a replica is operationally straightforward. You provision a new server, let it sync from the primary, and add it to the pool of servers that handle read queries. YouTube added many replicas to handle their growing read load.

But replication has a critical tradeoff: replication lag. Because replication is asynchronous, replicas can fall behind the primary. If a user uploads a video and immediately navigates to their video library, the read query might hit a replica that has not yet received the write. The video appears to be missing. This inconsistency is called eventual consistency — the replica will eventually catch up, but for a brief window, it shows stale data.

YouTube handled this with careful routing logic. Writes that needed to be immediately visible (like a user's own video upload) were read back from the primary, not a replica. Background reads and less latency-sensitive queries were spread across replicas. This kind of read-after-write consistency management is a real operational burden. It means your application code has to be aware of the replication topology, which adds complexity.

Another challenge: replicas help with reads, but they do nothing for write scalability. The primary still handles every write in the system. As write traffic grew, the primary became the bottleneck all over again.

## Sharding: Horizontal Scaling for Real

Read replicas extend the read capacity of a single dataset. Sharding extends the write capacity by splitting the dataset itself across multiple independent database servers. It is the point at which &ldquo;scaling MySQL&rdquo; stops being a configuration exercise and becomes an architectural commitment.

The concept is simple: instead of one database that holds all the data, you have many databases, each holding a partition of the data. If you have ten shards and you route each user's data to a specific shard based on the user's ID, each shard holds roughly one-tenth of the total data and handles roughly one-tenth of the total traffic.

YouTube sharded their MySQL infrastructure based primarily on users. A user and all of their associated data — their videos, their comments, their subscriptions, their playlists — was co-located on the same shard. This choice was deliberate. By keeping related data together, you minimize the number of cross-shard joins and the number of shards you need to query to assemble a user's complete profile.

graph TD
    A[Router Layer] &#8211;> B[Shard 0 users 0 to 9M]
    A &#8211;> C[Shard 1 users 9M to 18M]
    A &#8211;> D[Shard 2 users 18M to 27M]
    A &#8211;> E[Shard N users NxM to end]
    B &#8211;> F[Primary + Replicas]
    C &#8211;> G[Primary + Replicas]
    D &#8211;> H[Primary + Replicas]
    E &#8211;> I[Primary + Replicas]
    style A fill:#8e44ad,color:#fff
    style B fill:#c0392b,color:#fff
    style C fill:#c0392b,color:#fff
    style D fill:#c0392b,color:#fff
    style E fill:#c0392b,color:#fff

The shard routing logic typically works through a lookup table or a deterministic hash. YouTube used a lookup table approach for some data, where a lightweight central mapping service told the application which shard to query for a given user ID. The lookup service itself had to be extremely fast and highly available — it was in the critical path of every database operation.

Hash-based sharding, where , is simpler but has a brutal problem: resharding. If you start with 16 shards and grow to 32, a naive modulo hash sends roughly half of your users to different shards. You have to move enormous amounts of data while keeping the system live. YouTube invested significant engineering effort in building resharding tools that could migrate data incrementally, with careful coordination between the old shard assignment and the new one.

Consistent hashing is an alternative that reduces the resharding problem. By mapping both user IDs and shards to positions on a virtual ring, adding a new shard only requires moving data from one adjacent shard rather than rehashing all data. Virtual nodes (where each physical shard occupies multiple positions on the ring) further smooths the load distribution.

Sharding introduces cross-shard query problems. If you want to find all comments on a given video, and comments are sharded by the commenter's user ID, you may need to query multiple shards and merge the results. YouTube handled this by denormalizing certain data — storing copies of information in places where it was frequently accessed, rather than always going back to the canonical source. Denormalization trades storage efficiency and write complexity for read performance, and at internet scale, that tradeoff is almost always worth it.

  
    
      
        Sharding Strategy
        Description
        Strengths
        Weaknesses
        Used For
      
    
    
      
        Range-based
        User IDs 0–9M on shard 0, 9M–18M on shard 1, etc.
        Simple routing, easy range scans
        Hotspots on new user shard, uneven load
        Early YouTube
      
      
        Hash-based (modulo)
        shard = hash(user_id) % N
        Even distribution, deterministic
        Expensive resharding when N changes
        Many early sharded systems
      
      
        Consistent hashing
        Virtual ring; adding shards moves minimal data
        Minimal data movement on resize
        More complex routing logic
        Later scaling phases
      
      
        Directory-based
        Central lookup table for user-to-shard mapping
        Flexible, supports irregular assignments
        Lookup service is a SPOF; extra round trip
        YouTube shard routing
      
    
  

## MySQL Replication Architecture in Depth

Each shard in YouTube's MySQL topology was not a single server. Each shard was itself a small cluster: one primary and multiple replicas. The primary handled all writes for that shard. The replicas handled reads.

The replication topology evolved over time. In the early phases, each shard had a simple star topology — one primary, several replicas all reading directly from it. This worked well for a moderate number of replicas but eventually hit limits. The primary could only sustain so many replication connections and so much log shipping bandwidth before it became a bottleneck.

Later, YouTube implemented hierarchical replication: a relay replica would sit between the primary and a group of downstream replicas. The primary shipped logs to the relay, which then redistributed to the downstream replicas. This reduced the load on the primary and allowed each shard to scale to more replicas without the primary suffering.

graph TD
    A[Primary] &#8211;> B[Relay Replica 1]
    A &#8211;> C[Relay Replica 2]
    B &#8211;> D[Read Replica]
    B &#8211;> E[Read Replica]
    B &#8211;> F[Analytics Replica]
    C &#8211;> G[Read Replica]
    C &#8211;> H[Read Replica]
    C &#8211;> I[Backup Replica]
    style A fill:#c0392b,color:#fff
    style B fill:#e67e22,color:#fff
    style C fill:#e67e22,color:#fff
    style D fill:#2980b9,color:#fff
    style E fill:#2980b9,color:#fff
    style F fill:#16a085,color:#fff
    style G fill:#2980b9,color:#fff
    style H fill:#2980b9,color:#fff
    style I fill:#7f8c8d,color:#fff

Failover was a constant operational concern. If a shard's primary died, one of the replicas had to be promoted to primary. The challenge was ensuring that the promoted replica had fully caught up with the old primary before taking writes. Semi-synchronous replication, which requires at least one replica to acknowledge a write before the primary commits, was used to reduce the risk of data loss during failover. The tradeoff was slightly higher write latency — the primary had to wait for one acknowledgment before returning to the application.

The failover automation — detecting that a primary was down, selecting the most up-to-date replica, updating the routing table, and notifying application servers of the new primary — was its own significant engineering problem. YouTube built tooling to automate this process, but it required careful testing and regular drills to ensure it worked correctly when it was actually needed.

  
    
      
        Replication Model
        How It Works
        Data Safety
        Write Latency Impact
        Use Case
      
    
    
      
        Asynchronous
        Primary commits, then ships log to replicas
        Risk of data loss on failover
        None
        Default MySQL replication; used for read scaling
      
      
        Semi-synchronous
        Primary waits for at least one replica ACK before commit
        At most one transaction lost on failover
        Adds one network RTT
        YouTube shard primaries
      
      
        Synchronous (Group Replication)
        All replicas must commit before primary acknowledges
        No data loss
        Significant; proportional to replica count
        Not typical at YouTube scale
      
    
  

## Caching Saves the Day

If you take one operational insight away from YouTube's database architecture, make it this: caching did more for their scalability than almost any database optimization. At peak traffic, the vast majority of data being served to users was coming from cache, not from MySQL at all.

YouTube used Memcached extensively. Memcached is a distributed, in-memory key-value store. It is extremely simple: you store a value under a key, and you retrieve it by key. It does not support queries, indexes, or transactions. It is not durable — if a Memcached server restarts, the cache is gone. None of that matters for its intended purpose.

The pattern is straightforward:

For a popular video, this means the database query executes very rarely. The first request after a cache miss populates the cache. All subsequent requests within the TTL window hit Memcached, which responds in under a millisecond. The database is protected from the thundering herd of requests that a viral video would otherwise generate.

YouTube cached aggressively: video metadata, user profiles, subscription lists, comment counts, recommendation data. The cache layer became as important to the architecture as the database layer. Engineers had to reason carefully about cache invalidation — when a user updated their profile, the cached version had to be purged or updated. When a video was deleted, its cache entry had to be removed.

Cache invalidation bugs are subtle and nasty. A stale cache entry for a deleted video meant users would see that video in recommendations or search results even after the owner deleted it. YouTube built explicit invalidation pipelines that would sweep through the cache and remove entries when the underlying data changed.

The other major caching challenge was cold starts. When a Memcached server was restarted or a new server was added to the pool, its cache was empty. All the requests that had been hitting that cache suddenly fell through to the database. If this happened for a large enough portion of the cache simultaneously — after a datacenter event, for example — the sudden flood of database queries could overwhelm the database and cause a cascading failure. YouTube engineers called this a &ldquo;thundering herd&rdquo; and built delays and jitter into cache population logic to smooth the reconstruction.

graph LR
    A[User Request] &#8211;> B[App Server]
    B &#8211;> C{Memcached Hit?}
    C &#8211;>|Yes| D[Return Cached Data]
    C &#8211;>|No| E[Query MySQL Shard]
    E &#8211;> F[Populate Cache]
    F &#8211;> D
    style A fill:#27ae60,color:#fff
    style B fill:#2980b9,color:#fff
    style C fill:#8e44ad,color:#fff
    style D fill:#16a085,color:#fff
    style E fill:#c0392b,color:#fff
    style F fill:#e67e22,color:#fff

## The Video Upload Pipeline

Understanding how a video upload actually works helps illustrate how YouTube kept the database out of the critical path for expensive operations.

When a user initiates an upload, the process looks roughly like this:

A request hits the application tier. A metadata record is inserted into MySQL immediately, with status set to . The video ID generated from this insert is returned to the client. The client uploads the raw video bytes directly to a storage endpoint — not to the application server, and certainly not to MySQL. The storage system acknowledges receipt and enqueues a transcoding job.

graph TD
    A[User Upload Request] &#8211;> B[App Server Creates Metadata Row]
    B &#8211;> C[MySQL Shard Write - Status processing]
    B &#8211;> D[Return video_id to Client]
    D &#8211;> E[Client Uploads Video Bytes to Object Store]
    E &#8211;> F[Object Store Enqueues Transcoding Job]
    F &#8211;> G[Transcoding Workers Process Video]
    G &#8211;> H[Update MySQL - Status active plus storage_keys]
    G &#8211;> I[Generate Thumbnail]
    I &#8211;> H
    style A fill:#27ae60,color:#fff
    style C fill:#c0392b,color:#fff
    style F fill:#8e44ad,color:#fff
    style G fill:#e67e22,color:#fff
    style H fill:#c0392b,color:#fff

The transcoding workers take the raw video and produce multiple quality versions: 240p, 360p, 480p, 720p, 1080p, and eventually 4K. Each version is stored in the object storage system. Once all versions are complete, the worker updates the MySQL record to change the status to  and records the storage keys for each quality level.

This asynchronous, pipeline-based approach means that MySQL is involved at the beginning of the upload (metadata creation) and at the end (status update), but not during the heavy lifting. The actual video bytes never touch MySQL. The transcoding, which is the most computationally expensive part of the process, happens in a separate system that MySQL knows nothing about.

This design also made the system resilient. If a transcoding worker crashed halfway through processing a video, the metadata record was still in MySQL with status . The job could be retried. Nothing was lost.

## The Video Watch Pipeline

Serving a video to a viewer is equally revealing. Consider what happens when you click play on a YouTube video:

The browser makes a request to YouTube's servers. The application needs to do several things: verify the video exists and is public, retrieve the metadata for display (title, description, channel name, view count, like count), fetch recommendations for the sidebar, retrieve top comments, and determine the best CDN endpoint from which to serve the video file.

graph TD
    A[Viewer Clicks Play] &#8211;> B[Load Balancer]
    B &#8211;> C[App Server]
    C &#8211;> D{Metadata in Cache?}
    D &#8211;>|Yes| E[Return from Memcached]
    D &#8211;>|No| F[Query MySQL Shard]
    F &#8211;> G[Populate Memcached]
    G &#8211;> E
    E &#8211;> H[Fetch Recommendations]
    E &#8211;> I[Fetch Comments from Shard]
    E &#8211;> J[Determine CDN Node]
    J &#8211;> K[Stream Video from CDN]
    style A fill:#27ae60,color:#fff
    style C fill:#2980b9,color:#fff
    style D fill:#8e44ad,color:#fff
    style F fill:#c0392b,color:#fff
    style K fill:#16a085,color:#fff

The video metadata and the channel information come from cache wherever possible. The recommendation system, which had its own separate data store and processing infrastructure, returns a list of video IDs. Those video IDs are then resolved to full metadata records, again from cache. The comments are fetched from the appropriate MySQL shard.

The video file itself is served from a CDN — a Content Delivery Network. YouTube built and operated an enormous CDN infrastructure that cached popular video files at edge nodes close to viewers around the world. For a popular video, the file was likely cached at a CDN node a few hundred miles from the viewer, not streaming all the way from a central datacenter. MySQL is completely uninvolved in the actual video delivery. It knows the storage key that points to the file. The CDN knows how to serve the file. These two systems talk to each other only during cache misses at the CDN layer.

## Database Bottlenecks YouTube Encountered

No architecture discussion is complete without an honest accounting of the failures and pain points. YouTube's MySQL infrastructure encountered several categories of problems repeatedly.

Index maintenance was a persistent challenge. Large tables with many indexes meant that every write operation had to update multiple data structures. An insert into the  table might update three or four indexes in addition to writing the row itself. As indexes grew into the hundreds of millions of entries, the I/O cost of maintaining them became a major fraction of write latency. Teams had to be very deliberate about which indexes existed, periodically auditing and removing indexes that were no longer providing sufficient read benefit to justify their write overhead.

Replication lag was a recurring nightmare. At peak upload and engagement times, the binary logs from the primary generated more data than the replicas could apply at full speed. Replication lag would build up over hours, reaching minutes or even tens of minutes. A replica that is ten minutes behind cannot serve reads for anything that happened in the last ten minutes. Engineers would get paged in the middle of the night because replication lag on a critical shard had exceeded their threshold. Resolving it required either reducing write load, speeding up replicas, or both.

Long-running transactions caused lock contention. A query that ran for even a few seconds could hold locks that blocked hundreds of subsequent queries. Schema migrations on hot tables were particularly dangerous — adding a column to the  table on a live system without causing an outage required careful use of tools like , which performs the migration in the background by creating a shadow table and swapping atomically.

 exhaustion was a real problem for tables that had existed since the early days. A  column can hold values up to about 18.4 quintillion, which is comfortably unlimited for any foreseeable use case. But some early columns used , which maxes out at about 4.3 billion. As the platform grew toward billions of rows in some tables, the prospect of wrapping around an integer ID was not hypothetical. Schema migrations to widen ID columns required careful coordination.

  
    
      
        Bottleneck
        Root Cause
        Symptom
        Mitigation
      
    
    
      
        Write hotspot on view_count
        Millions of concurrent increments to a single row
        High lock wait time; slow writes
        Counter sharding; async batch updates; approximate counts
      
      
        Index bloat
        Many indexes on large tables
        Slow inserts and updates; high disk I/O
        Index audits; deferred indexing; covering indexes
      
      
        Replication lag
        Writes outpace replica apply speed
        Stale reads; replica unusable; pages at night
        More replicas; multi-threaded replication; reduce write amplification
      
      
        Schema migrations
        ALTER TABLE locks the table
        Seconds-long outages; write queue backup
        pt-online-schema-change; blue-green deploys
      
      
        Cross-shard joins
        Related data on different shards
        Complex application code; multi-shard queries
        Denormalization; application-layer joins; data locality design
      
      
        INT ID overflow
        4-byte ID approaching max value
        Silent corruption risk; insert failures
        Migrate to BIGINT; monitor high watermarks
      
    
  

## Event-Driven Architecture Evolution

As YouTube matured, the team recognized that not every write needed to be synchronous. When a user subscribed to a channel, the subscription row needed to be written immediately — but the notification to the channel owner, the feed update, the recommendation model update, and the analytics counter increment did not. These could be processed asynchronously.

This insight led YouTube toward an event-driven architecture. When a significant action occurred — a video upload, a subscription, a like — the application would publish an event to a message queue. Background workers would consume those events and carry out the downstream effects. This reduced the amount of work that each user-facing request had to do synchronously, which reduced latency. It also reduced the write amplification on MySQL — instead of updating five tables in a single transaction, you wrote one event to a queue and let workers handle the rest.

The message queue acted as a buffer. If the downstream workers fell behind, events queued up harmlessly. When the workers caught up, the queue drained. The user experience was slightly eventually consistent — your subscription notification might arrive a few seconds late — but this was a perfectly acceptable tradeoff.

This pattern eventually evolved into systems that closely resembled what is now commonly done with Apache Kafka: durable, distributed, append-only logs that allowed multiple consumers to read the same stream of events independently. Recommendation systems, analytics pipelines, notification systems, and feed generators could all consume the same event stream at their own pace.

The evolution toward event-driven architecture also reduced the coupling between systems. Before, updating the recommendations required a direct write to the recommendation database as part of the same transaction as the subscription write. After, the recommendation system just consumed subscription events from the queue and updated its own data store independently. This made each system easier to change, easier to operate, and easier to scale independently.

## Database Schema Design Lessons

The practical lessons from YouTube's schema evolution are worth cataloguing explicitly, because they recur in every system that grows from startup to scale.

Denormalization is not a dirty word. Normalized schemas are beautiful in textbooks because every piece of information lives in exactly one place. At scale, this means every read that needs multiple pieces of information requires joins, and joins at scale are expensive. YouTube gradually denormalized hot data — storing the uploader's username in the  table alongside the , for example, so that the video list page did not need to join against the  table for every row in the results. The tradeoff: when a user changed their username, two tables needed to be updated. At the scale of video views versus username changes, this was the right tradeoff.

Partitioning extends table capacity. MySQL's table partitioning feature allows a single logical table to be physically split into multiple files based on a column value. A  table partitioned by  month means that old comments live in separate physical partitions that can be archived, compressed, or dropped independently of recent comments. Queries that only need recent comments can be scoped to the relevant partitions, dramatically reducing the amount of data scanned.

Covering indexes eliminate table row fetches. An index that includes all the columns needed by a query allows MySQL to satisfy the query entirely from the index without touching the table data. For queries that read many rows but only need a few columns — like fetching the  and  for all videos by a user — a covering index on  can be dramatically faster than a non-covering index that forces a row lookup for each result.

Approximate counts are good enough. Updating  on every view is expensive. But users do not actually need the view count to be exact to the second. YouTube moved to approximate counting — updating counters in batches, using probabilistic data structures like HyperLogLog for unique visitor counts, and displaying rounded numbers (&ldquo;2.3 million views&rdquo;) rather than exact figures. This reduced write amplification enormously while preserving the user-facing feature.

## Scalability Deep Dive

It is worth mapping the scaling journey explicitly against the techniques deployed, because this sequence — vertical scaling, read replicas, caching, sharding — is the canonical path for any database that needs to grow from small to internet-scale.

  
    
      
        Phase
        Approximate Scale
        Primary Technique
        Key Constraint It Solved
        New Problems Introduced
      
    
    
      
        Launch
        Single-digit thousands of users
        Single MySQL server
        Simplicity and speed to market
        None yet
      
      
        Early growth
        Millions of users
        Vertical scaling (bigger server)
        Outgrown initial hardware
        Single point of failure; hardware ceiling approaching
      
      
        Hyper-growth
        Tens of millions of users
        Read replicas + Memcached
        Read saturation of single server
        Replication lag; cache invalidation complexity
      
      
        Post-acquisition scale-out
        Hundreds of millions of users
        User-based sharding
        Write saturation of single primary
        Cross-shard queries; resharding complexity
      
      
        Internet scale
        Billions of users
        Deeper sharding + event-driven + specialized stores
        Global scale; diverse workload types
        Operational complexity; polyglot persistence
      
    
  

One important nuance: these phases were not cleanly sequential. YouTube was deploying read replicas while still running on a single shard. They were deploying sharding while still investing in caching improvements. Real systems evolve in parallel, with multiple scaling efforts running simultaneously, each addressing a different bottleneck.

The vertical scaling phase deserves particular attention because it is often dismissed too quickly. Upgrading your database server from 32GB RAM to 256GB RAM, or from spinning disks to fast NVMe SSDs, can buy you months or years of additional runway without any code changes. That runway is valuable. It buys you time to implement the more complex solutions correctly, rather than under emergency pressure.

The danger of vertical scaling is that it creates a false sense of security. It works, and it works well — right up until it stops working. At that point, if you have not been investing in horizontal scaling capabilities, you face a crisis. The best-run teams treat vertical scaling as one tool among several, not as the final answer.

## Reliability and Disaster Recovery

Scaling is about handling more traffic. Reliability is about not losing data or availability when things go wrong. These are related but distinct engineering concerns, and YouTube had to address both.

Backups at MySQL scale are genuinely hard. Logical backups () produce a consistent snapshot by locking tables or using InnoDB's MVCC — but at large scale, they are slow to produce and slow to restore. Physical backups (copying the underlying InnoDB data files, using tools like Percona XtraBackup) are faster for both creation and restore, but require careful coordination to ensure consistency.

YouTube maintained backups at multiple levels: recent backups for rapid recovery, older backups for recovery from silent corruption, and backups replicated to geographically separate locations for disaster recovery. The operational discipline of regularly testing restores — not just taking backups, but actually restoring from them and verifying the data — was essential. A backup you have never restored is a backup you do not actually have.

Multi-region architecture required solving the replication problem at geographic scale. Replicating data across continents introduces hundreds of milliseconds of round-trip latency, which means even semi-synchronous replication becomes impractical as a primary consistency mechanism. YouTube's approach was to replicate asynchronously to remote regions and accept that the remote region's data was slightly behind. In a disaster recovery scenario, this meant some recent data might be lost. The amount of acceptable data loss, measured in time, is called the Recovery Point Objective (RPO). YouTube had to be explicit about its RPO and build infrastructure that met it.

## MySQL vs NoSQL: An Honest Comparison

As YouTube scaled, the question inevitably arose: should they replace MySQL with something better suited to internet-scale workloads? The NoSQL movement was gaining momentum. Cassandra, MongoDB, HBase, and other systems promised horizontal scalability without the complexity of manual sharding.

The answer YouTube's engineers arrived at was nuanced, and it is worth unpacking.

  
    
      
        System
        Data Model
        Horizontal Scale
        Consistency
        Query Flexibility
        Operational Maturity (circa 2008)
      
    
    
      
        MySQL (sharded)
        Relational; tables, rows, joins
        Manual sharding; significant engineering
        Strong within shard; eventual across shards
        High; full SQL
        Excellent; huge community
      
      
        Cassandra
        Wide-column; partition key plus clustering
        Native; designed for horizontal scale
        Tunable; typically eventual
        Limited; partition-key lookups optimized
        Poor; very new in 2008
      
      
        Bigtable / HBase
        Wide-column; row key plus column families
        Native; scales to petabytes
        Row-level strong consistency
        Limited; no secondary indexes natively
        Google-internal only until HBase emerged
      
      
        Dynamo-style (DynamoDB, Riak)
        Key-value; simple get/put by key
        Native; masterless, highly available
        Eventual; last-write-wins
        Very limited; key-only lookups
        Amazon's Dynamo paper published 2007; not public
      
      
        MongoDB
        Document; JSON-like BSON documents
        Sharding available but limited early on
        Document-level strong consistency
        Moderate; rich query operators
        First release 2009; very immature initially
      
    
  

The key insight is that YouTube's engineers already had MySQL running in production, serving billions of requests per day, with a team that deeply understood its behavior. Migrating to an unproven system at that scale, under that traffic, carried enormous risk. A NoSQL system that could not be operated reliably in production was worse than a SQL system that required careful engineering to scale.

Over time, YouTube did introduce specialized stores for specific use cases. For time-series data (analytics, viewing history), systems closer to Bigtable or columnar databases were better fits. For the recommendation graph, graph databases or custom graph processing systems were more appropriate. For globally distributed, low-latency key-value access, Memcached's successor systems and eventually Spanner-like distributed databases became the right choice.

Could YouTube be built on MySQL today? Yes, with the same sharding and caching strategies they used. But a greenfield YouTube built today would likely use MySQL for its core metadata, Cassandra or DynamoDB for high-write, high-scale supplementary data (view events, engagement metrics), and Spanner or CockroachDB for globally consistent metadata. The architecture would be polyglot from the start, using the right tool for each data access pattern, rather than stretching a single system to cover all use cases.

## Engineering Tradeoffs

Every architectural decision in YouTube's history involved giving something up to get something else. Being explicit about these tradeoffs is what separates senior engineering thinking from junior thinking.

Consistency versus availability: sharded MySQL with asynchronous replication chose availability over strong consistency. When a replica fell behind, reads from that replica returned stale data rather than blocking until the replica caught up. Users occasionally saw inconsistent state. This was acceptable because the alternative — blocking user requests until replication caught up — would have made the product unusably slow during any replication lag event.

Normalization versus performance: normalized schemas are correct and compact. Denormalized schemas are faster for reads at the cost of write complexity and storage. YouTube moved steadily toward denormalization as read performance became the dominant concern. Every denormalization decision was a bet that the read traffic savings would outweigh the write complexity and the risk of inconsistency between the canonical record and its denormalized copies.

Engineering simplicity versus operational efficiency: a single MySQL instance is simple to operate and simple to reason about. A sharded MySQL topology with hundreds of shards, each with a primary and multiple replicas, is a complex operational environment. You gain write scalability at the cost of operational complexity. The team that operates this system needs more expertise, better tooling, and more rigorous processes. This cost is real, and it should not be underestimated when making architectural decisions.

Caching versus freshness: every cached entry represents a promise that you will tolerate serving potentially stale data. The longer the TTL, the lower the database load, but the more out-of-date the served data might be. YouTube tuned cache TTLs differently for different types of data. View counts, which change constantly and are tolerant of some staleness, could have short TTLs or be served from approximate in-memory counters. User profile data, which changes rarely but where staleness is more visible to users, warranted more careful invalidation.

## What Modern Engineers Can Learn

The YouTube MySQL story is not just history. The patterns and antipatterns it illustrates are directly applicable to the systems being built today.

Start simple and add complexity when you hit actual bottlenecks. YouTube used a single MySQL server at launch because that was the right tool for the scale. Engineers who design for billions of users before they have thousands are wasting time and creating operational complexity that slows them down. The art is in knowing when the current architecture is genuinely at its limit, not when it looks inelegant.

Separate your data by access pattern. Video files and video metadata have fundamentally different access characteristics. Binary content belongs in object storage. Metadata belongs in a relational database. Time-series events belong in a columnar or time-series store. When you force all data types into one system, you end up with a system that handles all of them poorly.

Caching is a first-class architectural citizen, not an optimization. The YouTube architecture without Memcached would have required many times more database servers to serve the same traffic. Plan your caching layer from early in your architecture, not as an afterthought when the database starts struggling.

Understand your write patterns before they hurt you. The  hotspot was a predictable problem — any counter that gets incremented by millions of concurrent users will encounter write contention. Identifying these patterns early and designing around them (batch updates, approximate counts, counter sharding) is far less painful than fixing them in production.

Build operational tooling as a core competency. Failover automation, replication monitoring, schema migration tools, resharding scripts — these are not nice-to-haves. They are what makes the difference between an architecture that works in theory and one that works in production at three in the morning when something goes wrong.

## System Design Interview Perspective

YouTube's database architecture is a favorite subject for system design interviews, and for good reason: it covers the full stack of database scaling techniques in a context that most candidates are familiar with.

When an interviewer asks you to design YouTube, the weak answer focuses immediately on which database to use. The strong answer starts by understanding the access patterns, data types, and scale requirements before making any technology choices.

Start by clarifying the data: what kinds of data does the system need to store, how large is each entity, how frequently is it read versus written, and what consistency guarantees are actually required? Establish a rough sense of scale: how many users, how many daily active users, how many video uploads per minute, how many view events per second.

Then work through the tiers of the architecture. Start with what goes in a relational database (user metadata, video metadata, subscription records, comment records) versus what goes elsewhere (the video files themselves in object storage, view event streams in a time-series or stream processing system, recommendation data in a specialized graph or ML store).

Discuss read replicas as the first scaling move. Explain why they help (read distribution) and where they fall short (no help for writes). Discuss caching as a complementary mechanism that dramatically reduces database load. Explain cache invalidation and the tradeoffs around cache TTLs.

When the interviewer asks how you would handle ten times or a hundred times more traffic, introduce sharding. Be specific about your sharding key (user ID is typically the right choice for YouTube-like data because it keeps related data co-located). Discuss the tradeoffs: cross-shard queries become hard, resharding is expensive, the routing layer adds complexity.

Common mistakes candidates make: jumping to Cassandra or DynamoDB without justifying why MySQL is insufficient, ignoring the separation between metadata and media storage, forgetting about the CDN for actual video delivery, and treating caching as an optional optimization rather than a core architectural component.

The strongest candidates discuss not just the happy path but the failure modes: what happens when a shard's primary fails, how you handle replication lag, how you monitor and alert on database health, and how you perform schema migrations without downtime. These operational considerations signal that you understand production systems, not just theoretical ones.

## Conclusion

YouTube's story is ultimately a story about pragmatism. The engineers who built YouTube did not have a crystal ball that told them they were building one of the largest platforms in internet history. They had a LAMP stack, a growing user base, and a set of very smart people who understood their tools deeply enough to push them far beyond their apparent limits.

MySQL was not the wrong choice. It was the right choice for the right reasons, scaled through the right techniques. Read replicas, sharding, aggressive caching, careful schema design, event-driven architecture — none of these are exotic techniques. They are the discipline of understanding a system deeply enough to know when and how to extend it.

The lesson is not &ldquo;use MySQL for everything.&rdquo; The lesson is &ldquo;understand your data, understand your access patterns, scale the bottleneck in front of you, and do not add complexity before you need it.&rdquo; That discipline applies regardless of whether your database is MySQL, Postgres, Cassandra, or anything else.

The engineers who built YouTube's infrastructure were not doing magic. They were doing engineering. And that is exactly what makes their work worth studying.
