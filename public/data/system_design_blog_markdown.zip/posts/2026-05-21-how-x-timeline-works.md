---
title: "How X Timeline Works?"
date: "2026-05-21T08:23:07+05:30"
slug: "how-x-timeline-works"
categories: ["system_design", "architecture", "x", "technology", "social_media"]
original_url: "https://rishijeet.github.io/blog/how-x-timeline-works/"
word_count: 6620
reading_time: "33 min"
author: "Rishijeet Mishra"
---

# How X Timeline Works?

*Published on 2026-05-21 by Rishijeet Mishra | [https://rishijeet.github.io/blog/how-x-timeline-works/](https://rishijeet.github.io/blog/how-x-timeline-works/)*

> There is a moment, every time you open X, that feels effortless. A feed of tweets appears. Some are from people you follow. Others are from accounts you have never seen before but somehow feel relevant. A viral post catches your eye. A trending topic surfaces at just the right time. It all feels instant.

![Alt text](https://rishijeet.github.io/images/system_design/x-banner.jpeg)

Behind every timeline refresh is a chain of distributed systems doing extraordinary amounts of work in milliseconds. Machines are computing your interests, traversing social graphs with hundreds of millions of edges, fetching precomputed timelines from tiered caches, ranking thousands of candidate tweets using machine learning models, and delivering the result before your thumb stops scrolling. At peak traffic, X handles hundreds of millions of active users simultaneously, each expecting their own personalized, fresh, low-latency feed.

Understanding how this actually works is one of the richest system design problems in modern software engineering. It touches distributed databases, event streaming, ML-based ranking, graph traversal, cache design, and real-time data pipelines all at once.

This post walks through the full architecture from first principles. Whether you are preparing for a system design interview or simply want to understand how large-scale social media infrastructure is built, this is the engineering deep dive you have been looking for.

## Core Features of the X Timeline

Before jumping into architecture, it is worth being precise about what the timeline actually is. X has two primary feed surfaces.

The Following tab shows tweets from accounts you explicitly follow, sorted by relevance and recency. The For You tab, which is the default, is a fully personalized algorithmic feed. It pulls in tweets from accounts you follow, accounts you interact with, accounts that are popular in your network, trending content, and content from accounts you do not follow but that the recommendation engine believes you will engage with.

Beyond those two main feeds, the system has to handle retweets, which propagate content across the social graph in unpredictable ways. Quote tweets add commentary on top of existing content. Replies create threaded conversations. Likes and retweet counts need to be updated in near real-time and reflected in rankings. Media tweets with images and videos require separate processing pipelines. And all of this has to work while the platform is receiving millions of new tweets per hour.

The scale here is not just large, it is adversarially large. Celebrity accounts like those of major pop stars or politicians can have 50 to 100 million followers. When they tweet, the system needs to propagate that tweet to an enormous number of timelines, all without degrading the experience for everyone else.

## High-Level Timeline Architecture

The best way to understand the architecture is to trace the lifecycle of a single tweet from creation to appearing in someone's timeline.

When a user posts a tweet, the request hits a load-balanced API gateway. The gateway authenticates the request, validates the payload, and routes it to the Tweet Ingestion Service. The ingestion service runs validation, spam detection, and media processing in parallel before persisting the tweet to a distributed storage layer and then triggering the Fanout Service.

The fanout service's job is to figure out who should see this tweet and how to get it into their feeds. For users with a moderate number of followers, it precomputes the timeline updates and pushes the tweet ID into each follower's timeline cache. For celebrity accounts, it uses a different strategy, which we will cover in detail shortly.

When a user opens their app and pulls their feed, the Timeline Service assembles a ranked list of tweets. It fetches precomputed timeline entries from cache, may augment with real-time recommendations, and then passes the candidates through a ranking pipeline. The ranked output is returned to the client through the API gateway.

flowchart TD;
  A[Mobile or Web Client];
  B[API Gateway];
  C[Tweet Ingestion Service];
  D[Fanout Service];
  E[Timeline Service];
  F[Ranking Service];
  G[Recommendation Engine];
  H[Timeline Cache];
  I[Tweet Store];
  J[Graph Service];
  K[Notification Service];
  A &#8211;>|POST tweet| B;
  B &#8211;> C;
  C &#8211;> I;
  C &#8211;> D;
  D &#8211;> J;
  D &#8211;> H;
  A &#8211;>|GET timeline| B;
  B &#8211;> E;
  E &#8211;> H;
  E &#8211;> G;
  E &#8211;> F;
  F &#8211;> A;
  D &#8211;> K;
  classDef client fill:#2563eb,stroke:#1e40af,color:#ffffff;
  classDef service fill:#16a34a,stroke:#166534,color:#ffffff;
  classDef storage fill:#9333ea,stroke:#6b21a8,color:#ffffff;
  classDef queue fill:#f59e0b,stroke:#b45309,color:#ffffff;
  class A client;
  class B,C,D,E,F,G,J,K service;
  class H,I storage;

Every box in that diagram hides enormous complexity. Let us go through each one.

## Tweet Ingestion Pipeline

When a tweet is submitted, the very first thing the system needs to do is make the write safe. That means idempotent handling. If the mobile client retries because of a network timeout, you do not want the tweet to be stored twice. The ingestion service assigns a unique request ID at the API gateway layer and uses it to deduplicate retries.

The tweet then goes through a validation layer. Is the content within character limits? Are the media attachments within size restrictions? Is the user's account in good standing? These are synchronous checks that can fail fast.

Media processing is asynchronous. If the tweet includes an image or video, the ingestion service stores the raw media in object storage and drops a processing job into a queue. A separate media pipeline handles transcoding, thumbnail generation, CDN distribution, and content analysis in parallel with the rest of the tweet lifecycle. The tweet is persisted with a reference to the media, even before media processing is complete, and the client polls or receives a push notification when the media is ready.

Spam detection is a mix of synchronous and asynchronous signals. Synchronous rule-based checks can catch obvious spam patterns immediately, such as known malicious URLs or behavioral patterns like rapid-fire posting. More sophisticated ML-based spam detection runs asynchronously and can retroactively suppress a tweet that initially passed synchronous checks.

Once the tweet passes validation and is persisted, the ingestion service publishes a tweet creation event to an internal event streaming system. This event is the trigger for fanout, notifications, search indexing, and analytics processing, all happening in parallel via separate consumers.

flowchart TD;
  A[User Client];
  B[API Gateway];
  C[Idempotency Check];
  D[Validation Layer];
  E[Spam Detection Sync];
  F[Tweet Persistence];
  G[Event Stream];
  H[Fanout Consumer];
  I[Search Indexer];
  J[Notification Consumer];
  K[Media Processor];
  L[Spam Detection Async];
  A &#8211;> B;
  B &#8211;> C;
  C &#8211;> D;
  D &#8211;> E;
  E &#8211;> F;
  F &#8211;> G;
  G &#8211;> H;
  G &#8211;> I;
  G &#8211;> J;
  G &#8211;> K;
  G &#8211;> L;
  classDef client fill:#2563eb,stroke:#1e40af,color:#ffffff;
  classDef service fill:#16a34a,stroke:#166534,color:#ffffff;
  classDef storage fill:#9333ea,stroke:#6b21a8,color:#ffffff;
  classDef queue fill:#f59e0b,stroke:#b45309,color:#ffffff;
  class A client;
  class B,C,D,E,H,I,J,K,L service;
  class F storage;
  class G queue;

The persistence layer itself is interesting. Tweets are stored in a distributed key-value store partitioned by tweet ID. The tweet ID encodes a timestamp in its upper bits, which naturally sorts tweets by time within a partition and makes range queries on recent tweets efficient. X uses a custom storage system called Manhattan for this, though the principles apply to any distributed store like Cassandra.

## Fanout System Deep Dive

Fanout is the process of taking a single new tweet and pushing it into the timelines of all its author's followers. This is where the architecture has to make its first major tradeoff.

There are two pure approaches: fanout on write and fanout on read.

With fanout on write, when a tweet is posted, the system immediately writes the tweet ID into every follower's timeline cache. When those followers later open their apps, their timelines are already materialized and can be served instantly from cache. The downside is write amplification: a user with a million followers requires a million cache writes for every single tweet.

With fanout on read, the system does nothing at write time. When a user opens their app, the timeline service fetches the list of all accounts the user follows and then queries for recent tweets from each of them. The timeline is assembled on the fly. The advantage is no write amplification. The severe disadvantage is that fetching from hundreds or thousands of accounts at read time is extremely slow and creates massive read pressure on the tweet store.

  
    
      
        Property
        Fanout on Write
        Fanout on Read
        Hybrid
      
    
    
      
        Write cost
        High (amplified by follower count)
        Very low
        Moderate
      
      
        Read latency
        Very low (precomputed)
        High (assembled on demand)
        Low
      
      
        Celebrity problem
        Severe (millions of writes)
        No write issue
        Handled separately
      
      
        Cache pressure
        High but predictable
        Low on write, high on read
        Balanced
      
      
        Freshness
        Slightly delayed
        Always fresh
        Near-real-time
      
      
        Best for
        Normal accounts
        Never used purely in production
        Production systems
      
    
  

X uses a hybrid model, and understanding why is one of the most instructive engineering lessons in this entire domain.

For accounts with a moderate follower count, say under 10,000, the system uses fanout on write. When they tweet, their tweet ID is written into each follower's timeline cache entry asynchronously. This is fast, parallelizable, and the write amplification is manageable.

For celebrity accounts with millions of followers, fanout on write would create catastrophic write storms. Imagine Elon Musk tweeting and the system attempting to write to 100 million cache entries simultaneously. This would cause latency spikes, overwhelm the cache infrastructure, and delay timeline freshness for everyone.

The solution is elegant: celebrity tweets are not precomputed. Instead, when a follower opens their timeline, the timeline service performs a partial fanout on read specifically for celebrity accounts they follow. It fetches recent tweets from those few high-follower accounts directly from the tweet store at read time and merges them into the precomputed timeline.

This hybrid strategy allows X to handle the long tail of normal accounts efficiently through precomputation while gracefully handling the celebrity problem by treating a small number of high-influence accounts differently at read time.

The fanout workers themselves are distributed consumers reading from the event stream. They process tweet creation events and, for eligible accounts, read the follower list from the graph service and write the tweet ID into each follower's timeline cache. These workers are scaled horizontally and process fan-outs in parallel.

One subtle but important detail: the fanout writes tweet IDs, not tweet content. Timeline cache entries are just ordered lists of tweet IDs. The actual tweet content is fetched separately via a tweet cache when the timeline is rendered. This decouples storage concerns, keeps cache entries small, and means that if a tweet is edited or deleted, you do not need to invalidate thousands of timeline cache entries, just the tweet's own cache entry.

## Timeline Generation System

When a user refreshes their feed, the Timeline Service has to produce a ranked, personalized list of tweets in under 100 milliseconds. Here is what happens in that window.

First, the service fetches the precomputed timeline from the user's timeline cache. This is an ordered list of tweet IDs assembled by the fanout system. Typically, the timeline cache holds the most recent 800 to 1500 tweet IDs for a user.

Second, the service fetches recent tweets from high-follower accounts the user follows, using the fanout on read path for those celebrities.

Third, the recommendation engine is consulted. It injects additional tweet candidates from accounts outside the user's following graph, content that the ML system predicts the user will engage with.

These three sources are merged and deduplicated. Deduplication matters because a tweet might appear both in the precomputed timeline (because the user follows the author) and in the recommendation set (because it is trending in their interest graph).

The merged candidate set, which might be several hundred tweets, is then passed to the ranking pipeline. The ranking model scores each candidate and returns a final ordered list. The top tweets are returned to the client.

flowchart TD;
  A[Timeline Request];
  B[Precomputed Timeline Cache];
  C[Celebrity Fanout on Read];
  D[Recommendation Engine];
  E[Merge and Deduplicate];
  F[Ranking Pipeline];
  G[Ranked Timeline Response];
  A &#8211;> B;
  A &#8211;> C;
  A &#8211;> D;
  B &#8211;> E;
  C &#8211;> E;
  D &#8211;> E;
  E &#8211;> F;
  F &#8211;> G;
  classDef client fill:#2563eb,stroke:#1e40af,color:#ffffff;
  classDef service fill:#16a34a,stroke:#166534,color:#ffffff;
  classDef storage fill:#9333ea,stroke:#6b21a8,color:#ffffff;
  class A client;
  class B,C storage;
  class D,E,F service;
  class G client;

The latency budget here is tight. Fetching from cache takes under 5 milliseconds. Celebrity fanout on read might take 20 to 40 milliseconds depending on how many celebrity accounts a user follows. The ranking pipeline has to fit into whatever time remains. This is why ranking models are heavily optimized and often run as batched inference calls rather than sequential ones.

The freshness versus quality tradeoff is real. A more powerful ranking model produces better personalization but takes longer to run. Systems like X use approximate nearest-neighbor algorithms, pre-computed user embeddings, and model distillation to make the inference fast enough that users perceive their feed as essentially instant.

## Ranking and Recommendation Systems

The ranking system is where the X timeline gets genuinely interesting from an ML perspective. Let us separate two things: the Following tab and the For You tab.

The Following tab is ranked by relevance within the set of accounts the user follows. It is not purely chronological. The ranking model boosts tweets with high engagement from people in your network, gives a slight boost to accounts you interact with frequently, and considers tweet freshness. It also filters content you have already seen on a previous session.

The For You tab is a full recommendation problem. The system needs to surface content from outside your following graph that you might engage with. This involves collaborative filtering (users with similar engagement histories to yours liked content X, so you might like it too), interest-based embeddings (content that matches your known interests), and engagement prediction models that estimate the probability you will like, retweet, or linger on a given tweet.

The ranking pipeline works in multiple stages. A first stage, called candidate retrieval, produces a set of potentially thousands of candidates from the various sources described above. This stage uses approximate techniques and is designed for high recall, not precision. The goal is to not miss anything good.

A second, heavier stage, called ranking, scores each candidate more precisely using a deep learning model. This model takes as input features about the tweet (content, author, age, engagement counts), features about the user (interests, past engagement, account characteristics), and interaction features (does this author frequently engage with this user, how similar is this content to what the user typically engages with). The output is a set of predicted engagement probabilities.

flowchart TD;
  A[Candidate Sources];
  B[Following Graph Tweets];
  C[Interest Graph Tweets];
  D[Trending Content];
  E[Candidate Retrieval Pool];
  F[Light Scoring Pass];
  G[Deep Ranking Model];
  H[Diversity Filter];
  I[Served Timeline];
  A &#8211;> B;
  A &#8211;> C;
  A &#8211;> D;
  B &#8211;> E;
  C &#8211;> E;
  D &#8211;> E;
  E &#8211;> F;
  F &#8211;> G;
  G &#8211;> H;
  H &#8211;> I;
  classDef client fill:#2563eb,stroke:#1e40af,color:#ffffff;
  classDef service fill:#16a34a,stroke:#166534,color:#ffffff;
  classDef storage fill:#9333ea,stroke:#6b21a8,color:#ffffff;
  classDef queue fill:#f59e0b,stroke:#b45309,color:#ffffff;
  class A,B,C,D storage;
  class E,F,G,H service;
  class I client;

The ranking model does not just predict likes. X's publicly shared information about its recommendation system mentions that it predicts multiple engagement types: likes, retweets, replies, profile clicks, link clicks, and dwell time. Dwell time, the amount of time a user spends looking at a tweet before scrolling past, is a particularly powerful signal because it captures interest that was not expressed through an explicit action.

The final ranking score is a weighted combination of these predicted probabilities. The weights are tuned through experiments. Boosting the weight of dwell time increases time-on-platform. Boosting the weight of retweet predictions surfaces more viral content. These are product decisions that get expressed through the ranking model's objective function.

There is also a diversity component to the ranking. If the top 20 candidates by raw score are all from the same three accounts, the timeline would feel monotonous. A diversity filter re-ranks the final list to ensure a mix of authors, topics, and content types, even if it slightly sacrifices raw predicted engagement.

The exploration-exploitation tradeoff is also live in the For You feed. Some fraction of shown content is intentionally from accounts or topics the user has not interacted with before. This allows the system to discover new interests and avoid the filter bubble problem where users only see more of what they already like.

  
    
      
        Signal Type
        What It Measures
        Used In
        Latency Sensitivity
      
    
    
      
        Like prediction
        Explicit positive engagement
        All ranking stages
        Low (can be precomputed)
      
      
        Retweet prediction
        Willingness to endorse/share
        Virality scoring
        Low
      
      
        Reply prediction
        High-intent engagement
        Conversation boosting
        Moderate
      
      
        Dwell time
        Passive interest signal
        For You ranking
        High (near-real-time)
      
      
        Profile click
        Author interest
        Author affinity scoring
        Moderate
      
      
        Negative feedback
        See fewer like this
        Filter and suppress
        Immediate
      
    
  

## Social Graph Infrastructure

The social graph, who follows whom, is the foundation of everything. Without it, fanout cannot work, recommendation systems cannot find relevant accounts, and the Following tab cannot be assembled.

At X's scale, the follower graph has hundreds of millions of nodes and billions of edges. Storing this in a traditional relational database does not work. The query patterns needed for timeline generation require traversing the graph in ways that are unnatural for row-oriented storage.

The graph is stored as adjacency lists partitioned across many machines. Each user has a following list (accounts they follow) and a follower list (accounts that follow them). These are stored separately, because the access patterns are different. Fanout reads the follower list of the tweet's author. Timeline generation reads the following list of the user whose timeline is being assembled.

The hot-path operations on the graph need to be extremely fast. The system caches the most-accessed follower lists and following lists in a dedicated graph cache layer, typically Redis or a similar in-memory store. Cold lists, those for accounts with very few followers or that have not been accessed recently, are served from the persistent store.

Mutual follow detection (does this user also follow back?) is a common operation for features like showing reply threads from mutual connections. This is handled by a separate bidirectional graph index.

The interest graph is a derived structure. It captures not just explicit follows but inferred interests based on interaction patterns. If a user consistently likes tweets from a set of sports accounts without formally following them all, the interest graph captures that signal. This graph is maintained asynchronously by a separate pipeline that processes engagement events.

## Real-Time Feed Updates

When you are actively using X and someone you follow posts a tweet, it should appear in your feed quickly. This is the real-time update problem, distinct from the batch timeline generation described above.

X uses a push-based real-time update system for clients that are actively connected. When the fanout service writes to a user's timeline cache, it can also publish a push event to any active client sessions for that user. On mobile, this might come through APNs or FCM notifications. In the web client, it might arrive via a WebSocket connection.

However, pushing every single tweet update to every active session in real time creates enormous infrastructure pressure. The system has to maintain state about which users are currently active and route the push events accordingly. The practical approach is to use real-time pushes for the most time-sensitive signals (direct mentions, direct messages) and rely on periodic polling or pull-on-scroll for general timeline updates.

The streaming API, used by third-party developers, exposes a subset of this real-time event stream. It filters the public tweet firehose based on specified parameters and delivers matching tweets via a persistent HTTP stream. This is a separate serving path from the consumer timeline.

## Caching System Deep Dive

Caching is not a performance optimization at X's scale, it is a survival mechanism. Without aggressive caching, the databases would collapse under read pressure instantly.

The caching architecture has several distinct layers.

The timeline cache holds precomputed ordered lists of tweet IDs for each user's home timeline. It is the most frequently accessed cache in the system. The data structure is typically a sorted list or set keyed by user ID. When the fanout service pushes new tweets, it prepends the tweet IDs to the user's timeline list. When the timeline service fetches, it reads from the head of the list. When the list exceeds a maximum size, old entries are evicted from the tail.

The tweet cache holds tweet objects keyed by tweet ID. When the timeline service fetches a list of tweet IDs, it hydrates them by looking up the full tweet objects from this cache. Most tweets are fetched from cache, not from the tweet store. For viral tweets that appear in millions of timelines, this cache absorbs an enormous amount of read pressure that would otherwise hit the database.

The user cache holds user profile information (username, avatar, verification status) needed to render a timeline. This is separate from the tweet cache because profile data changes much less frequently than tweet data.

The graph cache holds frequently accessed follower and following lists. As discussed, the most popular accounts' follower lists are kept in memory because fanout workers access them constantly.

  
    
      
        Cache Layer
        Data Stored
        Read Frequency
        Write Frequency
        TTL Strategy
      
    
    
      
        Timeline cache
        Ordered tweet ID lists per user
        Very high
        High (fanout writes)
        LRU eviction, no TTL
      
      
        Tweet cache
        Tweet objects by tweet ID
        Extremely high
        Low (only on create/edit)
        Hours to days
      
      
        User cache
        Profile data by user ID
        High
        Very low
        Minutes to hours
      
      
        Graph cache
        Follower/following lists
        High (fanout reads)
        Low (follow/unfollow)
        Minutes, LRU for cold
      
      
        Recommendation cache
        Precomputed recommendation sets
        Moderate
        Batch (periodic recompute)
        Minutes to hours
      
    
  

Celebrity traffic spikes present a specific caching challenge. When a major celebrity posts something controversial, millions of users simultaneously try to view that tweet, its replies, and the author's profile. This creates a hotspot in the tweet cache, where a small number of keys receive an enormous fraction of total read traffic.

The standard solution is local caching at the application layer. The timeline service instances maintain a small in-process cache of the most recently accessed tweet objects. This absorbs the hotspot traffic without it ever reaching the distributed cache cluster. The tradeoff is slightly stale data (the in-process cache might be a few seconds behind), which is generally acceptable for tweet content.

## Search and Trending Systems

The trending system requires real-time aggregation of activity across the entire platform. It needs to identify topics and hashtags that are being mentioned at an elevated rate compared to their historical baseline.

This is a stream processing problem. The tweet ingestion pipeline publishes tweet content to a stream processor. The processor maintains rolling count windows for hashtags, keywords, and mentions. When the count for a term exceeds a threshold relative to its baseline, it is elevated to the trending system, which scores it, filters for quality, and publishes it to the trending API.

Geo-specific trends are produced by partitioning the stream by user location. The same infrastructure runs in parallel for different geographic windows: global, national, and city-level trends all use the same pattern at different granularities.

The search index is built separately from the trending system. Full-text search requires an inverted index mapping terms to tweet IDs. At X's write volume, building this index in real time is a significant engineering challenge. The approach is a combination of real-time indexing for recent tweets, where freshness matters most, and batch indexing for older content.

Elasticsearch or similar search systems manage the inverted index, partitioned by time ranges. The most recent tweets get the most indexing resources since users most often search for current events.

## Notification Infrastructure

Notification systems are a classic fan-out problem with a time-sensitivity constraint. When someone likes your tweet, you want to know quickly but it is not the end of the world if it takes a few seconds. When someone mentions you, it is more time-sensitive. Direct messages need to be nearly real-time.

These different urgency levels map to different delivery paths. The notification pipeline reads from the engagement event stream. A consumer processes like events and generates a notification task. The task includes the notification type, the recipient user ID, the actor user ID, and relevant context (which tweet was liked).

The notification delivery service routes these tasks through a priority queue based on urgency. High-priority notifications (mentions, follows, DMs) are processed immediately. Lower-priority notifications (likes, retweet counts) are batched and rate-limited per user to avoid flooding a recipient with dozens of rapid-fire notifications if a tweet goes viral.

Push notifications are delivered through platform-specific systems: APNs for iOS, FCM for Android, and web push for the browser. The delivery service maintains device token registrations and handles the complexity of retrying failed deliveries, managing expired tokens, and batching notifications sensibly.

## Spam Detection and Content Moderation

Content quality directly affects user experience. A timeline full of spam or abusive content drives users away. The spam detection system operates at multiple layers.

At the point of tweet creation, synchronous rule-based checks run before persistence. These are fast heuristic checks: does the tweet contain known spam URLs, is the posting rate anomalously high, does the account match patterns of bot behavior?

Asynchronous ML classifiers run after persistence and can retroactively act on content. These models score for toxicity, spam probability, and policy violations. They run in a separate pipeline consuming the tweet event stream and produce moderation actions that feed back into the tweet store.

The challenge is that adversaries actively work to evade detection. Bot operators iterate on their tactics in response to detection signals. This creates an adversarial dynamic that requires the spam detection system to continuously retrain on new attack patterns.

Rate limiting is one of the most effective defenses. Even if a sophisticated bot evades content-based detection, rate limits on tweet creation, follows, and likes make it difficult to have a large-scale impact. Rate limiting is enforced at the API gateway level using sliding window counters per user ID and IP address.

## Database and Storage Design

Let us get concrete about the data model. At the core of the system are a handful of fundamental entities.

In practice, these are not stored in a single relational database. The tweet store is a distributed key-value or wide-column store (like Manhattan or Cassandra) partitioned by tweet ID. The follower graph is its own service backed by a graph-optimized store. The engagement events table is an append-only time-series store feeding into analytics and ML pipelines.

One important design principle: engagement counts (likes, retweets) are notoriously difficult to keep strongly consistent at scale. X uses eventually consistent counters. The actual count displayed may lag the true count by a few seconds or even minutes during high-traffic events. This is an explicit tradeoff of strict consistency for availability and performance.

## Event-Driven Architecture

The event-driven architecture is what allows X's disparate systems to stay decoupled while reacting to the same underlying events.

Kafka (or a comparable system) is the central nervous system. Every significant action generates an event: tweet created, tweet liked, user followed, media processed, moderation decision made. These events are published to topic-partitioned streams.

The beauty of this model is that adding a new consumer, say a new analytics pipeline or a new ML training data collector, does not require changes to the producers. The tweet ingestion service does not need to know or care about every system that needs to react to tweet creation. It just publishes the event and lets consumers do their work.

This also provides natural buffering during traffic spikes. If the fanout workers fall behind because of a sudden surge in posting activity, the events accumulate in Kafka rather than the upstream services experiencing backpressure. Workers can catch up at their own pace.

The failure model is also cleaner. If the notification service is temporarily unavailable, events accumulate in Kafka with retention. When the service recovers, it consumes the backlog. No notifications are permanently lost, and no synchronous dependency chain needs to handle the failure.

## Scalability Deep Dive

The fundamental scalability challenge of X's timeline system is that it combines two hard problems simultaneously: high write throughput (millions of tweets per hour) and high read throughput (hundreds of millions of timeline fetches per hour). Most systems need to handle only one of these extremes well. Timeline systems must handle both.

Horizontal scaling addresses most of the throughput needs. The API gateway, tweet ingestion service, fanout service, and timeline service are all stateless and can be scaled by adding instances. The state lives in the shared databases and caches.

Timeline partitioning means that different user IDs are handled by different subsets of the infrastructure. The timeline cache is partitioned by user ID. A user's timeline data always lives on the same cache nodes, allowing the system to route requests efficiently.

Multi-region deployment addresses both latency and availability. Users in Europe should have their timelines served from European infrastructure. This requires replicating tweet data and graph data across regions, with asynchronous replication being acceptable for most data (tolerating a few seconds of lag) while direct message delivery and account security operations require stronger consistency guarantees.

  
    
      
        Bottleneck
        Root Cause
        Primary Mitigation
        Residual Risk
      
    
    
      
        Fanout write storms
        Celebrity accounts with huge follower counts
        Hybrid fanout, fanout on read for celebrities
        Read-time latency for users following many celebrities
      
      
        Ranking latency
        Deep learning model inference time
        Model distillation, batching, precomputed embeddings
        Quality loss from smaller models
      
      
        Cache hotspots
        Viral tweets spiking on few cache keys
        In-process caching, replication, key sharding
        Slight staleness in in-process cache
      
      
        Graph traversal
        Large follower lists accessed frequently
        Graph cache, adjacency list optimizations
        Memory pressure for extreme follower counts
      
      
        Search indexing lag
        High write volume versus indexing throughput
        Partitioned indexing by time, prioritize recent
        Older content may have higher search latency
      
    
  

## Reliability and Availability

Social media platforms face intense public scrutiny when they go down. The reliability engineering at X has to maintain high availability across all these interacting systems.

The timeline service is designed to degrade gracefully. If the recommendation engine is temporarily slow, the service falls back to serving only the precomputed fanout timeline without recommendations. If the ranking service is unavailable, it serves tweets in reverse-chronological order. Users may see a slightly different experience, but they still see their feed. This is much better than showing an error page.

Circuit breakers between services prevent cascading failures. If the graph service starts responding slowly, timeline service instances will trip their circuit breaker for that dependency and serve timelines without the graph-dependent operations rather than queuing up requests that will eventually time out.

The distributed tracing infrastructure is critical for diagnosing issues at this scale. Every request carries a trace ID that propagates through all the services involved in handling it. When a user reports a slow timeline load, engineers can trace the full path of that request, including which services added latency, which cache layers missed, and where retries occurred.

## Security and Privacy Systems

Timeline systems sit at the intersection of identity, content, and social relationships, all of which have significant privacy implications.

Access controls determine what content appears in whose timelines. Protected accounts (accounts that require approval before someone can follow them) must only have their tweets appear in the timelines of approved followers. This constraint must be enforced consistently across the fanout and recommendation systems. A recommendation engine surfacing a protected user's tweet in a non-follower's For You feed would be a serious privacy violation.

The content visibility system is more complex than a simple public/private binary. Tweets can have location restrictions, age-gating, sensitivity labels, and platform-level moderation states. The timeline service checks these attributes before including a tweet in any feed, and must do so efficiently given the volume of candidates processed.

Rate limiting, as discussed in the spam section, also serves a security function by protecting against denial-of-service attacks. The API gateway enforces both per-user rate limits and global limits that protect backend services from overload by misbehaving clients.

## Engineering Tradeoffs

Let me summarize the key tradeoffs as a practicing engineer would think about them rather than as theoretical alternatives.

The fanout-on-write versus fanout-on-read decision is really a question of where you want to pay: at write time or at read time. Because reads are far more frequent than writes (users read their timelines many more times per day than they post), paying at write time is almost always the right call for normal accounts. For celebrities, the write cost becomes prohibitive so you must shift some cost to read time. The hybrid is not a compromise between two bad options, it is the architecturally correct design for this specific skewed distribution of follower counts.

The ranking quality versus latency tradeoff is a continuous dial, not a binary choice. You can always improve ranking quality by using a more complex model, but it will cost you latency. The right operating point depends on user research about how much ranking quality improvement actually drives engagement, versus how much timeline load latency drives abandonment. These are empirical questions answered by running experiments.

Consistency versus availability in the tweet store and engagement counters is a case where eventual consistency is clearly the right answer. Users do not care if a like count is a few seconds stale. They do care deeply if the system is unavailable. Sacrificing strict consistency for high availability is the right call here, and it is important that this is an explicit product and engineering decision rather than an accident.

The recommendation exploration versus exploitation balance affects user experience in less obvious ways. Too much exploitation (always showing users exactly what they already like) leads to filter bubbles and declining diversity in the content users encounter. Too much exploration (showing lots of unfamiliar content) can feel irrelevant and drive down engagement. The right balance is found through experimentation, but the decision to even include exploration is a product values decision, not just an engineering one.

## Real-World Technology Stack

X's actual technology stack has evolved significantly over its history, and some of it has been made public through technical blog posts and engineering talks.

Scala and Java power much of the backend service layer. Scala in particular is well-suited to the functional, data-transformation-heavy code common in recommendation and ranking pipelines. Go is increasingly used for high-throughput services where its performance characteristics and simplicity are advantageous.

Redis is used extensively for caching, both for timeline caches and for rate limiting counters. Its sorted set data structure is a natural fit for timeline entries (tweet IDs ordered by score or timestamp).

Manhattan, X's internal distributed key-value store, handles tweet persistence and related storage. It is built on principles similar to Cassandra, optimized for X's specific access patterns.

Kafka (or an equivalent event streaming system) handles the event-driven communication between services.

Elasticsearch manages the search index and powers the full-text tweet search experience.

TensorFlow and similar frameworks underpin the ML ranking and recommendation models. Feature engineering pipelines run on distributed compute frameworks.

Kubernetes manages the container orchestration for the service fleet, providing the declarative infrastructure management needed to operate hundreds of services at scale.

  
    
      
        Technology
        Role
        Why This Choice
      
    
    
      
        Scala / Java
        Backend services, ranking pipelines
        JVM maturity, strong ecosystem, functional style suits data pipelines
      
      
        Go
        High-throughput services
        Low latency, simple concurrency model, fast compile times
      
      
        Redis
        Timeline cache, rate limiting
        Sorted sets, sub-millisecond reads, mature replication
      
      
        Manhattan (Cassandra-like)
        Tweet and user persistence
        Horizontally scalable, tunable consistency, high write throughput
      
      
        Kafka
        Event streaming
        Durable, partitioned, high-throughput pub/sub
      
      
        Elasticsearch
        Search index, trending topics
        Inverted index, real-time ingestion, powerful query API
      
      
        TensorFlow
        ML ranking and recommendation models
        Production-grade serving, GPU support, large ecosystem
      
      
        Kubernetes
        Container orchestration
        Declarative deployments, auto-scaling, service discovery
      
    
  

## System Design Interview Perspective

When an interviewer asks you to design a Twitter or X-like timeline system, they are testing your ability to navigate tradeoffs at scale. Here is how strong candidates approach it.

Start by clarifying scope. Are you designing the home timeline feed, just tweet storage, or the full recommendation system? How many users? What is the expected read/write ratio? What are the latency requirements? Getting these numbers pinned down early signals engineering maturity.

Define a simple end-to-end flow before optimizing. Describe tweet creation, persistence, fanout, and timeline retrieval in terms that work at small scale. Then identify where the bottlenecks appear as scale increases and how to address each one. This graduated approach is much more persuasive than jumping immediately to complex distributed systems buzzwords.

The fanout discussion is almost always the heart of the interview. Make sure you can articulate the write amplification problem, why pure fanout on read does not work at scale, and why the hybrid model is the engineering solution. Candidates who can reason about the celebrity problem specifically, and explain why it requires different treatment, demonstrate genuine distributed systems thinking.

Strong candidates discuss failure modes proactively. What happens if the fanout service is slow? What happens if the cache is cold? What happens if the ranking service is unavailable? Showing that you think about degraded states, not just happy paths, is a strong positive signal.

Common mistakes include: jumping to microservices and Kubernetes before establishing basic architecture; choosing consistency where eventual consistency is clearly fine; not accounting for the celebrity follower count distribution; treating ranking as a simple sort rather than a multi-stage ML pipeline; and not discussing how the caching strategy interacts with the fanout system.

The best system design discussions feel like conversations between engineers exploring tradeoffs together. Show your reasoning. Say why, not just what. The interviewer knows the answers, they want to understand how you think.

## Closing Thoughts

Every time you refresh your X timeline, hundreds of machines are doing work on your behalf. The fanout system has precomputed most of what you will see. The recommendation engine has injected content from outside your following graph that it predicts you will engage with. The ranking model has scored thousands of candidates and sorted them in a way designed to keep you interested. The caching infrastructure has served the vast majority of this from memory, never touching a disk.

All of this happens in under 200 milliseconds.

The X timeline is not one system. It is a coordination of distributed storage, event streaming, graph traversal, machine learning inference, multi-tier caching, and real-time update delivery, all working together within strict latency budgets. Understanding any one of these layers deeply is a career's worth of work. Understanding how they fit together, the tradeoffs between them, and why each architectural decision was made is the real system design challenge.

That understanding is what separates engineers who can build services from engineers who can build platforms.
