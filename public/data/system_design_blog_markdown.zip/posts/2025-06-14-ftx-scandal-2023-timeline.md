---
title: "FTX Scandal 2023: Timeline, Facts, and Key Players"
date: "2025-06-14T13:49:37+05:30"
slug: "ftx-scandal-2023-timeline"
categories: ["case_study", "scandals", "crypto"]
original_url: "https://rishijeet.github.io/blog/ftx-scandal-2023-timeline/"
word_count: 943
reading_time: "5 min"
author: "Rishijeet Mishra"
---

# FTX Scandal 2023: Timeline, Facts, and Key Players

*Published on 2025-06-14 by Rishijeet Mishra | [https://rishijeet.github.io/blog/ftx-scandal-2023-timeline/](https://rishijeet.github.io/blog/ftx-scandal-2023-timeline/)*

In the annals of modern financial history, few names have sparked as much controversy, disbelief, and chaos as Futures Exchange (FTX). Once hailed as a shining star of the cryptocurrency world, FTX’s meteoric rise and catastrophic fall stunned investors, regulators, and the general public alike. By the end of 2023, the scandal surrounding FTX and its founder Sam Bankman-Fried had cemented its place as one of the largest and most complex financial frauds of the 21st century.

This blog dives into the rise and fall of FTX, examining the events that led to its collapse, the financial and human toll it took, and the key takeaways from a debacle that shook the entire crypto industry to its core.

![Alt text](https://rishijeet.github.io/images/2025/ftx.png)

Source: Internet

### The Rise of FTX: From Start-up to Crypto Juggernaut

FTX was founded in 2019 by Sam Bankman-Fried (commonly referred to as SBF), a former Wall Street quant with a background from MIT and a reputation for genius-level intellect. The exchange was created as a more sophisticated platform for cryptocurrency derivatives and quickly attracted traders looking for advanced features, high leverage, and innovative products.

By 2021, FTX had:

- Raised over \$1.8 billion from prominent investors including Sequoia Capital, SoftBank, and Tiger Global.

- Claimed over 1 million users and processed billions of dollars in trades daily.

- Achieved a staggering \$32 billion valuation, making it the third-largest crypto exchange globally.

SBF’s influence extended well beyond the company. He was a frequent guest on financial talk shows, lobbied in Washington, and was dubbed the “JP Morgan of crypto” after bailing out other struggling crypto firms in 2022. But behind the charismatic image and philanthropic posturing was a house of cards waiting to collapse.

![Alt text](https://rishijeet.github.io/images/2025/ftx_revenue.png)

Source: Internet

### The Fall Begins: A Leak, a Tweet, and a Run on the Bank

The trigger came in early November 2022, when CoinDesk published a leaked balance sheet from Alameda Research, a trading firm closely tied to FTX and also founded by SBF. The leak revealed that:

- \$5.8 billion of Alameda’s assets were in FTT, the native token issued by FTX.

- A large portion of Alameda's balance sheet was illiquid and backed by FTT, suggesting FTX and Alameda were dangerously intertwined.

This revelation sparked panic in the market. Binance, FTX’s main rival, announced it would liquidate its \$530 million worth of FTT holdings.

![Alt text](https://rishijeet.github.io/images/2025/FTX_token_price.webp)

Source: Internet

What followed was a textbook “run on the bank.” Within 72 hours, FTX customers tried to withdraw \$6 billion, exposing the exchange’s inability to meet withdrawal demands. On November 11, 2022, FTX, Alameda Research, and over 130 related entities filed for bankruptcy.

### The Aftermath: Bankruptcy, Arrests, and a Trial

The bankruptcy filings laid bare the chaos within FTX:

- An estimated \$8–10 billion in customer funds were missing.

- FTX had no proper financial records, and assets were reportedly tracked in QuickBooks, a tool meant for small businesses.

- The new CEO, John J. Ray III (who previously oversaw Enron’s liquidation), called FTX's management the worst he’d seen in his 40-year career.

In December 2022, SBF was arrested in the Bahamas and extradited to the U.S. He was charged with eight counts of fraud, money laundering, and campaign finance violations.

During the 2023 trial:

- Testimonies from former FTX executives (including Caroline Ellison, CEO of Alameda and SBF’s former girlfriend) revealed deliberate misappropriation of customer funds.

- Prosecutors showed that billions were siphoned from FTX to fund Alameda’s risky bets, luxury real estate, political donations (over \$90 million), and personal expenses.

In November 2023, Sam Bankman-Fried was found guilty on all counts, facing a potential sentence of over 110 years in prison. His sentencing is scheduled for March 2024.

### The Numbers That Define the Collapse

  
    
      Metric
      Value
    
  
  
    
      Peak Valuation of FTX
      $32 billion
    
    
      Customer Funds Missing
      ~$8–10 billion
    
    
      Number of Users Affected
      Over 1 million
    
    
      Political Donations by SBF
      $90 million+
    
    
      Real Estate Purchases
      $300 million+
    
    
      Alameda Loan to SBF
      $1 billion+
    
    
      Legal and Bankruptcy Costs
      Estimated $200 million+
    
  

### Broader Impact on Crypto and Beyond

FTX’s collapse sent shockwaves through the crypto ecosystem:

- Prices of major cryptocurrencies like Bitcoin and Ethereum dropped over 20% in the weeks following the collapse.

- Several crypto lending platforms and hedge funds with FTX exposure, including Genesis and BlockFi, filed for bankruptcy.

- Investors lost trust in centralized exchanges, pushing many toward cold wallets and DeFi platforms.

Regulators responded swiftly:

- U.S. Congress held hearings on crypto regulation.

- The SEC and CFTC vowed tighter oversight of crypto platforms.

- Discussions began around creating a federal framework for crypto custodianship and proof-of-reserves.

### Lessons from the FTX Scandal

- Charisma is not competence
SBF’s charm, intelligence, and philanthropic front masked serious mismanagement and fraudulent practices.

- Regulatory gaps need closing
FTX operated in a regulatory gray zone, exploiting jurisdictional loopholes to avoid scrutiny.

- Centralization without accountability is dangerous
Despite being a crypto exchange, FTX was run like a black box. There were no independent board members or external audits.

- Always follow the money
The FTX saga revealed the ease with which customer funds could be co-mingled and misused in the absence of checks and balances.

### Final Thoughts

FTX was not just a crypto story—it was a human story of unchecked power, blind trust, and systemic failure. It shook investor confidence and became a harsh reminder that, even in the futuristic world of blockchain, age-old rules of governance, transparency, and ethics cannot be ignored.

As the crypto industry tries to rebuild in the wake of this collapse, FTX will stand as a cautionary tale—a reminder that even billion-dollar empires can crumble when built on deception.

Let this not just be history, but a lesson for the future.
