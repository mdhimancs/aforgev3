---
title: "How WhatsApp Works?"
date: "2026-05-01T22:30:48+05:30"
slug: "how-whatsapp-works"
categories: ["system_design", "architecture", "technology", "whatsapp", "message", "social_media"]
original_url: "https://rishijeet.github.io/blog/how-whatsapp-works/"
word_count: 8778
reading_time: "44 min"
author: "Rishijeet Mishra"
---

# How WhatsApp Works?

*Published on 2026-05-01 by Rishijeet Mishra | [https://rishijeet.github.io/blog/how-whatsapp-works/](https://rishijeet.github.io/blog/how-whatsapp-works/)*

> WhatsApp started as a simple idea: replace SMS with something that worked over the internet. That idea, built out of a tiny team, grew into one of the most sophisticated real-time communication platforms on earth. Today it handles over 100 billion messages every single day, across more than two billion active users, in nearly every country. And it does this while keeping every message end-to-end encrypted — meaning not even WhatsApp's own servers can read what you send.

![Alt text](https://rishijeet.github.io/images/system_design/whatsapp.png)

That is not a trivial thing to build.

Most developers who have never worked on messaging infrastructure underestimate how hard this is. It is easy to build a chat app that works for a few thousand users. What makes WhatsApp interesting — and genuinely difficult — is that it works at a scale where even a 0.001% failure rate means millions of dropped messages. Where network instability, device diversity, mobile battery constraints, and global infrastructure all need to be considered simultaneously. Where adding end-to-end encryption is not a feature bolt-on but a foundational architectural decision that affects literally every part of the system.

This blog is a deep technical walkthrough of how WhatsApp works internally. We will go from the moment you tap send on a message all the way through encryption, server routing, delivery acknowledgement, and multi-device synchronization. We will cover group messaging, media delivery, push notifications, presence systems, and voice calling. And throughout all of it, we will focus on why each system is designed the way it is — the tradeoffs, the failure scenarios, and the engineering reasoning behind every major decision.

## Core Features of WhatsApp

Before jumping into architecture, it helps to understand exactly what WhatsApp does. Because each feature has its own infrastructure requirements that interact in non-obvious ways.

One-to-one messaging is the core product. A message is composed, encrypted on your device, transmitted to WhatsApp servers, held if the recipient is offline, and then delivered when they come back online. The whole pipeline needs to be fast, reliable, and encrypted.

Group chats are fundamentally different. When you send a message to a group of two hundred people, that single message needs to reach two hundred different devices — each with their own encryption sessions, each potentially offline, each on different networks. This is called fanout, and it is one of the hardest scaling problems in messaging.

Voice and video calls are a completely different beast from messaging. They require peer-to-peer real-time communication with sub-200ms latency, adaptive quality based on network conditions, NAT traversal, and relay infrastructure for users who cannot connect directly. The media stack for calls has almost nothing in common with the messaging stack.

Media sharing — photos, videos, voice notes — introduces an entirely separate pipeline for upload, compression, CDN distribution, and encrypted delivery. A five-second voice note and a 4K video require the same security guarantees as text but very different infrastructure.

Status updates, read receipts, typing indicators, and presence are the ambient signals that make a messaging app feel alive. These are all low-priority compared to messages themselves, but they need to be efficient — because if every typing indicator or last-seen update generates a database write, you are generating billions of writes per day from signals users barely think about.

Multi-device support — introduced relatively recently — is one of the hardest problems WhatsApp has tackled. When you link WhatsApp to your laptop, your messages need to appear on both devices, stay in sync, and do all of this without breaking end-to-end encryption. That last constraint makes the problem extremely difficult.

Business messaging adds another dimension: high-volume senders, verified accounts, template messages, webhook integrations, and read receipt analytics for businesses. It sits on top of the core messaging infrastructure but with very different reliability guarantees.

## High-Level Architecture

At the highest level, WhatsApp's architecture looks like this: clients on the edge connect to a cluster of messaging servers over persistent connections. Those servers handle routing, delivery, encryption key management, and queuing. Underneath them is a layer of storage, caching, event streaming, and external notification systems.

flowchart TD;
    A[Mobile Client];
    B[Web Client];
    C[API Gateway and Load Balancer];
    D[WebSocket Messaging Servers];
    E[Presence Service];
    F[Group Messaging Service];
    G[Push Notification Service];
    H[Media Upload Service];
    I[Encryption Key Service];
    J[Event Streaming Kafka];
    K[Message Store];
    L[Cache Redis];
    M[CDN];
    N[APNs Firebase];

    A &#8211;> C;
    B &#8211;> C;
    C &#8211;> D;
    D &#8211;> E;
    D &#8211;> F;
    D &#8211;> G;
    D &#8211;> H;
    D &#8211;> I;
    D &#8211;> J;
    D &#8211;> K;
    D &#8211;> L;
    H &#8211;> M;
    G &#8211;> N;

    classDef client fill:#2563eb,stroke:#1e40af,color:#ffffff;
    classDef gateway fill:#0891b2,stroke:#0e7490,color:#ffffff;
    classDef service fill:#16a34a,stroke:#166534,color:#ffffff;
    classDef storage fill:#9333ea,stroke:#6b21a8,color:#ffffff;
    classDef queue fill:#f59e0b,stroke:#b45309,color:#ffffff;
    classDef external fill:#dc2626,stroke:#991b1b,color:#ffffff;

    class A,B client;
    class C gateway;
    class D,E,F,G,H,I service;
    class K,L,M storage;
    class J queue;
    class N external;

Each component in this diagram handles a specific concern. The load balancer distributes incoming connections across messaging servers. The messaging servers hold persistent connections with clients and route messages. The presence service tracks online/offline state. The group messaging service handles fanout. The push notification service handles offline delivery. The encryption key service manages the Signal Protocol infrastructure. Kafka handles asynchronous event streaming for analytics, audit trails, and decoupled processing. Redis is the primary cache. The CDN serves media.

The critical insight here is that messaging servers are stateful — they hold open TCP connections with clients. This is very different from typical web servers that can be completely stateless. It means you cannot route a message from User A to User B without knowing which messaging server User B's connection lives on. That session routing problem is something WhatsApp solves with a distributed session registry.

## The Real-Time Messaging Pipeline

Here is where things get interesting. Let us trace exactly what happens when you send a message.

You type &ldquo;Hey, dinner tonight?&rdquo; and tap send. Your WhatsApp client encrypts that message using the recipient's public key and your shared session key. The encrypted ciphertext — which looks like random bytes to anyone observing the network — is wrapped in a protocol buffer, sent over your persistent WebSocket connection to the nearest WhatsApp server, and acknowledged.

flowchart TD;
    A[User Types Message];
    B[Client Encrypts with Signal Protocol];
    C[Wrap in Protocol Buffer];
    D[Send over WebSocket];
    E[Messaging Server Receives];
    F[Check Recipient Online];
    G[Route to Recipient Server];
    H[Deliver to Recipient Client];
    I[Recipient Sends ACK];
    J[Server Marks Delivered];
    K[Queue for Offline Delivery];

    A &#8211;> B;
    B &#8211;> C;
    C &#8211;> D;
    D &#8211;> E;
    E &#8211;> F;
    F &#8211;>|Online| G;
    F &#8211;>|Offline| K;
    G &#8211;> H;
    H &#8211;> I;
    I &#8211;> J;
    K &#8211;>|User Comes Online| G;

    classDef action fill:#2563eb,stroke:#1e40af,color:#ffffff;
    classDef decision fill:#f59e0b,stroke:#b45309,color:#000000;
    classDef success fill:#16a34a,stroke:#166534,color:#ffffff;
    classDef queue fill:#9333ea,stroke:#6b21a8,color:#ffffff;

    class A,B,C,D action;
    class E,F decision;
    class G,H,I,J success;
    class K queue;

The server that receives your message now needs to figure out where the recipient is. It queries a distributed session store — essentially a hash map from user ID to server address — to find which server currently holds the recipient's WebSocket connection. Then it forwards the encrypted message to that server, which pushes it down the connection to the recipient's device.

The recipient's device receives the message, decrypts it, displays it, and sends back an acknowledgement. That ACK travels back up the chain to the original server, which marks the message as delivered and sends a delivery receipt back to you. When the recipient opens the chat, a read receipt is generated and sent back. You see the two blue ticks.

What happens when the recipient is offline? The message gets persisted to a message queue store with the recipient's user ID as the key. When the recipient comes back online and establishes a WebSocket connection, the server checks this queue and flushes all pending messages down to the device. Push notifications handle alerting the device to wake up and reconnect.

The important thing to understand about this pipeline is that it is designed for at-least-once delivery, not exactly-once. If the network drops between the ACK and the sender receiving confirmation of delivery, the message might be resent. WhatsApp handles duplicates on the client side using message IDs — if you receive a message you have already seen, you drop it.

Ordering is maintained within a conversation using client-generated timestamps and server sequence numbers. These are not perfectly globally ordered — two messages sent at almost the same instant from different devices might arrive in slightly different orders — but within a single conversation thread, the ordering is stable enough for practical purposes.

## End-to-End Encryption: A Deep Dive

WhatsApp's encryption is built on the Signal Protocol, originally designed by Open Whisper Systems. Understanding this system properly requires understanding a few cryptographic concepts.

Every WhatsApp user has a set of cryptographic keys. There is an identity key pair — a long-term keypair that represents your account. There are signed pre-keys — medium-term keys that rotate periodically. And there are one-time pre-keys — single-use keys that are uploaded to WhatsApp's servers in bulk and used to establish new sessions.

flowchart TD;
    A[Identity Key Pair];
    B[Signed Pre-Key];
    C[One-Time Pre-Keys];
    D[Upload Public Keys to Server];
    E[Sender Fetches Recipient Public Keys];
    F[X3DH Key Agreement];
    G[Generate Shared Secret];
    H[Initialize Double Ratchet];
    I[Derive Session Keys];
    J[Encrypt Messages];

    A &#8211;> D;
    B &#8211;> D;
    C &#8211;> D;
    D &#8211;> E;
    E &#8211;> F;
    A &#8211;> F;
    F &#8211;> G;
    G &#8211;> H;
    H &#8211;> I;
    I &#8211;> J;

    classDef keygen fill:#9333ea,stroke:#6b21a8,color:#ffffff;
    classDef server fill:#16a34a,stroke:#166534,color:#ffffff;
    classDef crypto fill:#dc2626,stroke:#991b1b,color:#ffffff;
    classDef output fill:#2563eb,stroke:#1e40af,color:#ffffff;

    class A,B,C keygen;
    class D,E server;
    class F,G,H,I crypto;
    class J output;

When Alice wants to send a message to Bob for the first time, she fetches Bob's public identity key, signed pre-key, and a one-time pre-key from WhatsApp's key server. She runs these through a process called X3DH (Extended Triple Diffie-Hellman) to derive a shared secret — a secret that only Alice and Bob can compute, and that WhatsApp's servers cannot derive even though they temporarily hold the public keys.

This shared secret seeds the Double Ratchet Algorithm. The Double Ratchet is what gives Signal Protocol its unique security properties. Every single message uses a different encryption key, derived by ratcheting forward from the previous key. The magic is that these keys are derived in one direction — you can compute future keys from a current key, but not past keys. This property is called forward secrecy.

Forward secrecy means that if an attacker somehow compromises your current encryption keys, they still cannot decrypt messages you sent in the past. The keys for those old messages are gone — they were ratcheted forward and discarded. This is a fundamental security property that WhatsApp inherited from Signal and that most older encryption systems lack.

The Double Ratchet has two components working together. The symmetric-key ratchet derives new message keys for every message using a key derivation function. The Diffie-Hellman ratchet runs a new key exchange every time you and your contact exchange messages in both directions, which provides what cryptographers call break-in recovery — even if an attacker compromises the current state, the next DH ratchet step heals the security.

Here is what this means concretely. Suppose an attacker manages to compromise your phone and extract your current session state. They can use that state to decrypt any messages you receive from that point forward — until the next DH ratchet step, which happens automatically as soon as you and your contact exchange messages. After that ratchet, the attacker's extracted state is useless for future messages.

WhatsApp's servers see nothing but ciphertext. They cannot read your messages. They do see metadata — who is messaging whom, when, how frequently, and approximately how large the messages are. This metadata can still reveal a lot about communication patterns, which is an honest limitation of WhatsApp's privacy model compared to something like Signal's sealed sender.

One practical concern with end-to-end encryption is key management. What happens when you get a new phone? Your old private keys are gone — that is the whole point of keeping them on-device. WhatsApp handles this by either allowing you to restore from an encrypted backup (where the backup key is derived from your account password and stored in a hardware security module via WhatsApp's key vault system) or simply starting fresh with new keys, which means older messages are not available on the new device.

## WebSocket and Persistent Connection Infrastructure

Most web applications use HTTP — a request-response protocol where the client asks, the server answers, and the connection might close. That model does not work for messaging because the server needs to push messages to you without you asking for them first.

WhatsApp uses persistent TCP connections, originally over XMPP (Extensible Messaging and Presence Protocol) and later evolved into a custom protocol that runs over WebSockets or a similar long-lived connection layer. The key property is that once your client connects, that connection stays open. The server can push data down to you at any time.

The challenge is maintaining millions — billions, at scale — of these open connections simultaneously. Each connection consumes file descriptors, memory for buffering, and CPU for TLS processing. A naive server implementation might handle a few thousand connections before running out of resources. WhatsApp famously chose Erlang for their messaging server infrastructure for exactly this reason.

Erlang's actor model and lightweight process model mean you can spawn hundreds of thousands of concurrent processes on a single machine, each handling one connection, with very small per-process overhead. The language and runtime were designed for exactly this kind of massively concurrent, fault-tolerant network service. It is not the most popular language in the industry, but for this use case it was a genuinely good engineering call.

Mobile networks add a whole new dimension of complexity. Mobile connections go down constantly — you walk into an elevator, your phone switches from WiFi to cellular, you move between cell towers, the network gets congested. Every one of these events might silently drop your TCP connection. Your client needs to detect this and reconnect.

WhatsApp clients send periodic heartbeats — small keepalive packets — over the connection. If the server does not receive a heartbeat within the expected window, it considers the connection dead and cleans up the session. The client independently monitors for network changes and connection failures using system callbacks, and triggers reconnection when needed.

Battery optimization is a real tension here. Keeping a persistent connection alive and sending frequent heartbeats drains battery. WhatsApp has to balance connection reliability against battery efficiency, which varies by platform (iOS has stricter background execution limits than Android) and by network type (cellular vs WiFi has very different power profiles). The heartbeat interval is tuned differently based on platform and network state.

## Message Queuing and Delivery Guarantees

When you send a message to someone who is offline, that message needs to be stored somewhere until they reconnect. This is the offline message queue.

The queue is keyed by recipient user ID. When the recipient's device comes online and establishes a connection, the messaging server checks the queue for any pending messages and delivers them in order. The client sends acknowledgements as it processes each message, and the server removes acknowledged messages from the queue.

This at-least-once delivery model means the same message could theoretically be delivered twice — for example, if the network drops right after the client receives the message but before the ACK reaches the server. WhatsApp handles idempotency on the client side using unique message IDs. The client maintains a recently-seen message ID set and drops any message it has already processed.

Delivery receipt semantics matter a lot to users. WhatsApp distinguishes between sent (message reached server), delivered (message reached recipient device), and read (recipient opened the chat). Each of these is tracked separately and displayed as different tick indicators. This requires reliable event tracking through the entire delivery pipeline.

Message ordering within a conversation is maintained through sequence numbers assigned by the sender's client. Even if messages arrive out of order at the server (which can happen in edge cases), the receiving client can buffer and reorder them before displaying. This is important for conversations where multiple messages are sent in quick succession.

## Group Messaging Architecture

Group messaging is where the real scaling challenges emerge. When you send a message to a group of 512 people (WhatsApp's current limit), that message needs to be delivered to 512 different users, each with their own encryption session, each potentially on a different server, each potentially offline.

The naive approach — let the sender's device encrypt 512 copies of the message, one for each recipient — does not scale. Encrypting and transmitting 512 copies would be impossibly slow for large groups.

WhatsApp uses a more efficient approach called the Sender Key protocol (also from Signal). When a group is created, a special group session key — called the Sender Key — is generated. The Sender Key is distributed to all group members, encrypted individually for each of them using their existing pairwise session. From that point forward, messages to the group are encrypted once using the Sender Key, and that single ciphertext is delivered to all group members.

flowchart TD;
    A[Sender Generates Message];
    B[Encrypt with Group Sender Key];
    C[Single Ciphertext];
    D[Server Fanout Service];
    E[Member 1 Delivery Queue];
    F[Member 2 Delivery Queue];
    G[Member N Delivery Queue];
    H[Member 1 Device];
    I[Member 2 Device];
    J[Member N Device];

    A &#8211;> B;
    B &#8211;> C;
    C &#8211;> D;
    D &#8211;> E;
    D &#8211;> F;
    D &#8211;> G;
    E &#8211;> H;
    F &#8211;> I;
    G &#8211;> J;

    classDef sender fill:#2563eb,stroke:#1e40af,color:#ffffff;
    classDef crypto fill:#9333ea,stroke:#6b21a8,color:#ffffff;
    classDef server fill:#16a34a,stroke:#166534,color:#ffffff;
    classDef queue fill:#f59e0b,stroke:#b45309,color:#000000;
    classDef device fill:#dc2626,stroke:#991b1b,color:#ffffff;

    class A sender;
    class B,C crypto;
    class D server;
    class E,F,G queue;
    class H,I,J device;

The fanout problem shifts from the client to the server. The server now needs to deliver one ciphertext to 512 queues. This is a write amplification problem — one message generates 512 queue writes. For a very active group with hundreds of messages per day, this generates enormous write volume.

The fanout service handles this asynchronously. When a group message arrives at the server, it is acknowledged to the sender immediately (so they see the sent tick), and then a fanout job is enqueued. The fanout service reads group membership from the database (or cache), writes the message to each member's delivery queue in parallel batches, and handles failures with retries.

Group membership management has its own complexities. When someone is added to a group, they need to receive the current Sender Key (so they can decrypt new messages) and — importantly — they should not receive the Sender Key for past messages (preventing them from reading messages sent before they joined). This is enforced cryptographically: when a new member joins, a new Sender Key rotation is triggered. Old messages remain inaccessible.

When someone leaves a group or is removed, another Sender Key rotation happens. This ensures the person who left cannot decrypt future messages even if they somehow retained the old Sender Key.

Scaling groups becomes a major engineering problem for very large groups. WhatsApp's community feature allows groups up to 1024 members, and broadcast channels go even larger. At these sizes, fanout write amplification is severe, membership changes are frequent, and delivery receipt aggregation becomes expensive. WhatsApp handles this through sharded fanout workers, batched queue writes, and less granular delivery tracking for very large groups.

## Multi-Device Synchronization

Multi-device support is the problem that keeps messaging engineers awake at night. It sounds simple — your WhatsApp should work on both your phone and your laptop. But combining this with end-to-end encryption creates a cascade of hard problems.

The fundamental tension is this: end-to-end encryption means private keys live only on your device. But if each device has its own private keys, then a message encrypted for your phone cannot be decrypted on your laptop — they have different keys.

WhatsApp solves this by treating each linked device as a separate Signal Protocol identity. When you link your laptop, the phone and laptop establish a paired session. When the sender encrypts a message to you, they actually encrypt separate copies for each of your active devices. The server knows which devices are linked to which account and delivers accordingly.

This means the sender is now encrypting multiple copies again — but the sender's client handles this automatically. For every message, the client fetches the set of active devices for the recipient, establishes a session with each if one does not already exist, encrypts the message for each session, and bundles them all in a single transmission. The server splits the bundle and routes each copy to the appropriate device.

Message history synchronization for newly linked devices is handled separately. When you link a new laptop, WhatsApp uses the existing phone to bootstrap the history — the phone encrypts a copy of recent message history and transfers it to the new device through an encrypted channel. This avoids routing history through WhatsApp's servers and preserves the end-to-end guarantee.

The consistency challenges here are subtle. If you send a message from your laptop and then immediately pick up your phone, the message should already be there on the phone. But if your phone was offline when you sent from the laptop, it will need to sync when it comes back online. WhatsApp maintains a device-specific delivery queue for each linked device, so messages sent to your account get queued separately for each device and delivered when each device reconnects.

Trust management is another dimension. When you link a device, the phone must verify the new device — typically by scanning a QR code. This QR code contains a short-lived one-time token that the phone and laptop use to authenticate each other and establish the initial pairing. If someone somehow got access to your QR code before you scanned it, they could link their device to your account. This is mitigated by QR codes expiring quickly (typically seconds) and by requiring the authenticating device to already be logged in.

## Presence and Read Receipt Systems

Knowing whether a contact is online or offline seems like a small feature, but presence tracking at WhatsApp's scale is surprisingly expensive.

Every user's online status changes constantly — they open the app, they get a call, they lock their phone. Each status change needs to be propagated to anyone who might care — specifically, anyone who has an open conversation with that user. If Alice has conversations with two hundred contacts, and each of those contacts changes their status multiple times per day, Alice's client is receiving hundreds of presence updates per day. Multiplied across two billion users, this is an enormous stream of events.

WhatsApp gates presence on privacy settings. By default, you only see presence updates for contacts you are actively chatting with, and even that is limited to when you have the conversation open. This is both a privacy feature and a scalability feature — it dramatically reduces the volume of presence events that need to be delivered.

The presence system uses a pub-sub model. When you open a conversation with Bob, your client subscribes to Bob's presence. The presence service pushes updates to all active subscribers when Bob's status changes. When you close the conversation, you unsubscribe. This subscription model is much more efficient than polling.

Last-seen timestamps are stored server-side and cached aggressively. Your actual last-seen time is written to the presence database when you disconnect, and cached in Redis for fast reads. When another user's client queries your last-seen time, the server serves it from cache in microseconds.

Read receipts work similarly. When you read a message, your client sends a read receipt event to the server, which stores it and routes it back to the sender. Read receipts are batched when you open a conversation with many unread messages — rather than sending one receipt per message, the client sends a receipt for the highest message ID it has seen, and the server marks everything up to that ID as read.

Typing indicators are ephemeral — they are sent directly over the WebSocket connection with no persistence. If the network drops while someone is typing, the typing indicator disappears. This is fine because typing indicators are not critical — it is acceptable to miss them occasionally.

## Voice and Video Calling Infrastructure

Calling is architecturally distinct from messaging. Messages can tolerate latency — a message that takes a second to deliver is fine. Calls cannot tolerate latency — audio that is more than 200ms late becomes unintelligible. This means the infrastructure for calling is fundamentally different.

WhatsApp calls use WebRTC as the foundational media protocol. WebRTC provides real-time audio and video transmission with built-in congestion control, packet loss recovery, and adaptive bitrate. It was designed for exactly this use case.

The ideal scenario for a call is peer-to-peer — Alice and Bob connect their devices directly, and audio flows between them without touching WhatsApp's servers at all. This is the lowest-latency path and does not consume any server bandwidth. But peer-to-peer connectivity is blocked in many network configurations — corporate firewalls, double NAT, strict mobile carrier routing.

To establish peer-to-peer connectivity, WebRTC uses ICE (Interactive Connectivity Establishment). The clients exchange ICE candidates — potential network paths between them — and try connecting on each path. STUN servers (Session Traversal Utilities for NAT) help clients discover their external IP addresses and port mappings so they can share this information with the other party.

When direct connectivity fails — which happens more often than you might expect — the call is relayed through TURN servers (Traversal Using Relays around NAT). TURN servers act as media relays: all audio and video flows through them. This increases latency and costs WhatsApp bandwidth, but it is the fallback that makes calls work everywhere.

Call quality adaptation is handled by WebRTC's built-in congestion control algorithms. If the network bandwidth drops, the codec reduces bitrate. If packet loss increases, the error correction layer compensates. The audio codec switches from high-quality (OPUS at 50+ kbps) to narrow-band (OPUS at 8 kbps) if the connection deteriorates significantly. Users hear this as quality degrading rather than the call dropping entirely — a much better user experience.

Group calls add another layer of complexity. Each participant cannot be connected to every other participant in a full mesh (five participants would need ten connections each way). WhatsApp uses a Selective Forwarding Unit (SFU) — a media server that each participant connects to once, and the SFU handles routing audio and video streams between participants. The SFU can also adapt streams per-participant based on their network conditions.

## Media Upload and Delivery Systems

Media in WhatsApp goes through a completely separate pipeline from messages. When you send a photo, the flow is: compress the image on-device, encrypt it with a randomly generated media key, upload the encrypted blob to WhatsApp's media servers, receive a URL for the uploaded blob, send a text message to your contact containing the URL and the media decryption key, your contact's device fetches the encrypted blob from the URL and decrypts it locally.

This separation is elegant. The messaging servers never handle the media blob itself — only the URL and the key. The media is stored on object storage (think S3-equivalent) and served through a CDN. The messaging pipeline stays lean and fast. And because the media is encrypted with a separate key that WhatsApp's servers never see, the media is also end-to-end encrypted.

Compression happens on-device before encryption and upload. Photos are re-encoded at reduced quality. Videos are transcoded to a smaller codec and resolution. This dramatically reduces upload size and storage costs. WhatsApp is quite aggressive about this — a photo you send through WhatsApp is noticeably lower quality than the original, because the client targets a file size budget rather than a quality threshold.

Thumbnail generation also happens on-device. The low-resolution preview image (the blur you see before the full image loads) is generated by the client, encrypted separately, and included directly in the message payload — so the preview appears instantly even before the full media download starts.

CDN caching works very well for popular media content (memes, viral videos that get forwarded thousands of times) because the same encrypted blob appears in many message logs. But even for private media, CDN edge nodes can cache and serve media closer to the recipient's geography, reducing download latency.

Media retention is limited. WhatsApp does not store media indefinitely on their servers — media blobs are retained for a fixed period (typically two to three months) after upload. After that, the URL becomes invalid. If you try to open an old message with an expired media URL, you see a &ldquo;Media not available&rdquo; message. This limits WhatsApp's storage costs and is consistent with the privacy model — they are not trying to be your long-term media archive.

## Push Notification Infrastructure

Push notifications are what bring a messaging app to life when you are not actively using it. Without push notifications, you would never know you had a new message until you opened the app.

On iOS, all push notifications go through Apple Push Notification service (APNs). On Android, they go through Firebase Cloud Messaging (FCM). WhatsApp does not have a choice here — these platforms control background delivery, and circumventing them would drain battery and potentially violate platform policies.

When a message arrives for an offline user, the messaging server enqueues it and simultaneously sends a push notification through APNs or FCM. The notification payload itself contains minimal information — typically just an indication that there is a new message, not the message content itself. This is a privacy choice: if the message content were in the notification payload, it would pass through APNs or FCM servers, breaking end-to-end encryption.

The receiving device wakes up from the push notification, establishes its WebSocket connection to WhatsApp's servers, and then the message flows through the normal encrypted channel. This makes the actual message delivery slightly slower (notification -> wake -> connect -> receive) compared to an always-on connection, but the battery savings are worth it.

APNs and FCM both have their own reliability challenges. Notifications can be delayed — sometimes by minutes — during periods of high load or when the notification payload size limit is exceeded. They can be dropped if the device is offline and the notification expires. WhatsApp handles this by using high-priority notifications for messages (which wake the device more reliably) and by doing a catch-up sync when the app comes to the foreground, regardless of whether a notification fired.

flowchart TD;
    A[New Message Arrives];
    B[Recipient Offline Check];
    C[Queue Message];
    D[Send Push Notification];
    E[APNs iOS];
    F[FCM Android];
    G[Device Wakes];
    H[Establish WebSocket];
    I[Flush Message Queue];
    J[Deliver to App];

    A &#8211;> B;
    B &#8211;>|Offline| C;
    C &#8211;> D;
    D &#8211;> E;
    D &#8211;> F;
    E &#8211;> G;
    F &#8211;> G;
    G &#8211;> H;
    H &#8211;> I;
    I &#8211;> J;

    classDef message fill:#2563eb,stroke:#1e40af,color:#ffffff;
    classDef decision fill:#f59e0b,stroke:#b45309,color:#000000;
    classDef queue fill:#9333ea,stroke:#6b21a8,color:#ffffff;
    classDef external fill:#dc2626,stroke:#991b1b,color:#ffffff;
    classDef device fill:#16a34a,stroke:#166534,color:#ffffff;

    class A message;
    class B decision;
    class C,D queue;
    class E,F external;
    class G,H,I,J device;

Notification fanout for group messages is expensive. A group message to 512 people might generate 512 separate push notification API calls. These are batched where possible, but even batched, the volume is enormous. WhatsApp's notification infrastructure sends billions of push notifications per day — this alone requires significant infrastructure to manage the API rate limits, retry failed notifications, and handle APNs/FCM endpoint registration changes (which happen every time a user reinstalls the app).

## Event-Driven Architecture

Most engineers who have not worked on messaging infrastructure are surprised by how central Kafka — or a Kafka-equivalent event streaming system — is to WhatsApp's architecture. It is not just for analytics. Event streaming is the backbone of multiple core workflows.

When a message is delivered, an event fires. When a read receipt is generated, an event fires. When a user connects or disconnects, an event fires. When media is uploaded, an event fires. These events flow through the streaming system and are consumed by multiple independent services.

The notification service consumes delivery events to decide when to send push notifications. The analytics system consumes message events for engagement metrics (with appropriate privacy aggregation). The read receipt service consumes events to generate double-tick updates. The presence service consumes connection events to update online status. Each consumer is independent — it can fail, fall behind, or be updated without affecting the others.

This decoupling is essential at scale. Without it, a single slow operation (like writing analytics data) could block the message delivery pipeline. With event streaming, the pipeline acknowledges the event and moves on, and the slow consumer catches up in its own time.

Event streaming also provides durability. If the notification service goes down for five minutes, it can replay events from the stream when it comes back up and send notifications for messages that arrived during the outage. The stream acts as a durable buffer between producers and consumers.

Kafka's partition model allows horizontal scaling of consumers. A single Kafka topic partitioned by user ID can be consumed in parallel by many consumer instances, each handling a subset of users. Adding more consumer instances increases throughput linearly.

## Database and Storage Design

WhatsApp's storage layer is a mix of different storage systems optimized for different access patterns.

Active messages in transit live in a key-value store optimized for queue-like access (read-then-delete). The key is user ID (or device ID for multi-device), and the value is a list of pending message payloads. This store needs high write throughput and fast reads by key. Cassandra or a similar wide-column store fits this well, because you can key by user ID and the store handles sharding automatically.

Message metadata — message IDs, timestamps, sender/recipient, delivery status — is stored separately from message content for most production systems. The metadata is smaller and needed for many operations (receipt tracking, deduplication) independently of the actual content.

Here is a simplified schema for the core tables:

  
    
      
        Table
        Key Columns
        Storage Type
        Access Pattern
      
    
    
      
        users
        user_id, phone, public_keys, registered_at
        SQL / Distributed KV
        Read-heavy, keyed by user_id and phone
      
      
        messages
        message_id, sender_id, recipient_id, ciphertext, status, sent_at
        Wide-column store
        Write-heavy for delivery, read on sync
      
      
        groups
        group_id, name, created_by, sender_key_version, created_at
        Distributed SQL
        Read-heavy, occasional writes on membership change
      
      
        group_members
        group_id, user_id, joined_at, role
        Distributed SQL
        Read-heavy for fanout, write on add/remove
      
      
        media_assets
        media_id, uploader_id, blob_url, encrypted_key_hash, size, expires_at
        Object storage + metadata DB
        Write once, read many, expire after TTL
      
      
        sessions
        user_id, device_id, server_address, last_heartbeat
        Redis / in-memory store
        Extremely read-heavy, updated on heartbeat
      
      
        delivery_receipts
        message_id, recipient_id, delivered_at, read_at
        Wide-column store
        Write on delivery/read, read by sender
      
    
  

The sessions table deserves special attention. It needs to be extremely fast — every message delivery requires looking up which server holds the recipient's session. This table lives in Redis, not in a database, precisely because database reads (even fast ones) would be too slow when performed billions of times per day.

Group membership is cached aggressively. When you send a group message, the fanout service reads group membership from cache, not from the database. Cache invalidation happens when membership changes — when someone joins or leaves, a cache invalidation event fires and the group membership cache entry is updated.

Partitioning strategy matters enormously. Messages partitioned by user_id means that queries for all messages to/from a specific user are local to one shard. Group membership partitioned by group_id means fanout queries are local. The goal is to avoid cross-shard queries wherever possible, because distributed transactions are expensive and complex.

## Caching System Deep Dive

Caching is not an optimization for WhatsApp — it is a structural necessity. Without aggressive caching, the database load would be orders of magnitude beyond what any database cluster could handle.

The presence cache stores online/offline status and last-seen timestamps for all active users. This cache is read millions of times per second — every time a conversation is opened, every time a message is sent (to decide whether to push a notification), every time the conversation list is rendered. The data needs to be fresh within seconds. WhatsApp uses Redis with a short TTL and write-through updates when presence changes.

The session cache maps user IDs to the server addresses holding their connections. This is the most read-intensive cache in the system — it is consulted on literally every message delivery. It needs to be not just fast but also correct — routing a message to a stale server address means the message cannot be delivered. Invalidation happens immediately when a user disconnects or reconnects.

The group membership cache stores the member list for each group. For active large groups (high-traffic groups with hundreds of members), this cache entry is read thousands of times per day — once per message sent to the group. Cache invalidation on membership changes must happen immediately and atomically to avoid fanout to stale members.

The encryption key cache stores recently fetched public keys for session establishment. When you first message someone, the sender's device fetches their public keys from the key server. These keys change infrequently (only when pre-keys are rotated), so they can be cached for minutes to hours. The cache dramatically reduces load on the key server and reduces the latency of establishing new sessions.

Cache stampede is a real risk at this scale. If a popular group's cache entry expires, hundreds of concurrent fanout operations might simultaneously try to read from the database to repopulate the cache. WhatsApp uses a combination of probabilistic early expiration (refresh the cache slightly before it actually expires) and mutex locks on cache repopulation to prevent this.

Hotspot management is particularly important for viral content. A forwarded video in a large community can suddenly generate tens of thousands of concurrent media download requests. The CDN handles most of this, but for presence data and group membership of super-large groups (broadcast channels with millions of subscribers), special hotspot mitigation is needed — local caching on messaging server nodes, read replicas, and request coalescing.

## Scalability Deep Dive

Real-time encrypted messaging is one of the hardest scaling problems in software engineering. Let us be specific about why.

WebSocket scalability is the first challenge. Each connected user consumes a persistent TCP connection on a server. A server with 1 million open connections is expensive — you need significant RAM for connection state, careful tuning of OS limits, and efficient I/O multiplexing. WhatsApp's Erlang infrastructure handles this by making each connection very lightweight (a few kilobytes of state) and using Erlang's highly efficient scheduler to handle I/O events without blocking.

Encryption bottlenecks are surprisingly significant at scale. AES encryption is fast on modern hardware, but the initial session establishment (the X3DH handshake) involves elliptic curve Diffie-Hellman operations, which are CPU-intensive. At millions of new sessions per hour (users getting new devices, reinstalling, linking new laptops), the key exchange service is under significant load. Hardware security modules and specialized cryptographic accelerators help, but this remains an ongoing scaling concern.

  
    
      
        Bottleneck
        Root Cause
        Mitigation Strategy
        Remaining Challenge
      
    
    
      
        WebSocket connections
        Each user needs a persistent connection
        Erlang lightweight processes, efficient I/O
        Memory pressure on high-connection servers
      
      
        Group fanout
        One message writes to N queues
        Async fanout workers, Sender Key protocol
        Very large groups still generate massive write load
      
      
        Session lookup
        Every message delivery queries session store
        Redis in-memory session store
        Redis cluster size and replication lag
      
      
        Key exchange
        EC DH operations are CPU-intensive
        Hardware acceleration, caching
        Scale of new device registrations
      
      
        Push notifications
        Billions of APNs/FCM API calls per day
        Batching, priority queuing, retries
        APNs/FCM rate limits and reliability
      
      
        Media storage
        Enormous media upload volume
        Client-side compression, CDN, TTL expiry
        Storage cost at global scale
      
    
  

Multi-region deployment is how WhatsApp handles global scale. Users in Europe connect to European data centers. Users in Asia connect to Asian data centers. Messages between users in different regions flow through inter-region links, which WhatsApp optimizes with dedicated backbone connections (rather than the public internet) to ensure low latency.

Data residency requirements in different countries add regulatory complexity to multi-region deployments. Some jurisdictions require that user data be stored within their borders. This influences how WhatsApp partitions user data across regions.

Horizontal scaling of stateless services is straightforward — add more servers, distribute load with a load balancer. The hard parts are the stateful components: the WebSocket servers holding connections, the session store, the message queues. WhatsApp uses consistent hashing to distribute users across server clusters in a way that minimizes reassignment when cluster size changes.

## Reliability and Availability

A messaging platform at WhatsApp's scale experiences every possible failure mode simultaneously, somewhere in the world, at all times. Engineering for reliability means engineering for graceful degradation — when things break (and they will), minimizing the impact on users.

Multi-region redundancy means that a data center outage does not take down the service. Users are rerouted to a secondary region, they reconnect, and messaging continues with only a brief disruption. This requires active-active replication of session state and message queues across regions, which is expensive and complex but necessary.

Message durability is guaranteed by writing messages to persistent storage before acknowledging them to the sender. This means if the server crashes immediately after writing, the message survives and will be delivered when the recipient reconnects. The trade-off is that the write to storage adds latency to the acknowledgement — typically tens of milliseconds.

The monitoring stack needs to be comprehensive. Metrics on every component: connection counts, message delivery latency percentiles, queue depths, encryption operation rates, APNs/FCM success rates. Distributed tracing to track a message through every hop of the delivery pipeline. Alerting on anomalies. WhatsApp uses a combination of open-source tools and custom-built monitoring infrastructure.

Presence system failures are particularly tricky. If the presence cache becomes stale (due to a cache invalidation failure), users see incorrect online status. This is a non-critical failure — messages still flow — but it degrades user experience. WhatsApp handles this by having presence servers cross-check cache with a slower authoritative source when discrepancies are detected.

## Security Architecture

Security is not a feature layer on top of WhatsApp — it is woven into every part of the architecture. We have covered end-to-end encryption in detail, but there are other security dimensions worth discussing.

Device authentication prevents unauthorized devices from sending or receiving messages on your account. When you register WhatsApp, your phone number is verified via SMS. The private key generated during registration is tied to your specific device and account. When you link a new device, the existing trusted device (phone) must authorize the linking. This trust chain makes account takeover significantly harder.

Replay protection is built into the Signal Protocol. Each message has a unique message ID and sequence number. If someone captures an encrypted message and replays it later, the Double Ratchet's counter-based key derivation will reject it — the key for that sequence position has already been advanced past.

Secure backups are opt-in and use end-to-end encryption even for the backup itself. The backup encryption key is derived from your account credentials and stored in a hardware security module (in WhatsApp's key vault infrastructure), requiring your account password to retrieve. This means WhatsApp cannot read your backup even if they have physical access to the backup storage.

Spam and abuse prevention at scale without breaking end-to-end encryption is genuinely hard. WhatsApp cannot read message content to detect spam. Instead, they rely on: rate limiting by sender, reporting mechanisms (when you report a message, a copy of recent messages from that sender is submitted to WhatsApp in a privacy-preserving way), metadata analysis (sending patterns, network graphs, account age), and community-level signals (mass blocking of an account is a strong spam signal).

## Engineering Tradeoffs

Every architecture decision in WhatsApp involves real tradeoffs. Let us talk about the ones that matter most.

Encryption versus operational visibility is the most fundamental tension. End-to-end encryption means WhatsApp cannot read messages to debug delivery issues, investigate abuse, or provide customer support. When a user says &ldquo;I sent a message and it never arrived,&rdquo; the support team cannot look at the message to diagnose the problem. They can only look at metadata: did the server receive it, did the server route it, did the server queue it. This is an intentional design choice, but it makes operations and abuse prevention significantly harder.

Real-time delivery versus battery consumption is a constant balancing act on mobile. Keeping a persistent connection alive maximizes delivery speed but drains battery. Disconnecting aggressively saves battery but increases latency and push notification dependency. WhatsApp tunes connection behavior based on platform (iOS vs Android), charging status, network type, and app foreground/background state.

Message durability versus latency is a classic distributed systems tradeoff. Writing a message to durable storage before acknowledging it to the sender adds latency (the storage write takes time) but provides a delivery guarantee. Acknowledging first and writing asynchronously improves latency but risks losing the message if the server crashes between the ACK and the write. WhatsApp acknowledges after the write, choosing durability over raw latency.

Caching versus consistency trades fast reads for potential staleness. Cached group membership might be slightly out of date — someone who just joined a group might not receive a message sent in the first second after they join, because the fanout service read the old cached membership. These edge cases are accepted because the alternative (no caching) would make the system orders of magnitude slower.

Multi-device synchronization versus implementation complexity is perhaps the clearest tradeoff. Supporting one device per account is dramatically simpler — one set of keys, no synchronization, no secondary delivery. Adding multi-device support (even limited to four linked devices) required a fundamentally new session architecture, new key distribution protocols, and new synchronization infrastructure. WhatsApp delayed this feature for years precisely because the engineering cost was high.

## Real-World Technology Stack

WhatsApp made several technology choices early that were unusual at the time and have served them well.

Erlang powers the messaging server layer. The choice was driven by Erlang's strengths: the actor model naturally maps to connection-per-process, the runtime is battle-tested for telecom-grade reliability, and Erlang's OTP framework provides supervision trees and hot code reloading that enable updates without downtime. The tradeoff is a smaller talent pool — finding Erlang engineers is harder than finding Java engineers.

FreeBSD was WhatsApp's original operating system choice, preferred over Linux for its networking stack performance and specific tuning properties for high-connection-count servers. Most of the industry runs Linux, so this was an unusual choice, but WhatsApp had deep expertise in FreeBSD and found it performed better for their workload.

C++ is used in performance-critical components of the client and server where every microsecond matters — particularly in the encryption and media processing layers. Modern C++ with careful memory management can outperform Java or Go significantly in latency-critical paths.

The Signal Protocol is not WhatsApp's invention, but their adoption of it (in partnership with Signal's creators) was a landmark moment in messaging security. The protocol handles the cryptographic complexity so the application layer can focus on product features.

WebRTC provides the media transport for calls. Building a custom real-time audio/video protocol from scratch would be enormously expensive and risky. WebRTC is well-tested, has hardware acceleration on most platforms, and handles the hard problems (congestion control, packet loss recovery, codec negotiation) out of the box.

Kafka (or a similar stream processing system) underpins the event-driven architecture. The ability to replay events, scale consumers independently, and provide durable message streams is essential to WhatsApp's architecture.

Redis serves as the primary cache layer. Its single-threaded, in-memory design provides predictable sub-millisecond latency that is critical for session lookup and presence data. Redis Cluster provides horizontal scaling and replication.

  
    
      
        Technology
        Role in WhatsApp
        Why This Choice
      
    
    
      
        Erlang
        Messaging server layer, connection management
        Lightweight processes, fault tolerance, hot reloading
      
      
        FreeBSD
        Server operating system
        Network stack tuning for high connection counts
      
      
        C++
        Encryption, media processing, client performance
        Maximum performance in latency-critical paths
      
      
        Signal Protocol
        End-to-end encryption, key management
        Battle-tested, forward secrecy, double ratchet
      
      
        WebRTC
        Voice and video calling, media transport
        Real-time media, NAT traversal, adaptive bitrate
      
      
        Kafka
        Event streaming, async processing pipeline
        Durable, replayable, horizontally scalable
      
      
        Redis
        Session cache, presence cache, group membership
        Sub-millisecond reads, simple data structures
      
      
        CDN
        Media delivery, geographic distribution
        Low-latency media serving globally
      
      
        XMPP/WebSockets
        Client-server persistent connection protocol
        Bidirectional, real-time, works on mobile
      
    
  

## System Design Interview Perspective

WhatsApp-style system design questions appear frequently in senior engineering interviews at companies like Meta, Google, Amazon, and Stripe. Understanding not just what WhatsApp does, but why it is designed the way it is, is what separates strong candidates from weak ones.

A typical question sounds like: &ldquo;Design a real-time messaging system like WhatsApp. Walk me through your approach.&rdquo; The interviewer is not looking for a perfect answer — they are evaluating how you think about distributed systems, scalability, tradeoffs, and reliability.

Strong candidates start by clarifying scope. One-to-one only, or groups? End-to-end encryption or not? Multi-device? What scale — how many daily active users, messages per day, average group size? These questions show engineering maturity and help you tailor the design to the problem.

Then establish the core architecture before diving into specifics. Clients connect persistently to messaging servers. Messaging servers route messages. A session store tracks which server holds each user's connection. A message queue holds offline messages. Push notifications handle offline delivery. This is the skeleton — get this right before adding detail.

The WebSocket scaling question almost always comes up. How do you handle millions of persistent connections? Know the Erlang answer, know the stateful routing problem, know that you need a session registry, and know that connection servers cannot be completely stateless.

End-to-end encryption is a differentiator. Most candidates treat it as a footnote. Strong candidates explain the Signal Protocol at a high level, explain why the server cannot read messages, and explain the key distribution problem. You do not need to know the Double Ratchet mathematics — but you should know that forward secrecy exists and why it matters.

Group messaging fanout is a great discussion point. How do you deliver a message to 512 people efficiently? What is the write amplification? What is the Sender Key protocol and why does it exist? What happens when someone joins or leaves the group mid-conversation? Candidates who think through these edge cases demonstrate real distributed systems intuition.

Common mistakes include: treating this as a CRUD application with a WebSocket layer (messaging is much more complex than that), ignoring offline delivery entirely, forgetting that mobile clients are unreliable and reconnect constantly, not discussing encryption at all, and jumping to optimization before establishing correctness.

The best answers also discuss what you would not build first. A strong candidate says: &ldquo;In a first version, I would start with simple delivery without multi-device support, use a simple queuing mechanism for offline delivery, and defer encryption to a second iteration.&rdquo; This shows that you understand engineering prioritization, not just theoretical design.

When discussing scalability, be specific. &ldquo;Add more servers&rdquo; is not an answer. Explain how you partition the session store, how you handle group fanout with sharded workers, how you use Redis clustering for the presence cache, and how multi-region deployment handles geographic latency. Specificity signals real experience or real preparation.

The conversation will often end with tradeoffs: &ldquo;What is the hardest thing about building this?&rdquo; The strongest answers pick a real hard problem — encryption key management across devices, group fanout at extreme scale, maintaining consistency in the presence system without excessive chattiness — and explain why it is genuinely hard, what the engineering options are, and what you would choose.

Interviewers at messaging companies will push on production reliability. What happens when the push notification service goes down? What happens when a server holding ten thousand WebSocket connections crashes? What happens when the session store has a hot key? These failure scenarios reveal whether you are thinking about systems that actually run in production or systems that only exist in architecture diagrams.

## Closing Thoughts

WhatsApp's technical depth is extraordinary. The more you understand about why each component exists and what problem it solves, the better you will perform not just in system design interviews, but in building real distributed systems. Every architectural pattern in WhatsApp — the persistent connection model, the Signal Protocol, the Sender Key for groups, the event-driven fanout, the cache-first session routing — exists because someone encountered a real problem at real scale and had to think carefully about the solution.

The best engineers are not the ones who memorize architectures. They are the ones who understand the problems deeply enough that they could rediscover the right architecture on their own. WhatsApp's architecture is a product of that kind of thinking, applied consistently over many years at extraordinary scale.
