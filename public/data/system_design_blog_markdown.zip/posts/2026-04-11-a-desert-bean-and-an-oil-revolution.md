---
title: "A Desert Bean and an Oil Revolution"
date: "2026-04-11T17:31:23+05:30"
slug: "a-desert-bean-and-an-oil-revolution"
categories: ["oil", "case_study"]
original_url: "https://rishijeet.github.io/blog/a-desert-bean-and-an-oil-revolution/"
word_count: 2827
reading_time: "14 min"
author: "Rishijeet Mishra"
---

# A Desert Bean and an Oil Revolution

*Published on 2026-04-11 by Rishijeet Mishra | [https://rishijeet.github.io/blog/a-desert-bean-and-an-oil-revolution/](https://rishijeet.github.io/blog/a-desert-bean-and-an-oil-revolution/)*

How a nation that once begged OPEC for oil became the world's largest producer, with a little help from Rajasthan's desert farmers

![Alt text](https://rishijeet.github.io/images/2026/oil.jpg)

## The Smell of Dependence

Picture this. It is October 1973. Richard Nixon is in the White House. The Vietnam War is winding down. And in the Middle East, a coalition of Arab nations has just made a decision that will bring the most powerful economy on Earth to its knees.

In retaliation for American support of Israel during the Yom Kippur War, the Arab members of OPEC, led by Saudi Arabia, announced an oil embargo against the United States. Overnight, the taps were turned off. Oil prices quadrupled from $3 to $12 a barrel. Petrol stations ran dry. Americans queued for hours, sometimes all night, just to fill their tanks. The speed limit on highways was slashed to 55 mph to conserve fuel. The lights on the Christmas tree at Rockefeller Center were dimmed. The world's richest country was brought to a standstill by a commodity it did not control.

That was the moment America truly understood its vulnerability.

But here is what makes that story even more remarkable. It did not have to be that way. The United States had been the world's dominant oil producer for most of the 20th century. It was an American, Edwin Drake, who drilled the first commercial oil well in Titusville, Pennsylvania, in 1859. It was American companies like Standard Oil, Texaco, and Gulf that built the global oil industry. It was American engineers who first discovered oil in Saudi Arabia in 1938. America created the oil world. And then, slowly, it became enslaved to it.

How did that happen? And how did America fight its way back to the top, helped unexpectedly by a humble bean from the deserts of Rajasthan? That is the story we are about to tell.

## The Century of Plenty, and Then the Cliff

From the late 1800s through the mid-20th century, the United States was swimming in oil. Texas, Oklahoma, California, Louisiana. Oil gushed from the ground with almost comical ease. In 1901, the Spindletop well in Beaumont, Texas, erupted with such force that it took nine days to cap it. When it finally stabilised, it was producing more oil per day than all other American wells combined. It was the single most consequential oil discovery in history.

![Alt text](https://rishijeet.github.io/images/2026/spindletop.avif)

Spindletop Oil Field

For decades, America's domestic production was more than sufficient. It powered two World Wars. It kept the factories running. It built the automobile culture, the highways, suburbs and drive-ins, that became synonymous with American identity. At its peak in 1970, the United States was producing 9.6 million barrels a day.

And then it began to decline.

The problem was simple geology. The easy, shallow, cheap-to-extract oil was running out. Production peaked in 1970, a fact predicted almost exactly a decade earlier by geologist M. King Hubbert in what became known as Hubbert's Peak theory. As domestic production fell, imports rose to fill the gap. By 1973, the United States was importing over 6 million barrels a day, with a significant chunk coming from the Arab world.

Enter the embargo. Enter the queues. Enter the humiliation.

## The Long Dependency

After the shock of 1973, America made bold declarations about energy independence. President Nixon launched Project Independence. President Carter installed solar panels on the White House roof. But the declarations faded, the solar panels were removed by Reagan, and the imports kept rising.

Through the 1980s, 1990s, and 2000s, the United States became progressively more dependent on Middle Eastern oil. The top source countries for American petroleum imports included Saudi Arabia, Iraq, and other Gulf states, alongside Canada and Mexico. At the peak of dependence in the early 2000s, America was importing close to 12 million barrels a day, sending hundreds of billions of dollars to foreign governments, some of whom were ideologically hostile.

The strategic implications were enormous. American foreign policy became tangled in the Persian Gulf. The United States maintained a massive military presence in the region, aircraft carriers in the Arabian Sea, bases in Saudi Arabia, diplomatic partnerships with kingdoms whose human rights records were troubling, all at least in part to protect the oil supply.

The Gulf War of 1990 to 1991, when Saddam Hussein invaded Kuwait, was ostensibly about sovereignty. But everyone understood the subtext. Kuwait's oil fields, which held about 10% of global reserves, could not fall into hostile hands. American soldiers died in the desert sands to protect the world's energy supply.

Then came 9/11. Fifteen of the nineteen hijackers were Saudi nationals. The uncomfortable relationship between American security and Saudi oil grew even more fraught. The dependency was costing America not just money. It was costing lives, influence, and moral clarity.

Something had to change.

## The Revolution Underground

The revolution, when it came, did not come from Washington. It did not come from Big Oil boardrooms or military strategy. It came from a stubborn Texas oilman named George Mitchell.

Through the 1980s and 1990s, Mitchell, the founder of Mitchell Energy, became obsessed with an idea that most people in the industry considered insane: extracting oil and gas from shale rock, a dense and impermeable formation that held enormous reserves but gave up its contents grudgingly, if at all.

The conventional wisdom said it was impossible. Shale rock does not flow. You cannot pump oil out of solid rock. Mitchell did not listen.

After years of costly experimentation, his team cracked the code in 1998 using a technique called hydraulic fracturing, or fracking. The idea was simple in concept. Drill down into the shale, turn the drill sideways using horizontal drilling, and then pump millions of litres of water, sand, and chemicals into the rock at enormous pressure. The pressure fractures the rock. The sand holds the fractures open. And the oil and gas flows out.

![Alt text](https://rishijeet.github.io/images/2026/shale-gas-extraction.png)

Shale fracking

Mitchell sold his company to Devon Energy in 2002 for $3.1 billion. Devon combined hydraulic fracturing with horizontal drilling, and the results were staggering. The shale revolution had begun.

Within a decade, the Permian Basin in Texas, the Bakken Formation in North Dakota, and the Eagle Ford shale in southern Texas were producing oil at a scale no one had imagined possible. By 2018, the United States had surpassed Saudi Arabia and Russia to become the world's largest oil producer, a title it had not held since 1970.

It was one of the most dramatic industrial reversals in history.

## The Secret Ingredient: How Rajasthan Fed the American Oil Boom

Now here is the part of the story that almost nobody knows. The part that connects the oil derricks of West Texas to the dusty fields of northwestern India. The part that involves a humble, drought-resistant bean called guar, and how it quietly powered the greatest energy revolution of the 21st century.

To understand the connection, you need to understand what fracking actually requires. When a fracking crew pumps fluid into a shale well, they are not using plain water. They need a substance that can thicken the water into a viscous gel that carries tiny grains of sand deep into the fractures at high pressure, holds them in suspension, and then breaks down cleanly after the job is done. It needs to be extraordinarily effective. It needs to be available in massive quantities. And it needs to be cheap enough to use by the million pounds.

![Alt text](https://rishijeet.github.io/images/2026/guar.jpg)

Guar Plant

The only substance on Earth that ticked all those boxes was guar gum. It is a powder made from the seeds of the guar bean, a desert legume that has grown in Rajasthan and Gujarat for centuries. For generations, it was used as cattle feed and occasionally cooked as a poor man's vegetable curry. Nobody in Texas had ever heard of it. Nobody in the global oil industry had ever cared about it.

And then the fracking boom arrived and changed everything.

India produces around 90% of the world's guar, and roughly 72% of that comes from Rajasthan alone. There is simply no substitute of comparable scale, reliability, or cost. American frackers needed Indian guar. That was the beginning and the end of the matter.

The scale of what happened next is almost hard to believe. Between 2006 and 2011, North American fracking companies quadrupled the amount of guar gum they were consuming, driving usage up to one billion pounds in 2011. A single shale well typically consumed around 4,000 kilograms of guar gum. By 2012, Halliburton alone was using 14 million pounds of guar gum every single month.

Read that again. Fourteen million pounds. Per month. From a single company.

India's exports of guar gum shot up from roughly $20 million in 2003 to $3.5 billion in 2012 to 2013, and nearly 80% of those exports were going directly to shale gas producers in the United States. Guar had gone from being India's most ignored agricultural crop to its single largest farm export almost overnight.

The price followed the demand. Before the shale boom, a tonne of guar gum sold for around $2,000. By 2012, that same tonne was fetching $28,000. That is a 1,400% increase in just a few years. The guar price was rising so fast that Indian commodity exchanges actually halted futures trading to allow for a government inquiry. Panic buying had set in. Prices were doubling week by week.

The impact on Rajasthan was seismic.

Farmers who had spent generations scratching out a living on sandy, arid soil suddenly found themselves sitting on what locals began calling their own black gold. In the city of Jodhpur, under the shadow of an ancient fort, traders were buying guar seed at ten times the price they had paid just a year earlier. Farmers were clearing debts they had carried for decades. They were building concrete houses. Buying tractors, televisions, and mobile phones. Funding lavish weddings. Sending their children to school.

One farmer named Shivlal made five times his usual seasonal income from just five acres of guar planted in sandy Rajasthan soil. He built a concrete house and bought a colour television. He told reporters he was planning to grow guar on his rooftop the following season.

![Alt text](https://rishijeet.github.io/images/2026/guar_export.ppm)

Guar Gum Export Trend

A company called Vikas WSP, based in Rajasthan, distributed 3,000 metric tonnes of guar seeds to 200,000 Indian farmers, encouraging them to abandon cotton and lentils and switch to guar. In 2011, guar became India's single largest agricultural export to the United States, with sales reaching $915 million in one year.

The American shale revolution, the greatest domestic energy comeback in history, was now dependent on the monsoon rains of Rajasthan. Oil executives in Houston were watching Indian weather forecasts with genuine anxiety. If the monsoon failed, guar supplies would tighten. If guar supplies tightened, fracking costs would rise. If fracking costs rose too sharply, the shale boom itself could slow.

Workers on oil rigs in West Texas and North Dakota had no idea. But somewhere in the supply chain that kept their drills turning, a Rajasthani farmer was deciding how many acres to plant that season. The two worlds were connected by a little green bean that most Americans could not have named or recognised.

It is one of the most extraordinary and underreported supply chain stories in modern industrial history.

## The Numbers: How Big Did America Get?

The statistics of America's shale-driven oil renaissance are genuinely staggering.

In 2008, the United States was producing around 5 million barrels of oil a day and importing nearly twice that. A decade later, the picture had completely reversed. By 2023, the United States was producing a record 13.5 million barrels of crude oil per day, up 9% from the year before. It was exporting oil to 173 countries. Oil exports alone brought in $117 billion in 2023. In 2024, the United States exported 55% of its entire crude oil and natural gas liquids production, setting new records for both production and export volume.

![Alt text](https://rishijeet.github.io/images/2026/us_prod.svg)

US Production of Crude Oil since 1920

The total revenue of the American oil and gas industry reached $244 billion in 2023, even after declining from a peak of $330 billion in 2022, when oil prices spiked following Russia's invasion of Ukraine.

America had gone from supplicant to supplier. And the Permian Basin alone was producing more oil per day than any single OPEC member nation.

## The Paradox: Why America Still Imports Oil

Here is where many people get confused. If America is the world's largest oil producer, why does it still import millions of barrels a day?

The answer is engineering, not economics.

American shale oil, particularly from the Permian Basin, is predominantly light sweet crude. It is low in sulfur and relatively easy to refine into petrol and diesel. It is excellent oil. But here is the problem. Most American oil refineries, built decades ago when the country was importing from the Middle East and Venezuela, were specifically designed to process heavy sour crude. That is the thick, high-sulfur oil that Saudi Arabia, Mexico, and Canada produce.

You cannot simply swap one type of crude for another in a refinery built for a different feedstock. Retrofitting or rebuilding refineries costs billions of dollars and takes years. So the United States exports its light shale oil to Europe and Asia, where refineries are set up to handle it, and simultaneously imports heavy crude from Canada, Mexico, and Saudi Arabia for its Gulf Coast refineries.

In 2023, the United States imported about 8.5 million barrels per day while exporting about 10.15 million barrels per day, making it a net petroleum exporter of around 1.64 million barrels per day.

It sounds paradoxical. It is entirely rational. America sells what it has, buys what its machinery needs, and profits in the process.

## The Money: What Does America Actually Earn?

Oil is not just an energy story. It is one of the biggest economic stories in the world.

The U.S. oil and gas sector directly employs over 150,000 people in extraction, and supports millions more in refining, transportation, equipment manufacturing, and services. Oil is the second largest U.S. export commodity by value, accounting for nearly 6% of all American exports. American crude oil and petroleum products now flow to Europe, South Korea, Japan, India, China, and dozens of other nations.

The shale revolution also reshaped geopolitics in ways that would have seemed impossible in 1973. When Russia invaded Ukraine in 2022 and European nations scrambled to replace Russian gas, it was American LNG tankers that sailed across the Atlantic to keep European homes heated that winter. Energy had become a weapon of statecraft, and America was now one of the largest arsenals.

## A Reversed World Order

The story of America's oil journey is ultimately a story about vulnerability, ingenuity, and the unexpected ways the global economy connects people who will never meet.

It is the story of a superpower humiliated at petrol stations in 1973, forced to tie its foreign policy to desert kingdoms for five decades, and then engineering a reversal so complete that it now exports oil to 173 countries across the world.

It is the story of George Mitchell, who refused to accept that the rock would not yield. Of engineers who figured out how to drill sideways. Of a technology that was messy, controversial, and environmentally fraught, but undeniably transformative.

And it is, improbably, the story of a small green bean in the Thar Desert.

When American shale production took off, it brought extraordinary prosperity to farmers living 21,000 kilometres away in Rajasthan who had never heard of the Permian Basin. Farmers who did not know what a shale formation was. Farmers who simply grew what the desert allowed them to grow and found, to their astonishment, that the world's most powerful industry could not function without them.

As one farmer's wife in Sri Ganganagar told reporters at the time: &ldquo;Everyone in the village is now growing guar. No one talks of anything else. It has changed the village. If you came here two years ago, you would not see joy on anyone's face.&rdquo;

That is the real story of the American oil revolution. Not just Texas and North Dakota. Not just Halliburton and ExxonMobil. But also Rajasthan. Also guar. Also a farmer named Shivlal who built a concrete house and bought a colour television because Texas needed his beans to crack open rocks half a world away.

Oil has always connected the world in ways we do not fully see until we look closely. America's journey from dependence to dominance is perhaps the most dramatic illustration of that truth the modern era has produced.

And it is not over yet.

As America pushes toward renewables, as electric vehicles begin to reshape petrol demand, as solar and wind transform the electricity grid, oil remains stubbornly irreplaceable in plastics, aviation, shipping, and petrochemicals. The shale revolution bought the world time. What the world does with that time is the next chapter of the story.
