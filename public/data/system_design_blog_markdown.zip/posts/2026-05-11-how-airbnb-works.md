---
title: "How Airbnb Works?"
date: "2026-05-11T09:21:17+05:30"
slug: "how-airbnb-works"
categories: ["system_design", "architecture", "airbnb", "booking", "technology"]
original_url: "https://rishijeet.github.io/blog/how-airbnb-works/"
word_count: 6532
reading_time: "33 min"
author: "Rishijeet Mishra"
---

# How Airbnb Works?

*Published on 2026-05-11 by Rishijeet Mishra | [https://rishijeet.github.io/blog/how-airbnb-works/](https://rishijeet.github.io/blog/how-airbnb-works/)*

> Every time you search for a place to stay in Tokyo, lock in a booking for next weekend in Lisbon, or message a host about parking — you're touching a system that handles millions of concurrent users, real-time availability across 7 million listings, payment transactions in dozens of currencies, and geo-spatial searches across the entire planet. Let's pull back the curtain.

![Alt text](https://rishijeet.github.io/images/system_design/airbnb.png)

Airbnb is one of the most fascinating systems to think about from an engineering standpoint. Not because any single piece is extraordinarily novel on its own, but because the combination of problems they have to solve simultaneously is genuinely hard.

You have geo-spatial search that needs to return results in under 200ms. You have a booking system that must never double-book a property, even when two guests are clicking &ldquo;Reserve&rdquo; at the exact same millisecond. You have dynamic pricing that shifts based on local events, season, and demand signals. You have payments flowing across 220+ countries with fraud detection running on every transaction. And you have to do all of this reliably for a platform where a single outage during peak travel season means real money lost for real hosts around the world.

As of recent years, Airbnb has over 7 million active listings in 220+ countries, serves hundreds of millions of guest arrivals per year, and sees traffic spikes that correlate with holiday seasons, major events, and even viral social media moments. That's the scale we're designing for.

Let's get into it.

## Core Features and Why They're Harder Than They Look

Before diving into architecture, it's worth understanding what Airbnb actually does — and specifically what makes each feature technically interesting.

Property Listings: Hosts create listings with photos, descriptions, amenities, house rules, and availability calendars. Simple to describe, but storing and serving millions of rich media listings at low latency requires careful thinking about storage, CDN strategy, and search indexing.

Search: Guests search by location, dates, guest count, price range, and amenities. The geo-spatial nature of this — &ldquo;show me listings within a 5km radius of these coordinates&rdquo; — combined with real-time availability filtering makes this one of the hardest search problems at scale.

Booking: A guest selects dates and clicks Reserve. The system must verify availability in real-time, hold the inventory, process payment, and confirm the booking — all without any other guest booking the same property for the same dates in that window. Race conditions here are not hypothetical; they happen constantly at scale.

Availability Calendar: Each listing has a calendar showing which dates are blocked (already booked, or blocked by the host) and which are open. This calendar must stay consistent across the host's interface, the guest-facing search, and the booking system simultaneously.

Dynamic Pricing: Hosts can set base prices, but Airbnb's smart pricing system suggests (and with Smart Pricing enabled, automatically adjusts) nightly rates based on local demand, comparable listings, seasonal patterns, and upcoming events. Computing this in real-time for millions of listings is a significant data pipeline challenge.

Reviews and Messaging: Both reviews and the host-guest messaging system sound straightforward. But reviews have integrity concerns (preventing fake reviews, handling disputes), and messaging needs to work reliably even when either party is offline, with proper notification delivery across email, SMS, and push.

Each of these features alone would be a substantial engineering problem. Airbnb runs all of them simultaneously at global scale.

## High-Level Architecture

Let's start with the 30,000-foot view and then drill down.

flowchart TB;

subgraph Clients
A1[Web Browser];
A2[iOS App];
A3[Android App];
end;

subgraph CDN
B[Static Assets Images Map Tiles];
end;

subgraph Gateway
C[Rate Limiting Auth Routing];
end;

subgraph Core
D1[Listing Service];
D2[Search Service];
D3[Booking Service];
D4[Payment Service];
D5[User Service];
D6[Messaging Service];
D7[Notification Service];
D8[Pricing Service];
D9[Review Service];
end;

subgraph Streaming
E[Async Event Streaming];
end;

subgraph Data
F1[PostgreSQL];
F2[Elasticsearch];
F3[Redis];
F4[Amazon S3];
F5[Cassandra];
end;

A1 &#8211;> B;
A2 &#8211;> B;
A3 &#8211;> B;
B &#8211;> C;
C &#8211;> D1;
D1 &#8211;> E;
E &#8211;> D7;
D1 &#8211;> F1;

This diagram gives you the skeleton. Now let me explain each layer and why it's designed this way.

CDN Layer: The first interceptor for all traffic. Airbnb serves listing photos, static JavaScript bundles, CSS, and map tiles from edge nodes distributed globally. The goal is to serve as much as possible without ever hitting the origin servers. A guest in Singapore loading a listing page should get images from a CDN node in Singapore, not from a data center in Virginia.

API Gateway: Every API request from mobile or web flows through a centralized gateway. This is where authentication tokens are validated, rate limiting is enforced (so no single client can hammer your APIs), and requests are routed to the correct downstream service. The gateway is also where you implement cross-cutting concerns like request logging and circuit breaking.

Microservices: Airbnb started as a Rails monolith (as many startups do) and gradually decomposed into services as different domains scaled at different rates. The search team needed to iterate on ranking independently of the booking team. The payment system needed stricter deployment controls than the review system. Microservices solve the organizational and scaling problem simultaneously — each service can be scaled, deployed, and maintained independently.

Kafka Event Bus: The connective tissue between services. When a booking is confirmed, the Booking Service publishes a  event to Kafka. The Notification Service picks it up and sends emails. The Pricing Service picks it up and recalculates availability-based demand scores. The Calendar Service picks it up and updates the listing's availability. Nobody is directly coupled to anybody else.

## Search System Deep Dive

Search is where Airbnb earns its reputation for engineering sophistication. It is not a simple keyword search. It is a geo-spatial, date-filtered, availability-aware, personalized ranking problem that must return results in under 200 milliseconds.

### The Query Anatomy

When a guest searches &ldquo;Paris, France — July 4–10, 2 guests, max $200/night,&rdquo; the search system needs to:

- Find all listings within a reasonable radius of Paris

- Filter to those that are available for all nights from July 4 to July 10

- Filter to those that accommodate at least 2 guests

- Filter to those priced at $200 or under

- Rank the results by a combination of relevance, quality, and personalization signals

- Return paginated results with photos, price, and ratings

Each of these steps has scaling implications.

### Geo-Spatial Indexing

The core challenge is step 1: &ldquo;find listings near Paris.&rdquo; You cannot do this with a simple SQL query scanning millions of rows. You need a spatial index.

GeoHash is one of the most common approaches. GeoHash divides the world into a grid of cells, each represented by a short string. The key property is that strings that share a prefix are geographically close to each other. A listing with GeoHash  is near any other listing starting with . This lets you turn a radius query into a prefix query — orders of magnitude faster.

For a city-level search, you might use precision 5 or 6 to find candidate cells, then compute exact distances only for candidates. This two-phase approach — coarse candidate retrieval followed by fine-grained filtering — is the backbone of geo search at scale.

QuadTree is an alternative. Instead of a fixed grid, a QuadTree recursively subdivides space into quadrants based on listing density. Areas with many listings (Manhattan) get finer subdivisions. Areas with few listings (rural Montana) stay coarse. This adapts better to uneven distribution but is more complex to implement and maintain.

Airbnb uses Elasticsearch (now OpenSearch-compatible) as its primary search index. Elasticsearch has native support for geo-point fields and geo queries, which abstracts a lot of the spatial indexing complexity while still leveraging inverted indexes for filtering.

### The Search Flow

flowchart LR;

%% Nodes
A[Guest Search Request];
B[Search Service];
C[Parse and Validate Query];
D{Check Redis Cache same query seen recently};
E[Return Cached Results];
F[Build Elasticsearch Query];
G[Geo Filter Date Filter Price Filter Amenity Filter];
H[Retrieve Candidate Listings];
I[Fetch Availability from Booking Service];
J[Apply Ranking Model quality and personalization];
K[Store in Cache TTL 60s];
L[Return Paginated Results];

%% Flow
A &#8211;> B;
B &#8211;> C;
C &#8211;> D;

D &#8211;>|Cache Hit| E;
D &#8211;>|Cache Miss| F;

F &#8211;> G;
G &#8211;> H;
H &#8211;> I;
I &#8211;> J;
J &#8211;> K;
K &#8211;> L;

One subtle challenge here is the availability check in step I. Elasticsearch holds listing metadata, but real-time availability (which dates are blocked) lives in the booking system. Doing a live availability check for every candidate listing on every search query would be prohibitively expensive. The solution is a periodic sync: the booking system publishes availability updates to Kafka, and a consumer updates the availability data in Elasticsearch. There's a small lag — usually under a minute — but for search results this is acceptable. The final availability confirmation happens at booking time, not at search time.

### Ranking

Once you have a set of available, filtered candidates, you need to rank them. The ranking model at Airbnb is a machine learning model (reportedly a gradient boosted tree followed by neural re-ranking) that scores each listing based on:

- Listing quality signals: number and recency of reviews, average rating, response rate, acceptance rate

- Price competitiveness: how this listing's price compares to similar listings in the area

- Guest preferences: if the guest has searched before, what types of properties did they click? What did they book?

- Host reliability: how often does this host cancel bookings? (A host with frequent cancellations gets penalized heavily in ranking)

- Photo quality: Airbnb has trained models to assess photo quality and penalize listings with dark, blurry, or poorly composed photos

This ranking is computed offline and stored as a score per listing. At query time, you retrieve candidates and sort by the precomputed score adjusted for query-specific context (distance from the searched location, for instance).

### Pagination Challenges

Geo-spatial pagination is awkward. When you page through results sorted by distance, a new listing being added (or an existing one becoming unavailable) can shift positions, causing duplicates or gaps between pages. Airbnb handles this with cursor-based pagination tied to a session token — the search state is snapshotted at query time and paginated results are pulled from that snapshot, not live data.

## Booking System Deep Dive

The booking system is where correctness trumps everything else. A search result being slightly stale is annoying. A double booking — two guests showing up at the same property on the same night — is a catastrophic failure that harms real people and destroys trust.

### The Booking Workflow

sequenceDiagram;

participant G as Guest;
participant BS as Booking Service;
participant PS as Payment Service;
participant LS as Listing Service;
participant NS as Notification Service;
participant K as Kafka;

G->>BS: Reserve listing_id dates guests;
BS->>BS: Validate dates not in past;
BS->>LS: Check availability;
LS&#8211;>>BS: Available;

BS->>BS: Acquire distributed lock;
BS->>BS: Recheck availability;

BS->>PS: Authorize payment hold;
PS&#8211;>>BS: Authorization successful;

BS->>BS: Create booking record pending;
BS->>LS: Block dates on calendar;

BS->>BS: Update booking confirmed;
BS->>K: Publish booking confirmed;

K->>NS: Send confirmation emails;

BS&#8211;>>G: Booking confirmed;

The critical section here is the distributed lock around step 4. Without it, two guests could both check availability (both see &ldquo;available&rdquo;), both proceed to payment, and both get a confirmed booking for the same dates. This is the classic time-of-check-to-time-of-use (TOCTOU) race condition.

### Preventing Double Bookings

Airbnb uses a combination of strategies here:

Database-level constraints: The calendar table has a unique constraint on . Any second booking attempt for the same listing and date will fail with a unique violation at the database level. This is the last-resort guard.

Distributed locking with Redis: Before writing, the booking service acquires a Redis lock on the key  using the  command (set if not exists, with expiry). This provides mutual exclusion at the application layer, well before the database constraint fires. The lock has a TTL (say, 10 seconds) so that if the booking service crashes while holding the lock, it automatically releases.

Optimistic locking on the listing record: The listing record has a version number. When a booking is committed, it checks that the version hasn't changed since it was read. If another booking sneaked in between the read and the write, the version won't match, and the transaction is rolled back and retried.

### Handling Payment Failures

Payment processing adds another layer of complexity. The sequence is:

- Authorize the payment (card is valid, funds reserved but not captured)

- Create the booking

- Capture the payment (money actually moves)

If step 2 fails after step 1, you must release the payment authorization. If step 3 fails after step 2, you need to cancel the booking and release the hold. This two-phase approach (authorize then capture) is industry standard for exactly this reason — it gives you a window to back out before money actually moves.

For handling partial failures, Airbnb uses a saga pattern — each step in the booking workflow publishes compensating events that can undo the step if a later step fails. The booking saga coordinator (often implemented as a state machine) tracks which steps have completed and orchestrates rollback when needed.

## Database Design

### Schema Overview

### SQL vs NoSQL Decisions

The bookings, payments, and user accounts all live in PostgreSQL. This is deliberate. These are domains where transactional consistency is non-negotiable. A payment that debits a guest but doesn't credit the host (due to an eventual consistency lag) is a real financial incident. PostgreSQL's ACID guarantees and row-level locking make it the right tool here.

The messaging system, on the other hand, is a better fit for Cassandra. Messages are append-only, read by conversation ID, and need to scale horizontally without complex joins. Cassandra's partition key model —  — retrieves all messages in a conversation in time order with a single partition scan. That's exactly the access pattern you need.

Search metadata lives in Elasticsearch. You can't do geo-queries, full-text search, and multi-faceted filtering efficiently in PostgreSQL at millions of listing scale. Elasticsearch is purpose-built for exactly this read pattern. The tradeoff is that data is duplicated — the authoritative record is in PostgreSQL, but a denormalized copy lives in Elasticsearch. Changes must be propagated via Kafka consumers to keep them in sync.

Redis serves as the caching layer and the distributed locking mechanism. Session tokens, search result caches, rate limit counters, and booking locks all live in Redis. The data here is ephemeral by design — if Redis loses its data, you fall through to PostgreSQL. Redis never holds the authoritative record.

### Indexing and Partitioning

As the bookings table grows into hundreds of millions of rows, you partition it by  (range partitioning by month or quarter). Older partitions can be archived to cheaper storage. Most booking queries are for recent or upcoming bookings, so the hot partition is small and fast.

## Pricing and Availability System

### Dynamic Pricing

Airbnb's Smart Pricing system is effectively a demand forecasting model. For each listing on each date, it estimates how much demand there will be and suggests a price that maximizes the host's expected revenue (not just occupancy — a fully-booked listing at too-low prices isn't optimal).

Inputs to the pricing model:
- Base price set by the host
- Historical booking patterns for this listing and comparable listings
- Seasonal demand curves for this market
- Local events (concerts, conferences, sports events) detected from external data sources
- Day-of-week effects (weekends vs weekdays)
- Lead time (bookings made 6 months out vs 3 days out have different price sensitivity)
- Current occupancy rate and remaining availability

The pricing service runs as a batch job overnight for all listings, generating per-listing, per-date price recommendations. These are stored in a pricing table and served through a cache. When a guest views a listing, the price shown is the cached recommendation, not a live computation.

flowchart LR;

%% Nodes
A[External Event Data Concerts Conferences];
B[Historical Booking Data];
C[Comparable Listings Data];
D[Pricing ML Model batch nightly];
E[Pricing Table PostgreSQL];
F[Redis Cache TTL 1hr];
G[Listing Service serves price to guests];

%% Flow
A &#8211;> D;
B &#8211;> D;
C &#8211;> D;

D &#8211;> E;
E &#8211;> F;
F &#8211;> G;

### Calendar Synchronization

Many hosts list their property on multiple platforms — Airbnb, VRBO, Booking.com. To prevent double bookings across platforms, Airbnb supports iCal synchronization. External platforms export their bookings as iCal feeds, and Airbnb periodically polls these feeds (typically every few hours) to import blocked dates.

This is a best-effort system — there's a polling lag. If a guest books via VRBO at 2pm and the next Airbnb iCal sync is at 4pm, there's a 2-hour window where Airbnb might still show those dates as available. The final guard is still the booking flow itself — but the likelihood of a collision is low.

## Maps and Geo Services

### How Map Search Works

Airbnb's map search is one of its most distinctive UX features. As you drag and zoom the map, listings appear and disappear dynamically. Under the hood, this is a bounding-box geo query: &ldquo;give me all listings with latitude between X1 and X2 and longitude between Y1 and Y2, filtered by the current search criteria.&rdquo;

flowchart LR;

%% Nodes
A[User Drags Map
New Bounding Box];
B[Debounced API Call
Wait 200ms];
C[Search Service];
D[Elasticsearch
Geo Bounding Box Query];
E[Apply Filters
Price Amenities Availability];
F[Return Listing Pins
lat lng price id];
G[Render Pins on Map];

%% Flow
A &#8211;> B;
B &#8211;> C;
C &#8211;> D;
D &#8211;> E;
E &#8211;> F;
F &#8211;> G;

The debouncing step (waiting 200ms) is important. Without it, every pixel of map drag would fire an API call, destroying performance for the client and the server.

For rendering, Airbnb sends back only the minimum data needed to display map pins — listing ID, coordinates, and price. The full listing details are loaded lazily when the user hovers or clicks a pin. This reduces payload size for map responses dramatically.

### Clustering

When a guest zooms out to see an entire country, you can't render thousands of individual pins — the map becomes unreadable and the client rendering performance collapses. The solution is clustering: at lower zoom levels, nearby listings are grouped into clusters showing the count. As you zoom in, clusters split into individual listings.

Clustering can be done client-side (computationally on the frontend using libraries like Supercluster) or server-side (pre-aggregated in Elasticsearch using geo-tile aggregations). Airbnb uses a hybrid — server-side aggregations for initial load, client-side refinement for interactive zooming.

### GeoHash and Distance Calculations

For &ldquo;nearby listings&rdquo; recommendations (shown on a listing page: &ldquo;More places near this area&rdquo;), GeoHash prefix matching is used. A listing with GeoHash  is shown neighbors sharing the  prefix, which covers roughly a 40km area.

For exact distance display (&ldquo;2.3 km from city center&rdquo;), the Haversine formula is used:

$$
d = 2R \times \arcsin\left(\sqrt{\sin^2\left(\frac{\Delta lat}{2}\right) + \cos(lat_1) \times \cos(lat_2) \times \sin^2\left(\frac{\Delta lon}{2}\right)}\right)
$$

This is computed at query time for candidate listings after the spatial index narrows down the candidates. Computing Haversine for 20 candidates is cheap; computing it for millions of listings would not be.

## Messaging System

### Architecture

Host-guest messaging needs to feel instant. When a host sends a message at 11pm about check-in instructions, the guest should see it immediately — not after polling a REST endpoint every 30 seconds.

This requires WebSocket connections for real-time delivery.

sequenceDiagram;

participant H as Host Browser;
participant WS as WebSocket Server;
participant MS as Message Service;
participant K as Kafka;
participant G as Guest Mobile;

H->>WS: Connect WebSocket;
G->>WS: Connect WebSocket;

H->>MS: Send message REST;
MS->>MS: Persist to Cassandra;
MS->>K: Publish message created;

K->>WS: Consume event;
WS->>G: Push message;
WS->>H: Delivery ACK;

The message service persists messages to Cassandra (append-only, partition by conversation ID, cluster by timestamp). The WebSocket server is a stateful layer — each connection maps to a user, and incoming message events are fanned out to the correct socket.

Because WebSocket servers are stateful, horizontal scaling requires a routing layer. When a guest connects to WebSocket server A, and the host is connected to WebSocket server B, a message from the host needs to reach server A to deliver to the guest. A Redis pub/sub channel (one per conversation) bridges the two servers.

### Offline Delivery

When a user is offline (no WebSocket connection), messages are queued. When the user reconnects, the WebSocket server checks for undelivered messages and pushes them. For mobile users who might stay offline for hours, push notifications (APNs for iOS, FCM for Android) are used as the delivery channel. The notification is a nudge to open the app, which then fetches messages via REST.

## Notification Pipeline

Airbnb sends millions of transactional emails, push notifications, and SMS messages per day — booking confirmations, host inquiries, review reminders, payment receipts. Each of these needs to be delivered reliably with retry logic.

flowchart TB;

%% Nodes
K[Kafka Topics
booking confirmed
booking cancelled
message received
review requested];
NC[Notification Consumer];
NR[Notification Router
select channel];

EM[Email Service
SendGrid SES];
PN[Push Notification Service
APNs FCM];
SM[SMS Service
Twilio];

DT[Delivery Tracking
open click bounce];
RP[Retry Queue
exponential backoff];

%% Flow
K &#8211;> NC;
NC &#8211;> NR;

NR &#8211;> EM;
NR &#8211;> PN;
NR &#8211;> SM;

EM &#8211;> DT;
PN &#8211;> DT;
SM &#8211;> DT;

DT &#8211;> RP;

The notification router applies user preferences and channel priority. If a user has push notifications enabled and their device is known to be active, prefer push. If they haven't opened the app recently, also send an email. For booking confirmations specifically, always send email regardless of other channels — it's the paper trail the guest needs.

The retry queue handles transient failures. If SendGrid is temporarily unavailable, the notification is re-queued with exponential backoff (retry after 1 min, then 5 min, then 30 min, then give up and alert the on-call team).

## Recommendation System

When a guest opens the Airbnb app without a specific search in mind — just browsing — the recommendation system kicks in. The goal is to surface listings the guest is likely to love before they've told you what they want.

The recommendation pipeline conceptually works in three stages:

Candidate Generation: Based on the user's location (from device GPS or last search), pull a large candidate set of nearby listings. Also incorporate any &ldquo;Wishlist&rdquo; items the user has saved — clear signals of intent.

Feature Engineering: For each candidate listing, compute features: distance from user, price relative to user's historical bookings, property type match (if user always books entire apartments, downrank shared rooms), review sentiment score, photo quality score.

Ranking: A trained ranking model (typically a two-tower neural network that learns user embeddings and listing embeddings separately, then scores them by dot product) orders the candidates. Users who tend to book similar properties are grouped in embedding space, so implicit collaborative filtering emerges from the model.

Trending Destinations: Airbnb surfaces trending destinations (cities or neighborhoods with recently spiking search volume) using real-time aggregation of search events in Kafka. A Spark Streaming job computes trending destinations every few minutes and writes them to a cache served on the home screen.

## Scaling Airbnb

### Horizontal Scaling

Every microservice runs as multiple replicas behind a load balancer. Stateless services (search, listing, pricing) scale trivially — add more replicas and distribute traffic. Stateful services (WebSocket servers, session stores) require session affinity or external state stores (Redis) so any replica can serve any request.

### Event-Driven Architecture

Kafka is the backbone of Airbnb's asynchronous processing. By publishing events rather than making synchronous service calls, the booking service doesn't need to know or care that the notification service, the pricing service, and the search indexer all need to react to a confirmed booking. Each listens independently. If the notification service is temporarily down, events accumulate in Kafka and are processed when it recovers — no data is lost.

This matters enormously during traffic spikes. On New Year's Eve or during major events, booking volume can spike 10x over normal. An event-driven architecture absorbs this naturally — Kafka buffers the spike, and downstream consumers process at their own pace.

### Cache Strategy

For listing data, a tiered cache works well. The listing detail page caches a fully assembled response (listing metadata + first photo + host info + current price) in Redis with a 5-minute TTL. For frequently viewed listings (popular cities, high-ranked results), this hit rate is very high. The miss rate is low enough that the database read replicas handle it comfortably.

### Database Bottlenecks and Hotspots

Popular listings — say, a treehouse in the Smoky Mountains with 5,000 reviews and a perpetual waitlist — can become read hotspots. Every search for that region returns that listing; every view of the listing hits the cache. The cache solves the read problem.

Write hotspots are harder. If 500 guests all try to book a listing the moment it becomes available (because the host just posted a cancellation), the booking service handles a storm of concurrent write attempts. The distributed lock serializes these writes — only one booking succeeds, and 499 guests get a &ldquo;no longer available&rdquo; response. This is by design. The lock is the correct solution. The only mitigation is ensuring the lock is implemented efficiently (Redis SET NX is sub-millisecond) and the sad-path response to guests is fast and helpful.

## Trust, Safety, and Fraud Detection

Trust is the product Airbnb is actually selling. A guest hands a stranger the keys to their home. That only works if both sides trust the platform to curate, verify, and protect them.

### Identity Verification

Airbnb requires government ID verification for hosts in many markets. The ID verification pipeline works as:

- User uploads a photo of their ID and a selfie

- An OCR service extracts name, date of birth, and document number

- A face matching model compares the selfie to the ID photo

- Document authenticity checks run against known templates (fonts, security features, layout)

- A risk score is generated and a human review queue catches borderline cases

### Fraud Detection

Every payment transaction runs through a fraud scoring model that evaluates:
- Is this IP address associated with prior fraud?
- Is the billing address consistent with the user's typical location?
- Is this a newly created account booking an unusually expensive property?
- Is the device fingerprint linked to prior fraudulent accounts?

High-risk transactions are held for additional verification. Very-high-risk transactions are declined and the account is flagged for review.

### Review Integrity

Reviews are only possible after a completed booking — preventing hosts or guests from reviewing without a real stay. Review bombing (coordinated negative reviews) is detected using graph analysis: if a cluster of accounts all review the same listing negatively within a short window, and those accounts have no prior review history, that pattern triggers an investigation.

### Anomaly Detection

A real-time anomaly detection system monitors key metrics — bookings per minute by region, payment failures per merchant, new listing creation rate — and alerts when values deviate significantly from historical baselines. This catches both technical incidents (a spike in payment failures suggests a payment gateway issue) and abuse patterns (a sudden spike in new listings in a city could indicate a fake listing campaign).

## Reliability and Availability

### Multi-Region Deployments

Airbnb runs in multiple AWS regions. Traffic is globally load-balanced (using Route 53 latency-based routing or similar) so guests in Europe primarily hit EU infrastructure and guests in Asia primarily hit APAC infrastructure. Each region is independently deployable and can serve traffic for the primary use case even if another region goes down.

The exception is financial data. Payment processing and booking records are replicated across regions, but writes go to a primary region and are replicated asynchronously. The RPO (recovery point objective) for financial data is near zero — Airbnb cannot afford to lose booking or payment records.

### Observability Stack

Without visibility into what's happening across hundreds of microservices, you're flying blind. Airbnb's observability stack includes:

Metrics: Every service emits latency histograms, error rates, and throughput metrics. Dashboards show real-time health. Alerts fire when error rates exceed thresholds or latency degrades.

Distributed Tracing: Using a system like Jaeger or OpenTelemetry, every request gets a trace ID that propagates through all downstream service calls. When a booking request takes 3 seconds instead of 300ms, the trace shows exactly which service call ate the time.

Log Aggregation: Structured logs from all services flow into a central system (Elasticsearch + Kibana, or similar). Engineers can search across all service logs for a specific booking ID to reconstruct exactly what happened during an incident.

Canary Deployments: New versions of services are deployed to a small percentage of traffic (say, 1%) and promoted to full rollout only if error rates remain stable. A bad deployment is caught and rolled back before it affects most users.

## Engineering Tradeoffs

Good system design isn't about picking the &ldquo;right&rdquo; answer — it's about understanding the tradeoffs and making informed choices.

  
    
      
        Decision
        Airbnb's Approach
        Alternative
        Tradeoff
      
    
    
      
        Monolith vs Microservices
        Microservices
        Monolith
        Independent scaling and deploys, but operational complexity increases
      
      
        SQL vs NoSQL for bookings
        PostgreSQL (SQL)
        Cassandra
        ACID guarantees for financial data, but harder to scale horizontally
      
      
        Real-time vs eventual consistency
        Eventual for search, strong for bookings
        All real-time
        Lower latency and cost for search; correctness where it matters
      
      
        Cache TTL
        Short (60-300s)
        Longer TTL
        Freshness vs cache efficiency
      
      
        Optimistic vs pessimistic locking
        Both, layered
        One or the other
        Redis lock (pessimistic) for speed, DB constraint (last-resort) for safety
      
      
        Sync vs async notifications
        Async (Kafka)
        Synchronous RPC
        Resilience and decoupling, but introduces delivery lag
      
    
  

The most important tradeoff at Airbnb is the consistency spectrum. The search system tolerates eventual consistency — showing a listing that was booked 30 seconds ago as still available — because the cost of being slightly stale is low (the guest just sees &ldquo;no longer available&rdquo; at booking time). The booking system tolerates zero eventual consistency — it uses strong transactional guarantees — because the cost of a double booking is catastrophic. Designing each subsystem at the appropriate point on the consistency spectrum is what separates a thoughtful architecture from a one-size-fits-all one.

## Technology Stack

  
    
      
        Category
        Technology
        Why
      
    
    
      
        Web Frontend
        React
        Component model scales well for complex UIs; large ecosystem
      
      
        Mobile
        React Native / Swift / Kotlin
        Cross-platform code sharing where possible; native where performance demands
      
      
        Backend Services
        Java, Kotlin, Ruby (legacy)
        Java/Kotlin for high-throughput services; type safety and JVM performance
      
      
        API Gateway
        Nginx / Envoy
        Proven, configurable, battle-tested at massive scale
      
      
        Search
        Elasticsearch
        Native geo queries, full-text search, aggregations, horizontal scaling
      
      
        Primary Database
        PostgreSQL
        ACID guarantees, mature ecosystem, excellent for relational + transactional data
      
      
        Messaging DB
        Apache Cassandra
        Append-only access pattern, horizontal scaling, partition-friendly
      
      
        Cache
        Redis
        Sub-millisecond reads, distributed locks, pub/sub, sorted sets for leaderboards
      
      
        Event Streaming
        Apache Kafka
        High-throughput, durable event log; decouples producers from consumers
      
      
        Object Storage
        Amazon S3
        Globally durable, infinitely scalable photo and media storage
      
      
        Container Orchestration
        Kubernetes
        Automates deployment, scaling, and self-healing of microservices
      
      
        Cloud Infrastructure
        AWS
        Global footprint, managed services reduce operational overhead
      
      
        Observability
        Datadog / OpenTelemetry
        Metrics, traces, and logs unified across services
      
      
        ML Platform
        Spark + custom serving
        Batch training at scale; low-latency model serving for ranking and fraud
      
    
  

A word on the choice of Kafka: it's heavy infrastructure to run and operate. For a team of 5, Kafka is overkill. For a platform at Airbnb's scale with dozens of services that need to react to the same events, Kafka's durability and consumer group model make it the right choice. You can replay events if a consumer has a bug, which is invaluable during incidents.

## System Design Interview Perspective

If you're preparing for a system design interview and Airbnb (or a similar short-term rental marketplace) comes up, here is how to approach it well.

### What interviewers are testing

- Can you scope the problem correctly? (Don't design Twitter when asked to design Airbnb)

- Do you understand geo-spatial search challenges?

- Can you reason about the booking concurrency problem?

- Do you know when to use which database?

- Can you identify the consistency requirements for different parts of the system?

### Strong answers include

For search: &ldquo;I'd use Elasticsearch with geo-point indexing for the spatial component, with a two-phase approach — GeoHash to find candidate cells, then distance calculation for ranking. Availability data is synced asynchronously from the booking system with a Kafka consumer, so search results might be 30-60 seconds stale, but the booking step is the real consistency gate.&rdquo;

For bookings: &ldquo;Double booking prevention uses a layered approach. First, a distributed Redis lock on (listing_id, date_range) serializes concurrent booking attempts. Second, a unique database constraint on (listing_id, date, BOOKED) provides a last-resort guard. Payment is authorized before the booking is committed, using the two-phase authorize-then-capture pattern.&rdquo;

For scaling: &ldquo;Search and listing reads scale horizontally — stateless services plus Redis caching handle most traffic. The booking write path is harder to scale because of the locking requirement, but because locks are narrow (per listing per date range) rather than global, you can have thousands of concurrent bookings happening in parallel as long as they're for different listings.&rdquo;

### Common mistakes to avoid

- Designing a monolithic database. Putting search, bookings, payments, and messaging all in one PostgreSQL database will bottleneck your design. Explain why different storage systems serve different access patterns.

- Ignoring the concurrency problem. An answer that says &ldquo;check availability then book&rdquo; without addressing the race condition shows incomplete thinking.

- Over-engineering upfront. In an interview, explain that the system would start simpler (a single database, no Kafka) and describe when and why you'd introduce complexity as you scale.

- Treating all data with the same consistency requirement. The hallmark of a strong answer is knowing where eventual consistency is acceptable and where it isn't.

### Interview flow recommendation

- Spend 5 minutes clarifying scope: which features matter most? (Focus on search and booking — they're the core)

- Estimate scale: how many listings, searches/sec, bookings/day?

- Design the API layer: what are the core REST endpoints?

- Sketch the high-level architecture: clients → gateway → services → storage

- Deep-dive search: geo-spatial indexing, filtering, ranking

- Deep-dive booking: the locking strategy, the payment flow, the saga pattern

- Discuss scaling: where are the bottlenecks? How do you address them?

- Close with tradeoffs: what did you choose not to do, and why?

## Closing Thoughts

Airbnb is a masterclass in building a system where correctness, performance, and user trust are all non-negotiable simultaneously. The search system has to be fast because slow search means guests leave. The booking system has to be correct because a single double-booking is a disaster. The payment system has to be reliable because every failed transaction is lost revenue and lost trust. And all of this has to work across the globe, in dozens of currencies, for millions of properties.

What makes Airbnb's architecture interesting isn't that it uses exotic technology — almost everything here is industry standard (PostgreSQL, Elasticsearch, Kafka, Redis). What makes it interesting is the careful reasoning about which consistency model applies where, how to handle concurrency at the transaction level, how to make geo-spatial search fast without sacrificing result quality, and how to build a trust layer for a business model that literally requires strangers to trust each other.

Understanding the why behind each architectural choice — not just the what — is what separates an engineer who can talk about system design from one who can actually do it.

Enjoyed this deep dive? The best way to internalize these concepts is to start designing systems yourself — pick a product you use every day and try to sketch its architecture from first principles. Then look at what engineers at that company have actually written about how they built it. The gap between your design and theirs is where the most learning happens.
