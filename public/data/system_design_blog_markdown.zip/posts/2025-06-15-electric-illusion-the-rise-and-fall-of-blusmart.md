---
title: "Electric Illusion: The Rise and Fall of BluSmart"
date: "2025-06-15T20:38:26+05:30"
slug: "electric-illusion-the-rise-and-fall-of-blusmart"
categories: ["case_study", "scandals", "startups"]
original_url: "https://rishijeet.github.io/blog/electric-illusion-the-rise-and-fall-of-blusmart/"
word_count: 847
reading_time: "4 min"
author: "Rishijeet Mishra"
---

# Electric Illusion: The Rise and Fall of BluSmart

*Published on 2025-06-15 by Rishijeet Mishra | [https://rishijeet.github.io/blog/electric-illusion-the-rise-and-fall-of-blusmart/](https://rishijeet.github.io/blog/electric-illusion-the-rise-and-fall-of-blusmart/)*

BluSmart was once a symbol of India's clean energy aspirations — an all-electric ride-hailing platform backed by marquee investors and government lenders. With its zero-emissions fleet and no-surge pricing model, it quickly gained popularity in cities like Delhi and Bengaluru.

But behind the scenes, the startup’s success story unraveled into one of the most serious corporate fraud cases in India’s startup ecosystem. At the center of this financial maze was Gensol Engineering Ltd, a publicly listed company, controlled by the same promoters behind BluSmart. The ₹262 crore scandal that emerged in 2025 now implicates not just BluSmart, but Gensol’s board, finances, and investors.

![Alt text](https://rishijeet.github.io/images/2025/blusmart-logo.webp)

Source: Internet

### BluSmart’s Meteoric Rise

Founded in 2019, BluSmart positioned itself as India’s first all-electric ride-hailing startup. The platform scaled rapidly:

- Fleet: 8,000+ electric vehicles by 2024

- Coverage: Operational in Delhi-NCR, Mumbai, and Bengaluru

- Funding: ₹486+ crore in equity and ₹978 crore in loans from government-owned lenders

- Backers: BP Ventures, Mayfield Fund, and IREDA & PFC via Gensol Engineering

BluSmart's asset-light model hinged on one key arrangement — vehicle procurement and leasing handled by Gensol EV Lease Pvt Ltd, a subsidiary of Gensol Engineering Ltd, which was also promoted by the Jaggi brothers.

This relationship became the foundation of the scandal.

### How Gensol Became the Nexus of Fund Diversion

Gensol Engineering Ltd, listed on the Indian stock exchange, was the entity through which public sector lenders like IREDA (Indian Renewable Energy Development Agency) and PFC (Power Finance Corporation) disbursed nearly ₹978 crore in loans for electric vehicle procurement.

Here's how the misuse played out:

#### 1. Conflict of Interest

Anmol and Puneet Jaggi held leadership roles in both BluSmart and Gensol. This dual control allowed them to shift funds and assets across entities without independent checks. While Gensol was meant to procure and lease EVs to BluSmart, the actual disbursement and usage of funds were poorly documented.

#### 2. Falsified Board Resolutions

SEBI’s investigation revealed that board resolutions submitted to justify fund transfers from Gensol to other entities were forged. These resolutions claimed shareholder or board approvals that never took place.

#### 3. Diversion of Funds

Out of the ₹978 crore loan sanctioned to Gensol for 6,400 EVs:

- Only 4,704 EVs were procured.

- Over ₹262 crore could not be accounted for.

- Some funds were redirected to purchase personal assets, including:

A ₹50 crore luxury apartment at DLF Camellias, Gurugram

- Golf equipment worth ₹26 lakh

- Foreign trips and personal company expenses

- Transfers to family members and promoter-controlled entities

#### 4. Blurring the Lines

Because Gensol was the lender-facing entity and BluSmart was the consumer-facing app, the two were treated as distinct. However, in reality, the same core leadership ran both. This lack of separation allowed for:

- Overreporting of assets

- Misleading investor communications

- Obscuring of fund flows between listed and private companies

#### 5. Impact on Public Markets

Gensol Engineering’s stock plummeted over 85% following SEBI's interim order. Investors who trusted the company’s renewable energy mission were blindsided by its role in enabling a startup’s financial misconduct.

### Timeline of Events

  
    
      2019
      BluSmart founded by Anmol and Puneet Jaggi
    
    
      2021–2024
      ₹978 crore disbursed to Gensol for EV procurement
    
    
      April 15, 2025
      SEBI interim order reveals ₹262 crore fund diversion via Gensol
    
    
      April 17, 2025
      BluSmart halts operations across all cities
    
    
      May 2025
      Grant Thornton appointed for forensic audit of Gensol and BluSmart
    
    
      June 2025
      Delhi High Court orders seizure of over 700 EVs leased by Gensol to BluSmart
    
  

### Consequences of the Scam

Investors and Markets

- Gensol’s credibility as a listed renewable energy company is under threat.

- Public lenders like PFC and IREDA face scrutiny for failing to detect misuse earlier.

Regulatory Oversight

- SEBI’s action has prompted tighter surveillance of related-party transactions in startups.

- The Ministry of Corporate Affairs (MCA) is reviewing whether more stringent cross-holding disclosures are required for startups using public debt.

Drivers and Users

- Over 10,000 drivers, mostly from underserved backgrounds, lost income overnight.

- BluSmart customers are still awaiting wallet refunds or app updates.

Future of BluSmart

- Talks of reviving the company via an independent board or acquisition have emerged.

- Some investors, including BP Ventures, may pursue legal action to recover their equity.

### Lessons from Gensol–BluSmart Case

  
    
      

### Dual Leadership in Public/Private Firms

      Strong boundaries between promoter-led entities are essential.

    
    
      

### Lack of Board Independence

      Board members should be empowered to question and audit all fund movements.

    
    
      

### Weak Internal Controls

      Statutory audits must detect and flag multi-crore diversions early.

    
    
      

### Misuse of Public Money

      Lending institutions need better tracking for disbursed capital.

    
  

### Conclusion

The BluSmart-Gensol scandal underscores a critical truth: governance is not optional. Innovation, sustainability, and market expansion are meaningless if built on opaque finances and related-party secrecy.

Gensol’s role in the BluSmart collapse shows how a listed company can be used as a conduit for private ambition if oversight is weak. As India’s startup ecosystem matures, this case should serve as a clear signal — accountability must scale along with vision.

BluSmart’s fall was not due to a lack of market demand or poor technology. It failed because of misaligned ethics, enabled by a public company that chose opacity over integrity.
