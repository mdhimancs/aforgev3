---
title: "Case Study: The Collapse of Silicon Valley Bank"
date: "2025-03-09T11:48:11+05:30"
slug: "case-study-the-collapse-of-silicon-valley-bank"
categories: ["case_study", "banks", "fintech", "startup"]
original_url: "https://rishijeet.github.io/blog/case-study-the-collapse-of-silicon-valley-bank/"
word_count: 647
reading_time: "3 min"
author: "Rishijeet Mishra"
---

# Case Study: The Collapse of Silicon Valley Bank

*Published on 2025-03-09 by Rishijeet Mishra | [https://rishijeet.github.io/blog/case-study-the-collapse-of-silicon-valley-bank/](https://rishijeet.github.io/blog/case-study-the-collapse-of-silicon-valley-bank/)*

Silicon Valley Bank (SVB) was one of the largest banks catering to the startup and venture capital ecosystem in the United States. Its sudden collapse in March 2023 sent shockwaves through the financial sector, prompting government intervention and raising concerns about the stability of other regional banks. This case study explores the factors that led to SVB's failure, its impact, and key lessons learned.

![Alt text](https://rishijeet.github.io/images/2025/svb.webp)

Source: Internet

## Background of Silicon Valley Bank

Founded in 1983, SVB grew into the 16th largest bank in the U.S., with assets exceeding $209 billion by the end of 2022. It specialized in serving technology startups, venture capital (VC) firms, and innovation-driven companies. SVB's business model relied heavily on deposit funding from these clients and investments in long-duration U.S. government bonds.

### Growth and Success

- By 2021, SVB’s total assets grew by 215% compared to 2019.

- It controlled nearly 50% of all venture-backed startups’ deposits in the U.S.

- A key player in the tech boom, SVB benefited from rising valuations, strong venture funding, and low interest rates.

## The Downfall: Key Factors Leading to the Collapse

### Overreliance on Long-Term Bonds

SVB invested heavily in long-term U.S. Treasury bonds and mortgage-backed securities (MBS) to generate returns. However, these investments carried significant interest rate risk.

- By 2022, nearly 57% of SVB’s total assets ($120 billion) were invested in securities, primarily long-duration bonds.

- When interest rates rise, bond values fall, creating unrealized losses.

### Federal Reserve’s Interest Rate Hikes

- The Federal Reserve raised interest rates 11 times from March 2022 to March 2023, increasing the federal funds rate from 0.25% to 4.75%.

- The sharp rise in rates led to a $17 billion unrealized loss on SVB’s bond portfolio.

- This devalued SVB’s assets, making it more vulnerable to liquidity pressures.

### Tech Industry Slowdown and Deposit Flight

- As interest rates rose, venture capital funding declined by 31% in 2022, leading startups to withdraw deposits.

- SVB’s deposits dropped from $198 billion in March 2022 to $165 billion by the end of 2022.

### Panic and Bank Run (March 2023)

- On March 8, 2023, SVB announced it had sold $21 billion worth of securities at a $1.8 billion loss and planned to raise $2.25 billion in new capital.

- This triggered panic among VC firms and startups, leading to mass withdrawals of $42 billion in a single day (March 9).

- On March 10, 2023, regulators shut down SVB, marking the largest U.S. bank failure since 2008.

## Government and Market Response

### FDIC Intervention

- The Federal Deposit Insurance Corporation (FDIC) took control of SVB, ensuring deposits up to $250,000.

- On March 12, 2023, the U.S. government guaranteed all deposits, preventing wider contagion.

### Stock Market and Banking Sector Impact

- Bank stocks plummeted, with First Republic Bank losing 70% of its value within days.

- The KBW Bank Index (measuring U.S. bank performance) dropped 18% in March 2023.

- Global financial markets reacted sharply, fearing systemic risks.

![Alt text](https://rishijeet.github.io/images/2025/svb_stock.avif)

Source: Internet

## Key Lessons and Takeaways

- The Risk of Asset-Liability Mismatch

SVB’s heavy reliance on long-duration bonds while serving short-term depositors created a major mismatch, exposing
it to liquidity risk.

- Interest Rate Sensitivity in Banking

Banks must proactively hedge against interest rate fluctuations, especially in a rising-rate environment.

- The Power of Panic and Social Media

SVB’s collapse was exacerbated by rapid digital bank runs, fueled by panic-driven withdrawals coordinated through
social media and VC networks.

- Regulatory and Risk Management Gaps

SVB was exempt from Dodd-Frank stress testing due to relaxed regulations in 2018.

- Stricter oversight on regional banks could have mitigated risks.

## Conclusion

The collapse of Silicon Valley Bank exposed vulnerabilities in the financial system, particularly for banks with concentrated deposit bases and interest rate exposure. While the FDIC’s intervention prevented a broader crisis, the incident underscored the need for robust risk management, diversified banking strategies, and stronger regulatory frameworks. SVB’s downfall serves as a cautionary tale for financial institutions navigating uncertain economic conditions.
