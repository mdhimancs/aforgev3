---
title: "Black Gold Rules the World - Everything You Never Knew About Oil"
date: "2026-04-11T09:45:11+05:30"
slug: "black-gold-rules-the-world-everything-you-never-knew-about-oil"
categories: ["oil", "case_study", "petroleum"]
original_url: "https://rishijeet.github.io/blog/black-gold-rules-the-world-everything-you-never-knew-about-oil/"
word_count: 2253
reading_time: "11 min"
author: "Rishijeet Mishra"
---

# Black Gold Rules the World - Everything You Never Knew About Oil

*Published on 2026-04-11 by Rishijeet Mishra | [https://rishijeet.github.io/blog/black-gold-rules-the-world-everything-you-never-knew-about-oil/](https://rishijeet.github.io/blog/black-gold-rules-the-world-everything-you-never-knew-about-oil/)*

The world as we know it would not exist without petroleum. From the fuel in your car to the plastic in your phone case, oil is woven into almost every thread of modern civilization. But how did this thick, dark liquid buried miles underground become the most powerful commodity on Earth?

## A Brief History: From Ancient Seeps to Industrial Lifeline

Long before the first oil well was ever drilled, humans knew about petroleum. Ancient Mesopotamians — in what is today Iraq — used naturally occurring bitumen (a semi-solid form of crude oil) to waterproof boats and bind bricks together as far back as 3,000 BCE. The Chinese were drilling primitive bamboo wells to extract oil as early as 347 CE.

But the modern petroleum era truly begins on August 27, 1859, in Titusville, Pennsylvania, USA, when Edwin Drake successfully drilled the world's first commercial oil well to a depth of 21 metres. The oil he struck didn't just flow — it ignited an industry, and with it, an entirely new world order.

Within decades, John D. Rockefeller's Standard Oil had monopolized the American market, controlling over 90% of U.S. oil refining by the 1880s. The invention of the internal combustion engine, and then the automobile, sent demand soaring. By the early 20th century, oil was no longer just a source of lamp fuel — it was the lifeblood of empires, powering warships, aircraft, and tanks in both World Wars.

![Alt text](https://rishijeet.github.io/images/2026/oil1.webp)

Source: Internet

## Types of Crude Oil: Not All Oil is the Same

When people say &ldquo;oil,&rdquo; they're often referring to crude oil — the unrefined petroleum extracted from the earth. But crude oil itself comes in many grades, classified by two key properties: density (light vs. heavy) and sulfur content (sweet vs. sour).

![Alt text](https://rishijeet.github.io/images/2026/oilq.jpg)

Source: Internet

The major benchmarks:

- Brent Crude — Extracted from the North Sea (between the UK and Norway), Brent is the world's leading price benchmark. It's a light, sweet crude, meaning it's relatively low in sulfur and easier to refine into gasoline and diesel. About two-thirds of the world's oil contracts are priced relative to Brent.

- West Texas Intermediate (WTI) — The American benchmark, slightly lighter and sweeter than Brent. Traded on the NYMEX exchange in New York, WTI is the reference price for U.S. oil markets.

- Dubai/Oman Crude — The benchmark for Middle Eastern oil sold to Asian markets. It's heavier and more sour than Brent or WTI.

- OPEC Basket — A weighted average price of several different types of crude produced by OPEC member nations, including Saudi Light, Iranian Heavy, and Venezuela's Merey blend.

- Heavy Crude & Tar Sands — Found in abundance in Venezuela and Canada, these are thick, viscous types that require extra processing. They're cheaper to buy but more expensive to refine.

- Shale Oil (Tight Oil) — A game-changer of the 21st century. Extracted via hydraulic fracturing (&ldquo;fracking&rdquo;) from shale rock formations, it turned the United States into the world's largest oil producer.

## Who Produces How Much? The Global Leaderboard

Here's where geopolitics meets geology. As of the mid-2020s, the top oil-producing nations are:

![Alt text](https://rishijeet.github.io/images/2026/global_oil_production_light.png)

Source: Internet

OPEC (Organization of the Petroleum Exporting Countries), founded in 1960, unites 13 major producing nations — mostly from the Middle East, Africa, and Latin America — to coordinate output and influence global prices. The extended OPEC+ alliance includes Russia and other non-OPEC producers.

## Why Is the Middle East Floating on Oil?

This is one of the most fascinating geological stories in history. The Middle East sits atop roughly 48% of the world's proven oil reserves, and the reason is ancient — literally hundreds of millions of years old.

Around 150–300 million years ago, the region that is now the Arabian Peninsula was covered by a shallow, warm, tropical sea — part of the ancient Tethys Ocean. This sea was teeming with marine life: tiny organisms, plankton, and algae. As these organisms died, they sank to the seabed and were buried under layers of sediment.

Over millions of years, heat and pressure from the earth's crust transformed this organic matter into hydrocarbons — the chemical basis of oil and gas. What made the Middle East particularly special was the geology above: thick layers of impermeable rock (called cap rock) that trapped the hydrocarbons beneath, preventing them from escaping to the surface. The result? Enormous, perfectly sealed underground reservoirs.

![Alt text](https://rishijeet.github.io/images/2026/ghavar2.avif)

Source: Internet - Ghawar Oil Field

The Ghawar field in Saudi Arabia, discovered in 1948, is the world's largest conventional oil field — stretching over 280 km in length and having produced over 65 billion barrels of oil. Fields like Burgan in Kuwait and Rumaila in Iraq are similarly colossal.

![Alt text](https://rishijeet.github.io/images/2026/ghavar.avif)

Source: Internet - Ghawar Stretch

The Middle East primarily produces Arab Light and Arab Medium — light to medium, low-to-medium sulfur crudes that are relatively easy and inexpensive to refine. Saudi Arabia's production cost per barrel is among the lowest in the world — sometimes as little as $2–4 per barrel to extract, compared to $20–40 for U.S. shale.

## Saudi Aramco: The Most Valuable Company on Earth

Saudi Aramco (officially the Arabian American Oil Company, now the Saudi Arabian Oil Company) is not just the world's largest oil company — it is arguably the most powerful corporation in human history.

![Alt text](https://rishijeet.github.io/images/2026/sa.webp)

Source: Internet

Founded in 1933 as a joint venture between Standard Oil of California and the Saudi government, Aramco was progressively nationalized through the 1970s, with Saudi Arabia taking full ownership by 1980. Today it is majority owned by the Saudi government and is the backbone of the Saudi economy, contributing over 70% of government revenues.

Key facts about Aramco:

- Market capitalization: Over $1.8 trillion (making it the world's most valuable company by market cap at various points)

- Production: Approximately 9–10 million barrels per day

- Reserves: Controls about 260 billion barrels of proven reserves — the second-largest in the world

- IPO: In 2019, Aramco listed on the Tadawul (Saudi stock exchange) in what became the world's largest IPO, raising $25.6 billion

Similar national oil companies (NOCs) around the world:

- NIOC (National Iranian Oil Company) — Iran

- Iraq National Oil Company (INOC) — Iraq

- ADNOC (Abu Dhabi National Oil Company) — UAE

- Kuwait Petroleum Corporation — Kuwait

- PDVSA — Venezuela

- Rosneft — Russia (majority state-owned)

- Petrobras — Brazil (majority state-owned)

- CNPC / Sinopec — China (state-owned giants)

## Shell, ExxonMobil & the Western Oil Majors

While national oil companies control the reserves, the Western &ldquo;supermajors&rdquo; dominate refining, technology, distribution, and trading. The seven historic giants — once called the &ldquo;Seven Sisters&rdquo; — have been consolidated over decades into today's supermajors:

- Shell (Royal Dutch Shell) — Anglo-Dutch, one of the world's largest energy companies with operations in 70+ countries. Shell operates refineries, petrol stations, LNG terminals, and increasingly, renewables.

- ExxonMobil — The largest American oil company, formed by the 1999 merger of Exxon and Mobil (both descendants of Rockefeller's Standard Oil). It is one of the most profitable corporations in history.

- Chevron — Another Standard Oil descendant, headquartered in California. Major operations in the U.S., Kazakhstan, and deepwater fields globally.

- BP (British Petroleum) — UK-based, with major operations in the Gulf of Mexico, North Sea, and Azerbaijan. Infamous for the Deepwater Horizon disaster of 2010.

- TotalEnergies — French supermajor, major presence in Africa, the Middle East, and LNG markets.

- ConocoPhillips — Major American independent producer, focused primarily on upstream (exploration and production).

- Valero, Marathon, Phillips 66 — Leading American refining companies that buy crude and turn it into gasoline, jet fuel, diesel, and petrochemicals.

## America: From Importer to Exporter

For most of the 20th century, the United States was a net importer of oil — buying millions of barrels daily from the Middle East, Venezuela, and Canada. The Arab Oil Embargo of 1973, when OPEC cut off oil to Western nations supporting Israel, sent shockwaves through the American economy and made the vulnerability of oil dependency painfully clear.

Then came the shale revolution. Starting in the late 2000s, advances in horizontal drilling and hydraulic fracturing unlocked vast deposits of oil trapped in shale rock — particularly in the Permian Basin (Texas/New Mexico), Bakken Formation (North Dakota), and Eagle Ford (Texas). By 2018, the U.S. had surpassed Saudi Arabia and Russia to become the world's largest oil producer.

![Alt text](https://rishijeet.github.io/images/2026/shale.png)

Source: Internet

America today:

- Produces: ~13 million barrels/day

- Exports: ~4–5 million barrels/day (mostly to Europe, South Korea, Japan, China)

- Imports: ~6–7 million barrels/day (mostly from Canada, Mexico, Saudi Arabia)

- Still a net importer overall, but the gap has narrowed dramatically

The U.S. also holds a Strategic Petroleum Reserve (SPR) — underground salt caverns in Louisiana and Texas that can store up to 714 million barrels as an emergency buffer.

## China: The Hunger That Moves Markets

China is the world's largest importer of crude oil and its appetite is one of the biggest drivers of global oil prices. China's economic growth over the past four decades created an insatiable demand for energy.

- Production: ~4 million barrels/day (not enough to meet domestic needs)

- Imports: ~10–11 million barrels/day

- Main suppliers: Russia, Saudi Arabia, Iraq, UAE, Kuwait, Angola

China's two oil giants — CNPC (PetroChina) and Sinopec — are among the world's largest companies by revenue. China has also been aggressively securing oil assets in Africa, Central Asia, and South America through its Belt and Road Initiative.

China's rapid growth in electric vehicles (it leads the world in EV adoption) is expected to gradually reduce its oil import dependency — but for now, it remains the engine that keeps tankers full.

## Russia: Oil as a Weapon

Russia is the world's second or third largest oil producer and its single largest export earner. Oil and gas account for roughly 40–50% of Russia's federal budget revenues.

Russia's oil flows primarily westward into Europe (via the Druzhba pipeline, the world's longest oil pipeline at over 4,000 km) and eastward to China and Asia. After Western sanctions following the invasion of Ukraine in 2022, Russia pivoted massively toward selling discounted oil to India and China — demonstrating how geopolitics reshapes energy flows almost overnight.

Key Russian companies: Rosneft, Lukoil, Gazprom Neft, Surgutneftegas.

## How Oil is Traded: The Invisible Pipeline of Contracts

Oil is traded through two primary mechanisms:

1. Spot Markets — Oil bought and sold for immediate delivery. Prices fluctuate by the minute based on supply, demand, geopolitical events, and weather.

2. Futures Contracts — Agreements to buy or sell a fixed amount of oil at a set price on a future date. Traded on exchanges like the NYMEX (New York) for WTI and the ICE (Intercontinental Exchange, London) for Brent. This is how airlines, shipping companies, and governments hedge against price volatility.

Petrodollars: Almost all global oil trade is denominated in US dollars. This has been the standard since the 1970s, when the Nixon administration struck a deal with Saudi Arabia to price oil exclusively in dollars in exchange for military protection. This arrangement gives the USD its unique status as the world's reserve currency — and explains why any country that tries to sell oil in another currency faces enormous political pressure.

Physical transportation happens via:

- Supertankers (VLCCs) — Very Large Crude Carriers, massive ships carrying 2 million barrels across oceans

- Pipelines — The Druzhba (Russia–Europe), Trans-Arabian Pipeline, Keystone XL (North America)

- Strategic chokepoints — The Strait of Hormuz (between Iran and Oman) is the world's most critical oil chokepoint, with nearly 20% of global oil supply passing through it daily. The Strait of Malacca, Suez Canal, and Bab-el-Mandeb are also critical.

## Refining: Turning Black Liquid into Everything

Crude oil on its own is useless — it must be refined. Refineries use a process called fractional distillation, where crude is heated in a tall column and different components (fractions) boil off at different temperatures:

![Alt text](https://rishijeet.github.io/images/2026/fd.svg)

- Gasoline (petrol) — ~500°F

- Jet fuel / Kerosene — ~400°F

- Diesel — ~600°F

- Heating oil / Fuel oil — ~700°F

- Lubricating oil — ~800°F+

- Asphalt / Bitumen — the residue at the bottom

The world's largest refineries include:

- Jamnagar Refinery (India, Reliance Industries) — the world's largest single-location refinery complex, processing 1.24 million barrels/day

- Paraguana Refinery Complex (Venezuela)

- SK Energy refinery in Ulsan, South Korea

- Ruwais Refinery (UAE, ADNOC)

- Port Arthur Refinery (Texas, USA, Motiva — a Saudi Aramco–Shell JV)

![Alt text](https://rishijeet.github.io/images/2026/jamnagar.webp)

Jamnagar Refinery

## Why Oil Still Matters — and What Comes Next

Oil is not just fuel. It is the raw material for petrochemicals — the building blocks of plastics, synthetic fabrics, fertilizers, pharmaceuticals, cosmetics, and electronics. Even in a world that moves to electric vehicles, demand for petrochemicals is expected to grow for decades.

But the era of oil's total dominance is slowly shifting. The rise of solar, wind, and battery technology, combined with global climate commitments, is reshaping energy economics. Saudi Aramco, Shell, and BP are all investing in renewables. But with billions of people in the developing world still getting access to electricity and transportation for the first time, oil will remain critically important well into the mid-21st century.

As the legendary Texas oilman T. Boone Pickens once said:

> &ldquo;A country that can't control its energy sources can't control its future.&rdquo;

That truth — forged in the oil fields of Arabia, Texas, and Siberia — remains as relevant today as the day the first barrel of crude came out of the ground in Pennsylvania, over 165 years ago.

The world runs on oil. Understanding it is understanding modern geopolitics, economics, and our shared future.
