---
title: "How Google Docs Works?"
date: "2026-05-22T09:20:01+05:30"
slug: "how-google-docs-works"
categories: ["system_design", "architecture", "google", "technology"]
original_url: "https://rishijeet.github.io/blog/how-google-docs-works/"
word_count: 7077
reading_time: "35 min"
author: "Rishijeet Mishra"
---

# How Google Docs Works?

*Published on 2026-05-22 by Rishijeet Mishra | [https://rishijeet.github.io/blog/how-google-docs-works/](https://rishijeet.github.io/blog/how-google-docs-works/)*

> There is a moment every developer takes for granted. You open a Google Doc, your colleague is already in it, and you both start typing at the same time. The cursor moves, text appears, changes propagate in near real-time, and nothing breaks. It just works.

![Alt text](https://rishijeet.github.io/images/system_design/googledocs-banner.png)

What happens underneath that blinking cursor is one of the most sophisticated distributed systems problems in software engineering. You have multiple users modifying shared state simultaneously, across different machines, different networks, different continents. You have to handle network partitions, conflicting edits, stale state, and offline scenarios. You need to guarantee that no matter how chaotic the concurrent editing gets, every user eventually sees the same document in a consistent state.

Google Docs is not just a word processor. It is a distributed system that happens to look like a word processor.

This article is a genuine engineering walkthrough of how Google Docs works internally. We will go through collaborative editing algorithms, real-time synchronization infrastructure, operational transformation, CRDT concepts, version history systems, autosave mechanisms, offline editing, and scalability challenges. By the end, you should have a solid mental model of why the system is designed the way it is, not just what it does.

## What Makes Collaborative Editing So Hard

Before we look at how Google Docs solves the problem, it is worth understanding why the problem is hard in the first place.

Imagine two engineers, Priya and Amos, both editing a document at the same time. The document currently reads: 

Priya inserts  after , turning it into . At the same moment, Amos deletes  from the end, intending to turn it into . Both operations are generated at the same timestamp. They hit the server in some order.

If you apply Amos's delete first and then Priya's insert, you get . If you apply Priya's insert first and then Amos's delete, you also get . Great, same result in this case.

But now change the scenario slightly. Amos deletes the character at position 6, which is . Priya inserts two characters at position 5. Now Amos's deletion index is off because Priya's insertion shifted everything. If you apply these naively, Amos ends up deleting the wrong character. The document is now corrupt. Nobody explicitly made an error, but the system failed.

This is the essence of the concurrent editing problem. Operations that look valid in isolation become invalid when applied after another operation has changed the document state they were generated against. And at scale, with hundreds of users editing documents with millions of characters, the number of potential conflicts explodes.

Solving this requires more than clever programming. It requires a formally correct algorithm that can take two operations generated against the same document state and produce a pair of transformed operations that, when applied in any order, always produce the same result. That algorithm is called Operational Transformation.

## Core Features of Google Docs

Before going deep into the internals, it helps to enumerate what the system actually has to do:

- Real-time collaborative editing where multiple users can type simultaneously and see each other's changes within milliseconds

- Autosave that continuously persists document state so that a browser crash loses at most a few seconds of work

- Complete version history that lets any user rewind the document to any point in time

- Live cursor and selection presence so you can see where your collaborators are working

- Comments, suggestions mode, and inline annotations

- Offline editing where you can keep working without internet and have changes synchronized when you reconnect

- Sharing and permission systems that range from private to publicly editable

- Multi-device editing so you can start on a laptop and continue on a phone

- Document recovery in the event of catastrophic failure

Each of these features is nontrivial on its own. Together, they form an interconnected system where changes in one component ripple through every other. Let us look at the architecture before going into each area in depth.

## High-Level Architecture

The system broadly separates into client-side state management, real-time synchronization infrastructure, backend services, and durable storage. Here is how the main components interact:

flowchart TD;

%% =========================
%% Client Layer
%% =========================
A[Browser Client];
B[Mobile Client];

%% =========================
%% Gateway Layer
%% =========================
C[API Gateway];

%% =========================
%% Core Collaboration Services
%% =========================
D[Document Service];
E[Collaboration Server];
F[Operational Transform Engine];
G[Presence Service];
H[Version History Service];
I[Notification Service];
J[Offline Sync Service];

%% =========================
%% Storage and Infrastructure
%% =========================
K[Active Document Cache];
L[Document Store];
M[Operation Log];
N[Revision Store];
O[Presence Store];
P[Event Streaming Bus];

%% =========================
%% Client Requests
%% =========================
A &#8211;>|HTTPS / WebSocket| C;
B &#8211;>|HTTPS / WebSocket| C;

%% =========================
%% Gateway Routing
%% =========================
C &#8211;>|Document APIs| D;
C &#8211;>|Realtime Collaboration| E;

%% =========================
%% Collaboration Engine
%% =========================
E &#8211;>|Concurrent Edit Events| F;
E &#8211;>|User Presence Updates| G;
E &#8211;>|Emit Collaboration Events| P;

%% =========================
%% Document Storage
%% =========================
D &#8211;>|Hot Active Documents| K;
D &#8211;>|Persist Documents| L;

%% =========================
%% Operational Logs
%% =========================
F &#8211;>|Append Operations| M;

%% =========================
%% Versioning
%% =========================
H &#8211;>|Store Revisions| N;

%% =========================
%% Presence Tracking
%% =========================
G &#8211;>|Online User State| O;

%% =========================
%% Event Driven Services
%% =========================
P &#8211;>|Document Revision Events| H;
P &#8211;>|Realtime Notifications| I;
P &#8211;>|Offline Sync Events| J;

%% =========================
%% Styles
%% =========================

%% Clients
style A fill:#2563eb,stroke:#1e40af,stroke-width:4px,color:#ffffff;
style B fill:#2563eb,stroke:#1e40af,stroke-width:4px,color:#ffffff;

%% Gateway
style C fill:#0891b2,stroke:#0e7490,stroke-width:5px,color:#ffffff;

%% Core Services
style D fill:#16a34a,stroke:#166534,stroke-width:4px,color:#ffffff;
style G fill:#16a34a,stroke:#166534,stroke-width:4px,color:#ffffff;
style H fill:#16a34a,stroke:#166534,stroke-width:4px,color:#ffffff;
style I fill:#16a34a,stroke:#166534,stroke-width:4px,color:#ffffff;
style J fill:#16a34a,stroke:#166534,stroke-width:4px,color:#ffffff;

%% Collaboration Engine
style E fill:#7c3aed,stroke:#5b21b6,stroke-width:5px,color:#ffffff;
style F fill:#8b5cf6,stroke:#6d28d9,stroke-width:5px,color:#ffffff;

%% Cache
style K fill:#f59e0b,stroke:#b45309,stroke-width:4px,color:#000000;

%% Storage
style L fill:#9333ea,stroke:#6b21a8,stroke-width:4px,color:#ffffff;
style M fill:#9333ea,stroke:#6b21a8,stroke-width:4px,color:#ffffff;
style N fill:#9333ea,stroke:#6b21a8,stroke-width:4px,color:#ffffff;
style O fill:#9333ea,stroke:#6b21a8,stroke-width:4px,color:#ffffff;

%% Event Bus
style P fill:#dc2626,stroke:#991b1b,stroke-width:5px,color:#ffffff;

%% =========================
%% Link Styling
%% =========================

%% Client Connections
linkStyle 0 stroke:#2563eb,stroke-width:3px;
linkStyle 1 stroke:#2563eb,stroke-width:3px;

%% Gateway Routing
linkStyle 2 stroke:#0891b2,stroke-width:3px;
linkStyle 3 stroke:#0891b2,stroke-width:3px;

%% Collaboration Flows
linkStyle 4 stroke:#7c3aed,stroke-width:4px;
linkStyle 5 stroke:#16a34a,stroke-width:3px;
linkStyle 6 stroke:#dc2626,stroke-width:4px;

%% Storage Flows
linkStyle 7 stroke:#f59e0b,stroke-width:4px;
linkStyle 8 stroke:#9333ea,stroke-width:4px;

%% Operation Logs
linkStyle 9 stroke:#8b5cf6,stroke-width:4px;

%% Revision Store
linkStyle 10 stroke:#16a34a,stroke-width:3px;

%% Presence
linkStyle 11 stroke:#16a34a,stroke-width:3px;

%% Event Driven Services
linkStyle 12 stroke:#dc2626,stroke-width:3px;
linkStyle 13 stroke:#dc2626,stroke-width:3px;
linkStyle 14 stroke:#dc2626,stroke-width:3px;

The API Gateway handles authentication, rate limiting, and routing. Document Service manages CRUD operations on document metadata and content. The Collaboration Server is the heart of real-time editing. It maintains persistent WebSocket connections, routes operations between users sharing a document, and drives the OT engine. The Presence Service handles cursor positions, user avatars, and active session tracking. The Version History Service asynchronously processes the operation log and creates navigable revision snapshots.

Active documents live in a distributed in-memory cache for fast reads. The Operation Log is an append-only record of every mutation. The Document Store holds the current authoritative document state. The Revision Store holds compressed snapshots for version history.

## Real-Time Collaborative Editing Pipeline

This is where the interesting engineering happens. Let us trace what happens from the moment you press a key to when your collaborator sees the change.

flowchart TD;
    A[User Presses Key];
    B[Local State Update];
    C[Operation Generated];
    D[Optimistic UI Applied];
    E[Operation Queued];
    F[WebSocket Send];
    G[Collaboration Server Receives];
    H[OT Engine Transforms];
    I[Operation Applied to Doc State];
    J[Operation Logged];
    K[Broadcast to Other Clients];
    L[Other Clients Transform and Apply];

    A &#8211;> B;
    B &#8211;> C;
    C &#8211;> D;
    D &#8211;> E;
    E &#8211;> F;
    F &#8211;> G;
    G &#8211;> H;
    H &#8211;> I;
    I &#8211;> J;
    J &#8211;> K;
    K &#8211;> L;

    classDef action fill:#2563eb,stroke:#1e40af,color:#ffffff;
    classDef local fill:#16a34a,stroke:#166534,color:#ffffff;
    classDef server fill:#7c3aed,stroke:#5b21b6,color:#ffffff;
    classDef storage fill:#9333ea,stroke:#6b21a8,color:#ffffff;

    class A,B,C,D,E action;
    class F local;
    class G,H,I,J,K server;
    class L local;

When you press a key, the client does not wait for server confirmation. It applies the change locally immediately. This is called an optimistic update and it is the reason editing feels instantaneous. If the client had to wait for the server before updating the display, the latency would be noticeable and the experience would feel sluggish.

The operation is serialized and placed in a send queue. The WebSocket connection picks it up and sends it to the Collaboration Server, where the OT Engine takes over.

The OT Engine receives the operation with a revision number. The revision number tells the server which version of the document the client was looking at when it generated the operation. If the server has processed operations since that revision, the incoming operation must be transformed against those intermediate operations before it can be safely applied.

Once transformed, the operation is applied to the in-memory document state, appended to the operation log, and broadcast to all other connected clients. Those clients run their own local transformation to reconcile the incoming operation with any local pending operations they have not yet received confirmation for.

The key insight is that every participant maintains a queue of sent-but-unacknowledged operations. When a remote operation arrives, the client transforms it against that queue to figure out what it means in the context of the current local state.

## Operational Transformation Deep Dive

Operational Transformation is the algorithm that makes concurrent editing mathematically safe. The core idea is that instead of sending document snapshots, you send operations that describe mutations, and when those operations need to be applied in a different context than they were generated in, you transform them to account for that difference.

An operation is typically one of a small set of types:

- Insert(position, content): Insert content at a given character position

- Delete(position, length): Delete a run of characters starting at a position

- Retain(length): Skip over a number of characters without changing them

The critical property that OT must satisfy is called the TP1 convergence property. If two operations O1 and O2 are generated against the same document state, then applying O1 followed by Transform(O2, O1) must produce the same result as applying O2 followed by Transform(O1, O2). In other words, the order of application must not matter as long as transformations are applied correctly.

Let us walk through a concrete example.

The document contains: 

User A generates Insert(2, &ldquo;XY&rdquo;) creating: 
User B generates Delete(3, 2) against the original, intending to delete : 

Now these operations arrive at the server in the order A then B. A is applied: . Now B needs to be transformed against A before application. A inserted 2 characters at position 2. B's delete was at position 3. Since position 3 is after position 2, B's delete position must shift right by the number of characters A inserted: Delete(5, 2). Apply that to  and you get . Correct.

If they arrive in order B then A: B is applied to  giving . Now A needs to be transformed against B. A inserted at position 2. B deleted from position 3. Since position 3 is after position 2, A's insert position is not affected. Apply Insert(2, &ldquo;XY&rdquo;) to  giving . Same result.

This works for simple cases, but real documents have complex nested operations, rich text formatting, lists, tables, embedded objects, and simultaneous changes from dozens of users. The transformation functions for each operation type must handle every possible combination of overlapping operations. Getting this right is notoriously difficult.

There are also ordering problems. The server imposes a total order on operations. Every client must eventually apply operations in that order. But clients may have locally applied operations that are not yet acknowledged. Those must be transformed against every server-acknowledged operation that arrives while they are still pending.

flowchart TD;

%% =========================
%% Initial Client States
%% =========================
A[Client A State
Revision 5];
B[Client B State
Revision 5];

%% =========================
%% Concurrent Operations
%% =========================
C[Client A Generates
Operation A at Rev 5];

D[Client B Generates
Operation B at Rev 5];

%% =========================
%% Server Processing
%% =========================
E[Server Receives
Operation A First];

F[Apply Operation A
Document becomes Rev 6];

G[Server Receives
Operation B at Rev 5];

H[OT Engine Transforms
Operation B against Operation A];

I[Apply Transformed Operation B
Document becomes Rev 7];

%% =========================
%% Broadcast Phase
%% =========================
J[Broadcast Operation A
to Client B];

K[Broadcast Transformed Operation B
to Client A];

%% =========================
%% Client Reconciliation
%% =========================
L[Client A Receives Operation B
Transforms against Pending Ops];

M[Client B Receives Operation A
Applies Directly];

%% =========================
%% Main Flow
%% =========================
A &#8211;>|Local Edit| C;

B &#8211;>|Local Edit| D;

C &#8211;>|Send to Server| E;

D &#8211;>|Send to Server| G;

E &#8211;>|Server Processing| F;

F &#8211;>|Current Revision = 6| H;

G &#8211;>|Incoming Older Revision| H;

H &#8211;>|Operational Transform| I;

%% =========================
%% Broadcast Updates
%% =========================
I &#8211;>|Sync Peers| J;

I &#8211;>|Sync Peers| K;

%% =========================
%% Client Sync
%% =========================
J &#8211;>|Apply Remote Edit| M;

K &#8211;>|Reconcile Local Pending Changes| L;

%% =========================
%% Fancy Styles
%% =========================

%% Clients
style A fill:#2563eb,stroke:#1e40af,stroke-width:4px,color:#ffffff;
style B fill:#2563eb,stroke:#1e40af,stroke-width:4px,color:#ffffff;

%% Operations
style C fill:#16a34a,stroke:#166534,stroke-width:4px,color:#ffffff;
style D fill:#16a34a,stroke:#166534,stroke-width:4px,color:#ffffff;

%% Server and OT Engine
style E fill:#7c3aed,stroke:#5b21b6,stroke-width:4px,color:#ffffff;
style F fill:#8b5cf6,stroke:#6d28d9,stroke-width:5px,color:#ffffff;
style G fill:#7c3aed,stroke:#5b21b6,stroke-width:4px,color:#ffffff;
style H fill:#ec4899,stroke:#be185d,stroke-width:6px,color:#ffffff;
style I fill:#a855f7,stroke:#7e22ce,stroke-width:5px,color:#ffffff;

%% Broadcast and Client Sync
style J fill:#f59e0b,stroke:#b45309,stroke-width:4px,color:#000000;
style K fill:#f59e0b,stroke:#b45309,stroke-width:4px,color:#000000;

style L fill:#06b6d4,stroke:#0e7490,stroke-width:4px,color:#ffffff;
style M fill:#06b6d4,stroke:#0e7490,stroke-width:4px,color:#ffffff;

%% =========================
%% Link Styling
%% =========================

%% Local Operations
linkStyle 0 stroke:#2563eb,stroke-width:3px;
linkStyle 1 stroke:#2563eb,stroke-width:3px;

%% Send Operations
linkStyle 2 stroke:#16a34a,stroke-width:4px;
linkStyle 3 stroke:#16a34a,stroke-width:4px;

%% Server Processing
linkStyle 4 stroke:#7c3aed,stroke-width:4px;
linkStyle 5 stroke:#8b5cf6,stroke-width:4px;
linkStyle 6 stroke:#7c3aed,stroke-width:4px;
linkStyle 7 stroke:#ec4899,stroke-width:5px;

%% Broadcast Phase
linkStyle 8 stroke:#f59e0b,stroke-width:4px;
linkStyle 9 stroke:#f59e0b,stroke-width:4px;

%% Client Reconciliation
linkStyle 10 stroke:#06b6d4,stroke-width:4px;
linkStyle 11 stroke:#06b6d4,stroke-width:4px;

Google's approach, as documented in academic papers from the Wave project, also deals with a second property called TP2, which is needed when you have more than two clients. TP2 says that transforming O3 against O1 and then O2 must give the same result as transforming O3 against the composition of O1 followed by O2. Not all OT algorithms satisfy TP2, and the ones that do tend to be more complex. Google's system uses a server-based transformation model where the server acts as the arbiter of operation order, which simplifies the requirements compared to peer-to-peer OT.

## CRDT Concepts and Comparison

Operational Transformation is not the only approach to conflict-free collaborative editing. Conflict-free Replicated Data Types, or CRDTs, take a fundamentally different angle.

Where OT says &ldquo;I will transform your operation to account for mine,&rdquo; CRDTs say &ldquo;I will design the data structure such that merging any two states always produces the same result, regardless of order.&rdquo; The conflict resolution is baked into the data type itself rather than into a separate algorithm.

The most well-known CRDT for collaborative text is LSEQ or RGA (Replicated Growable Array). Instead of character positions (which are fragile under concurrent inserts), each character gets a globally unique identifier that encodes its intended position relative to its neighbors. When characters are deleted, they are typically tombstoned rather than removed, so that position references do not become invalid.

Because each operation is self-describing and idempotent, you do not need a central server to impose operation ordering. Operations can travel through the network in any order and still converge. This makes CRDTs naturally suited for peer-to-peer and decentralized systems.

  
    
      
        Property
        Operational Transformation
        CRDT
      
    
    
      
        Conflict resolution
        Algorithmic transformation of operations
        Embedded in data structure design
      
      
        Ordering requirement
        Requires central server for total order
        Works without ordering guarantees
      
      
        Memory overhead
        Lower; characters are regular positions
        Higher; tombstones and unique IDs accumulate
      
      
        Implementation complexity
        Complex transformation functions
        Complex data structure management
      
      
        Network topology
        Typically hub-and-spoke via server
        Supports peer-to-peer naturally
      
      
        Deletion semantics
        Clean position-based deletions
        Tombstone-based, can accumulate garbage
      
      
        Offline support
        Requires careful operation queuing
        Native; merge on reconnect
      
      
        Rich text support
        Mature, well-studied
        More complex; less standardized
      
      
        Production adoption
        Google Docs, Etherpad
        Figma, Notion, Automerge-based systems
      
    
  

Google Docs uses OT rather than CRDTs for historical reasons and because OT's server-centric model fits naturally with the rest of its infrastructure. Systems like Figma and some newer collaborative tools use CRDTs because the peer-to-peer properties simplify certain scaling concerns.

The honest engineering answer is that neither is strictly superior. CRDTs trade memory and garbage collection complexity for ordering flexibility. OT trades centralized ordering requirements for cleaner memory semantics and well-understood algorithms for rich text.

## Real-Time Synchronization Infrastructure

The synchronization layer is what makes the collaborative editing experience feel live. The foundation is WebSockets.

HTTP was designed for request-response. For real-time collaboration, you need a persistent, bidirectional channel where both the client and server can push messages at any time. WebSockets provide this. When you open a Google Doc, the browser establishes a WebSocket connection to a Collaboration Server. That connection stays open as long as you have the document open.

The Collaboration Server maintains a room for each active document. Every client session connected to the same document is part of the same room. When the server receives a transformed operation, it broadcasts it to all other sessions in the room. This is the broadcast step in the pipeline we saw earlier.

flowchart TD;
    A[Client A WebSocket];
    B[Client B WebSocket];
    C[Client C WebSocket];
    D[Collaboration Server Room];
    E[OT Engine];
    F[Operation Log];
    G[In-Memory Doc State];

    A &#8211;>|op at rev 12| D;
    D &#8211;> E;
    E &#8211;> G;
    G &#8211;> F;
    D &#8211;>|transformed op| B;
    D &#8211;>|transformed op| C;

    classDef client fill:#2563eb,stroke:#1e40af,color:#ffffff;
    classDef server fill:#7c3aed,stroke:#5b21b6,color:#ffffff;
    classDef storage fill:#9333ea,stroke:#6b21a8,color:#ffffff;

    class A,B,C client;
    class D,E server;
    class F,G storage;

One of the trickier problems is what happens when a client disconnects and reconnects. The client may have been offline for anywhere from a few seconds to several minutes. During that time, the document may have advanced many revisions. The client has a queue of locally generated operations that were never acknowledged.

On reconnect, the client sends its pending operations along with the last revision it acknowledges. The server replays all operations that happened since that revision, transforms the client's pending operations against that history, and sends back the catch-up state. The client discards its optimistic local state and applies the authoritative reconciled state.

This reconnection protocol is one of the places where bugs most commonly lurk in collaborative editing systems. Edge cases include clients reconnecting in the middle of a server broadcast, operations that were partially received before disconnection, and clock skew between client and server revision numbering.

Presence information, meaning cursor positions and user avatars, travels through the same WebSocket channel but is treated differently. Cursor updates are high-frequency but low-stakes. If a cursor position update is lost, the worst outcome is a slightly stale cursor display. So cursor updates are sent at a throttled rate and are not guaranteed to be delivered or applied in order. They are independent of the operation transformation pipeline.

## Presence and Cursor Tracking Systems

When you see your colleague's colored cursor blinking a few paragraphs above yours, that involves a surprisingly subtle set of engineering decisions.

The naive approach is to send cursor position as a document character offset. But character offsets are fragile under concurrent edits. If Priya inserts 50 characters before Amos's cursor position, Amos's cursor would appear to jump 50 characters forward if you are not tracking this. The cursor position must be transformed through the same operation pipeline as edits, or maintained as a reference to a document anchor rather than an absolute offset.

Presence updates are rate-limited and batched. If you are typing quickly, your cursor position changes on every keystroke, but the system does not send a presence update for every character. It batches updates and sends at most a few times per second. This dramatically reduces the network traffic for active sessions.

The Presence Service uses a separate in-memory store, typically a Redis cluster, to hold current cursor state for all active sessions. Reads are fast. State is ephemeral. If the Redis node goes down, cursor presence is lost, but nobody's document is corrupted.

User avatars and names are resolved from the identity service and cached on the collaboration server. When a new user joins a document session, the server sends a presence join event to all other clients in the room so that avatars appear instantly.

## Version History System

One of the most underappreciated parts of Google Docs is that it stores the complete editing history of every document. You can rewind a five-year-old document to see exactly what it looked like at any moment. This is a non-trivial storage and systems problem.

The simplest approach would be to snapshot the document on every save. But documents change hundreds of times per editing session. Storing a full snapshot each time would be enormously wasteful. A document that is a few kilobytes of text would accumulate gigabytes of history.

The practical approach is a combination of operation logs and periodic snapshots.

Every operation that is applied to a document is appended to the operation log in durable storage. This log is the ground truth for document history. To reconstruct the document at any point in time, you can replay the log from the beginning up to the desired timestamp. But replaying millions of operations is expensive, so the system also maintains periodic snapshots.

flowchart TD;
    A[Operation Applied];
    B[Append to Operation Log];
    C[Update In-Memory State];
    D[Snapshot Trigger Check];
    E[Every N Operations or T Time];
    F[Serialize Current Doc State];
    G[Compress and Store Snapshot];
    H[Tag Snapshot with Rev Number];
    I[Version History Index Updated];

    A &#8211;> B;
    A &#8211;> C;
    B &#8211;> D;
    D &#8211;> E;
    E &#8211;> F;
    F &#8211;> G;
    G &#8211;> H;
    H &#8211;> I;

    classDef op fill:#2563eb,stroke:#1e40af,color:#ffffff;
    classDef storage fill:#9333ea,stroke:#6b21a8,color:#ffffff;
    classDef snapshot fill:#16a34a,stroke:#166534,color:#ffffff;
    classDef index fill:#f59e0b,stroke:#b45309,color:#000000;

    class A,B op;
    class C,D storage;
    class E,F,G snapshot;
    class H,I index;

A snapshot is created every N operations (where N might be something like 100 or 500) or every T minutes, whichever comes first. To look up the document state at revision R, the system finds the most recent snapshot at or before revision R, loads that snapshot, and then replays only the operations between the snapshot and R. Instead of replaying 10 million operations, you might replay at most a few hundred.

Snapshots are stored compressed. Plain text documents compress extraordinarily well because text has high redundancy. Even rich-text documents with formatting metadata compress well using standard algorithms like Brotli or Zstandard.

The version history UI in Google Docs also groups changes into named milestones. These are user-created or automatically generated labels attached to specific revisions in the snapshot index. The underlying storage is the same; it just has a human-readable tag attached.

Restoring a document to a previous version is implemented as applying a new operation that replaces the current document state with the historical snapshot. This means restoring is also tracked in the operation log, so you can undo a restore.

## Autosave Architecture

The autosave system has a deceptively simple job: make sure that if your browser crashes or your laptop loses power, you lose as little work as possible. In practice, building a reliable autosave is harder than it looks.

Google Docs does not save on a timer the way older applications do. It saves continuously. Every operation that the client sends to the server is also persisted in the operation log on the server side. So in a sense, the document is saved every few hundred milliseconds as you type, because that is how often operations are flushed from the client to the server.

But what about the window between your keystroke and the server acknowledging receipt? That is where local persistence comes in.

The client maintains a local buffer of pending operations in memory. For offline support, which we will get to, these are also written to IndexedDB in the browser. If the tab crashes or the browser closes unexpectedly, the next time you open the document, the client can detect that there are unrecorded local operations and attempt to replay them.

The server-side autosave pipeline is event-driven. Each accepted operation triggers a write to the operation log. The operation log is the durable record. The document's in-memory state in the cache is rebuilt from this log. If the Collaboration Server crashes, another server picks up the document and loads state from the operation log and the most recent snapshot. Recovery is fast because the log is append-only and the snapshot is always consistent.

The frequency of autosave creates an interesting tradeoff. Saving more frequently means less data loss on failure, but it also means more write load on the operation log store. Google's approach of making every operation an atomic log append gives you continuous persistence without creating artificial batch saves at arbitrary intervals.

## Offline Editing and Synchronization

Offline editing is one of those features that sounds like a nice-to-have until you lose your internet on a train and realize you were in the middle of writing something important.

When you go offline, the client detects this through WebSocket disconnection and network change events. From that point, edits continue to be applied locally. The client generates operations as you type, applies them to the local in-memory document state, and queues them in IndexedDB for durability. The local editing experience is indistinguishable from online editing.

When you reconnect, the client sends all queued operations to the server with the revision number they were generated against. If the document has not changed on the server while you were offline, the operations apply cleanly. If other collaborators made changes while you were disconnected, the OT engine transforms your operations against theirs, and the reconciliation proceeds as in the normal concurrent editing case.

The tricky scenarios are longer offline periods where the operation queue grows large, or where the underlying document structure changed dramatically while you were offline. Imagine you went offline and wrote a whole new section, and while you were offline someone else deleted the section you were writing in. The reconciliation has to handle that gracefully without losing either person's intent.

Google's approach here is to replay all queued operations through the OT engine against the server's accumulated state since the last known good revision. The result might not always be exactly what either party intended in a semantic sense, but it will always produce a valid, consistent document state. The system prioritizes correctness over always guessing the right human intent.

## Database and Storage Design

The data layer of a system like this has to make hard choices about consistency, throughput, and operational simplicity.

Documents in Google Docs are not simple blobs. They have rich structure: paragraphs, headings, lists, tables, inline images, comments, suggestions, and formatting spans. The internal representation is more like a structured tree than raw text. Operations in the OT log describe mutations to this tree, not just plain text positions.

A simplified view of the storage schema looks like this:

The  table is the most write-intensive table in the system. It must support high-throughput sequential appends and fast range reads by . This is a natural fit for a time-series or log-oriented storage engine. Google's internal systems would use Bigtable or Spanner for this, where rows can be stored in sorted key order and range scans are efficient.

The  table is read-heavy during version history navigation and write-infrequent during normal editing. Snapshots are typically stored in an object store like Google Cloud Storage with metadata indexed in Spanner.

The  table is updated constantly during active editing and should live in a low-latency cache layer like Redis rather than durable storage. Presence state is inherently ephemeral.

  
    
      
        Storage Layer
        Technology
        Consistency Level
        Primary Concern
      
    
    
      
        Operation Log
        Spanner / Bigtable
        Strong, serializable
        Append throughput, range read speed
      
      
        Document Metadata
        Spanner
        Strong
        Consistency for permissions checks
      
      
        Snapshot Store
        GCS + Spanner metadata
        Eventually consistent for reads
        Storage cost, compression ratio
      
      
        Active Document Cache
        In-memory on Collab Server
        Single writer
        Sub-millisecond operation apply
      
      
        Presence State
        Redis
        Best effort
        Write throughput, low latency
      
      
        Permission Cache
        Redis + local cache
        Eventually consistent
        Fast auth checks per operation
      
    
  

## Event-Driven Architecture

Operations in Google Docs do not travel through a monolithic service. Different concerns are handled by different services, and they communicate through an event bus.

When an operation is applied by the OT Engine, it emits an event to the event bus. Subscribers to this event include:

- The Version History Service, which asynchronously processes operations to update the operation log and trigger snapshot creation

- The Notification Service, which checks if the operation should send email notifications to document watchers

- The Search Indexer, which updates full-text search indexes for the document

- The Analytics pipeline, which records document activity for usage metrics

Using an event bus means these consumers can be scaled independently. If the notification service is slow, it does not block the real-time editing pipeline. If the search indexer falls behind, real-time collaboration is unaffected. The editing pipeline is the critical path, and everything else is asynchronous and decoupled.

The event bus itself must be durable. If the notification service is down when an operation event is emitted, the event cannot be lost. A Kafka-like system with persistent message logs and consumer group offsets is the natural fit here. Consumers can catch up from their last processed offset after a restart.

## Caching System Design

A document with fifty active collaborators generates dozens of operations per second. If every operation had to go through a database read-write cycle, the latency would be unacceptable and the storage load would be enormous.

The active document state lives in memory on the Collaboration Server that owns the document. When a document is first accessed, its state is loaded from the most recent snapshot and reconstructed by replaying recent operations. After that, all operations are applied to the in-memory state and the snapshot is updated asynchronously.

This means reads of the current document state are effectively free from a latency standpoint. They are already in memory. The only writes that hit durable storage synchronously are operation log appends, which are sequential and fast.

The tricky case is hotspot documents: a shared document with hundreds of simultaneous editors. A single Collaboration Server can only handle so many concurrent WebSocket connections and operations per second before it becomes a bottleneck. For extremely hot documents, the system can shard the document into sections and distribute sections across multiple servers, though this adds complexity to the OT coordination across shards.

  
    
      
        Cache Layer
        What It Holds
        Eviction Policy
        Invalidation Strategy
      
    
    
      
        Collab Server In-Memory
        Active document state, pending ops
        Document unloads after inactivity
        N/A; single writer per document
      
      
        Redis Presence Cache
        Cursor positions, active sessions
        TTL per session (seconds)
        Direct invalidation on disconnect
      
      
        Redis Permission Cache
        ACL lookups per doc+user
        TTL (minutes)
        Push invalidation on share change
      
      
        Revision Cache
        Recent document snapshots
        LRU by document popularity
        Version-stamped keys
      
      
        Client-Side IndexedDB
        Offline ops, doc state, drafts
        Manual cleanup on sync
        Cleared on successful reconciliation
      
    
  

## Permission and Sharing Systems

Permissions in Google Docs are a deceptively complex system because they are both hierarchical and dynamic.

A document can be owned by an individual, shared with specific users, shared with an entire Google Workspace domain, or made public to anyone with the link. Each level has a role: viewer, commenter, editor, or owner. And permissions can be changed at any time by someone with sufficient access.

The permission check happens on every operation before it is accepted. &ldquo;Can this user perform this operation on this document?&rdquo; is evaluated at the collaboration server level using a cached version of the permission data. The cache has a short TTL and is invalidated on permission changes, balancing performance against correctness.

Access revocation is one of the more subtle cases. When someone's access is revoked, any active WebSocket sessions they have for that document must be terminated. This requires pushing an invalidation event to the Collaboration Server, which then closes the relevant connections. If this is not handled promptly, a revoked user could continue receiving document updates for the duration of their WebSocket session.

## Scalability Deep Dive

Building a collaborative editor for millions of simultaneous users requires thinking carefully about every component's scaling behavior.

The Collaboration Server is the most constrained component because it holds per-document in-memory state and maintains WebSocket connections. Horizontal scaling here is tricky because all users editing the same document must connect to the same server instance (or a coordinating cluster) to maintain OT correctness.

The solution is consistent hashing on document ID. All users editing document D are routed to the same Collaboration Server (or set of servers for high-traffic documents). This means the collaboration layer scales by adding more server instances and redistributing document ownership. A document migration is needed when a server is added or removed, but since documents with no active editors are just database entries, the migrations only matter for active documents.

  
    
      
        Component
        Scaling Strategy
        Key Bottleneck
        Mitigation
      
    
    
      
        API Gateway
        Stateless horizontal scaling
        Authn/authz latency
        Token caching, edge validation
      
      
        Collaboration Server
        Document-based sharding
        Hot documents, WebSocket limits
        Per-document load balancing
      
      
        OT Engine
        Co-located with Collab Server
        Complex operation transforms
        Efficient algorithms, batching
      
      
        Operation Log
        Partitioned by doc_id
        Write throughput per hot doc
        Batched log appends
      
      
        Presence Service
        Stateless + Redis cluster
        Update frequency at scale
        Client-side rate limiting
      
      
        Version History
        Async, independent scaling
        Snapshot generation cost
        Background jobs, compression
      
    
  

Multi-region deployments add another dimension. For latency reasons, you want users to connect to a collaboration server geographically close to them. But document ownership is typically in one primary region, and cross-region OT coordination adds latency. Google addresses this with leader-based replication where the primary region owns the OT coordination for a document and other regions forward operations to the primary and receive broadcasts back.

## Reliability and Availability

Even a well-designed system fails. The reliability story for Google Docs is built around making failures fast to detect and recover from.

Every Collaboration Server exposes health check endpoints and emits operational metrics: operation processing latency, WebSocket connection count, operation queue depths, and error rates. A service mesh monitors these and routes traffic away from unhealthy servers.

When a Collaboration Server crashes mid-operation, the clients connected to it detect the disconnect through WebSocket closure events. They enter a reconnect loop, which first tries to reconnect to the same server and then falls back to other servers in the pool. The new server loads the document state from the operation log and snapshot store, and the clients replay their pending operations.

The operation log itself is the durability guarantee. As long as every applied operation is appended to the durable log before a success acknowledgment is sent to the client, no work is ever lost due to server failure. The in-memory state on the server can always be reconstructed. This is an important design choice: durability before acknowledgment. The performance cost of a synchronous log write is worth the correctness guarantee.

## Engineering Tradeoffs in Practice

Every major design decision in this system involves a genuine tradeoff. Let us look at a few that are worth discussing in an interview or architecture review.

The choice between OT and CRDTs is not purely technical. OT requires a central server to impose operation order, which fits naturally with a server-centric deployment. But it makes peer-to-peer or decentralized editing harder. CRDTs enable decentralized architectures but consume more memory due to tombstones and require more complex GC logic. For a system as large as Google Docs with billions of documents, the memory overhead of CRDTs would be significant.

Optimistic updates (applying changes locally before server confirmation) dramatically improve the editing experience but introduce complexity. Every client must maintain a pending operation queue and be prepared to reconcile local state when server-transformed operations arrive. Getting this wrong produces jitter: text appearing to jump around as local state is corrected. Google invests significant engineering in making this invisible to users.

Autosave frequency versus storage cost is a real tension. Every operation appended to the operation log is durable storage that costs money. Over a billion documents each with hundreds of daily operations, the log grows fast. Compression and periodic compaction (merging many small operations into a single snapshot) are essential for keeping storage costs manageable.

The consistency versus availability tradeoff in the permission system is another example. Strong consistency means that when you revoke someone's access, they are guaranteed to be locked out within milliseconds. But achieving that requires synchronous permission invalidation across distributed caches, which adds latency to every operation. Most systems accept a short window of stale permission state in exchange for lower latency in the common case.

## Real-World Technology Stack

A system like Google Docs would realistically be built with a combination of:

Java and Go for backend services. Java is heavily used at Google for services that benefit from mature libraries and the JVM ecosystem. Go is increasingly used for high-throughput, low-latency network servers like the Collaboration Server, where its goroutine model handles thousands of concurrent WebSocket connections efficiently.

TypeScript on the client side. The document editor itself is a complex stateful application. TypeScript provides the type safety necessary to manage the OT operation types, document state, and synchronization state without making subtle bugs in the transformation logic.

WebSockets for real-time communication. No serious alternative exists for low-latency bidirectional communication in browsers. gRPC-web or Server-Sent Events could handle one-way push, but the full bidirectional nature of collaborative editing requires WebSockets.

Redis for presence and cache layers. The sub-millisecond read latency and support for pub/sub make Redis the natural choice for ephemeral state that needs to be shared across servers.

Spanner for the operation log and document metadata. Spanner's combination of global consistency and horizontal scalability is uniquely suited to operation logs that need total ordering within a document while being distributed across datacenters.

Kafka for the event bus. The durable, ordered, partitioned log model maps perfectly to the operation event stream. Consumers can independently tail the log and process events at their own pace.

Protocol Buffers for serialization. Operations, document state, and presence updates are all serialized as protobufs. The schema enforcement and compact binary format are both important at this scale.

Kubernetes for orchestration. The collaboration servers, presence services, and all stateless services run in Kubernetes clusters for automated deployment, scaling, and health management.

## System Design Interview Perspective

If you are asked to design Google Docs or a real-time collaborative text editor in a system design interview, there are several areas where strong candidates distinguish themselves from average ones.

Weak answers describe the feature set and then jump to &ldquo;we need WebSockets and a database.&rdquo; They miss the fundamental difficulty of the problem, which is concurrent state management.

Strong answers immediately identify Operational Transformation or CRDTs as the core algorithmic challenge. They explain why naive approaches (last-write-wins, locking) do not work for collaborative text editing and why you need a conflict resolution algorithm that preserves intent.

Strong answers also treat the server architecture as a distributed systems problem. The Collaboration Server cannot be a simple stateless service because it holds document state. That statefulness has sharding and failover implications that need to be addressed.

In terms of interview structure, a good approach is to:

Start with the data model. What does an operation look like? What does document state look like?

Move to the synchronization protocol. How do you handle two users editing the same character position at the same time?

Address the infrastructure. WebSockets, Collaboration Server design, operation log, caching.

Discuss scaling. How do you handle 10,000 concurrent editors on the same document? Different document? Multi-region?

Address reliability. What happens when the Collaboration Server crashes mid-operation? What happens when a client loses connectivity?

Common mistakes include: forgetting offline editing entirely, treating permission checks as trivially easy, ignoring the presence system, not explaining how version history is stored efficiently, and failing to discuss the tradeoff between optimistic updates and correctness.

One thing interviewers consistently value is when a candidate explains why a design choice was made rather than just what the choice is. &ldquo;We use append-only operation logs because they give us both durability and a basis for version history reconstruction without the complexity of mutable state management&rdquo; is a much stronger statement than &ldquo;we log every operation.&rdquo;

## Putting It All Together

Google Docs is a reminder that the features users take for granted are often the hardest engineering problems. That blinking cursor synchronized across continents. That version history that goes back five years. That editing session that recovers seamlessly after your laptop loses wifi on a train. None of it is simple.

The system is built on a foundation of formally correct algorithms, append-only durable storage, event-driven asynchronous processing, and carefully managed in-memory state. Every component is designed with failure in mind: what happens when this goes down, what state is lost, and how do we recover?

Understanding these systems at this level of depth is useful not just for interviews. The patterns here - OT for concurrent state management, append-only logs for durability, event sourcing for derived state, optimistic updates with reconciliation - show up in many distributed systems. Understanding why they exist in Google Docs helps you recognize where to apply them elsewhere.

The next time you type into a shared document and watch your colleague's cursor respond, you will have a better sense of what just happened.
