---
title: "Energy Requirements for AI Infrastructure: Current and Future Impacts"
date: "2025-07-26T21:16:34+05:30"
slug: "energy-requirements-for-ai-infrastructure-current-and-future-impacts"
categories: ["llm", "ai", "energy", "data_center"]
original_url: "https://rishijeet.github.io/blog/energy-requirements-for-ai-infrastructure-current-and-future-impacts/"
word_count: 1843
reading_time: "9 min"
author: "Rishijeet Mishra"
---

# Energy Requirements for AI Infrastructure: Current and Future Impacts

*Published on 2025-07-26 by Rishijeet Mishra | [https://rishijeet.github.io/blog/energy-requirements-for-ai-infrastructure-current-and-future-impacts/](https://rishijeet.github.io/blog/energy-requirements-for-ai-infrastructure-current-and-future-impacts/)*

The rapid expansion of artificial intelligence (AI), particularly large language models (LLMs) and generative AI, has driven an unprecedented surge in energy demand due to the computational intensity of training and operating these systems. Eric Schmidt, former Google CEO, has highlighted electricity as the primary limiter of AI growth, estimating that the U.S. will require an additional 92 gigawatts (GW) of power—equivalent to the output of 92 nuclear power plants—to sustain the AI revolution. This analysis explores the current energy consumption of major companies’ AI infrastructure, projects future energy needs through 2035, and examines how these demands will reshape the energy sector, drawing on available data from web sources and posts on X.

## Current Energy Consumption by Major Companies

### Overview

Major tech companies, or “hyperscalers” (e.g., Microsoft, Google, Meta, Amazon, OpenAI), are the primary drivers of AI infrastructure energy demand, operating massive data centers for training and inference of AI models. Training a single state-of-the-art AI model, such as OpenAI’s GPT-4, can consume 50 gigawatt-hours (GWh) of electricity, equivalent to the annual energy use of 4,800 U.S. households. Inference (running AI models for user queries) is also energy-intensive, with a single ChatGPT query requiring approximately 2.9 watt-hours, nearly 10 times that of a Google search (0.3 watt-hours). Below is an overview of key players’ energy footprints based on available data:

![Alt text](https://rishijeet.github.io/images/2025/Screenshot%202025-07-26%20at%208.43.24%E2%80%AFPM.png)

- Microsoft:

Current Usage: Microsoft’s data centers, which support Azure and AI initiatives like Copilot, consumed an estimated 17 GW of power globally in 2023, with AI workloads accounting for a growing share. Training a single large model can require 50-100 GWh, and inference for millions of daily queries adds significantly to this demand.

- Initiatives: Microsoft has committed to purchasing 10.5 GW of renewable energy from Brookfield Asset Management between 2026 and 2030 to power its AI data centers, marking one of the largest corporate renewable energy deals to date.[](https://www.energypolicy.columbia.edu/projecting-the-electricity-demand-growth-of-generative-ai-large-language-models-in-the-us/)

- Specific Projects: Microsoft’s deal to buy power from the reopened Three Mile Island nuclear reactor (Constellation Energy) will provide 835 MW of carbon-free power for 20 years, targeting AI data center needs.[](https://energy.mit.edu/news/the-multi-faceted-challenge-of-powering-ai/)

- Google:

Current Usage: Google’s global data center power consumption is estimated at 15-20 GW, with AI workloads (e.g., Gemini models) contributing 14% of this demand in 2023. Google expects to spend $75 billion on AI infrastructure in 2025, much of which will go toward energy-intensive data centers.[](https://www.technologyreview.com/2025/05/20/1116327/ai-energy-usage-climate-footprint-big-tech/)[](https://www.goldmansachs.com/insights/articles/ai-to-drive-165-increase-in-data-center-power-demand-by-2030)

- Initiatives: Google is investing in renewable energy and has issued a roadmap emphasizing AI’s potential to drive a “new era of American innovation” through productivity gains, but acknowledges that energy demands will outpace current infrastructure.[](https://www.city-journal.org/article/artificial-intelligence-energy-electricity-demand)

- Meta:

Current Usage: Meta’s planned $10 billion AI data center in Louisiana, set to begin operations in 2028, will require 2 GW for computation alone, with additional power for cooling. This single facility’s energy demand is equivalent to that of 200,000 households.[](https://www.technologyreview.com/2025/05/20/1116272/ai-natural-gas-data-centers-energy-power-plants/)

- Initiatives: Meta is investing over $200 million in infrastructure (roads, water systems) to support its data centers and claims to cover the full cost of utility grid upgrades to avoid passing costs to consumers.[](https://www.technologyreview.com/2025/05/20/1116272/ai-natural-gas-data-centers-energy-power-plants/)

- OpenAI:

Current Usage: Training GPT-4 consumed an estimated 50 GWh, enough to power San Francisco for three days. With millions of daily queries, OpenAI’s inference energy demand is significant, though exact figures are undisclosed due to the company’s lack of transparency.[](https://www.technologyreview.com/2025/05/20/1116327/ai-energy-usage-climate-footprint-big-tech/)[](https://www.forbes.com/sites/arielcohen/2024/05/23/ai-is-pushing-the-world-towards-an-energy-crisis/)

- Initiatives: OpenAI’s Stargate initiative, announced with President Donald Trump, aims to build data centers consuming up to 5 GW each, with a total investment of $500 billion. This project could require 15-25 GW across multiple facilities, equivalent to the power needs of a small state.[](https://www.technologyreview.com/2025/05/20/1116327/ai-energy-usage-climate-footprint-big-tech/)[](https://www.cfr.org/blog/america-may-not-need-massive-energy-build-out-power-ai-revolution)

- Amazon:

Current Usage: Amazon Web Services (AWS) operates over 100 data centers globally, with an estimated power consumption of 20 GW in 2023. AI workloads, including Amazon Bedrock and custom AI chips, are driving increased energy use, though specific AI-related figures are not publicly detailed.

- Initiatives: Amazon is investing in renewable energy and energy-efficient data center designs but faces challenges in scaling power supply to meet AI-driven demand.[](https://www.nature.com/articles/d41586-025-00616-z)

### Aggregate Industry Impact

- Global Data Center Demand: In 2023, global data centers consumed 240-340 terawatt-hours (TWh), or 1-1.3% of world electricity demand, with AI-specific data centers accounting for approximately 14 GW of additional capacity.[](https://www.energypolicy.columbia.edu/projecting-the-electricity-demand-growth-of-generative-ai-large-language-models-in-the-us/)[](https://www.nature.com/articles/d41586-025-00616-z)

- U.S. Data Center Demand: U.S. data centers used 176 TWh (4.4% of national electricity) in 2023, with AI workloads driving a significant portion. By 2027, AI data centers alone could require 68 GW globally, nearly matching California’s 2022 total power capacity of 86 GW.[](https://www.rand.org/pubs/research_reports/RRA3572-1.html)[](https://energy.mit.edu/news/the-multi-faceted-challenge-of-powering-ai/)

## Future Energy Needs (2025-2035)

### Projections

The energy demands of AI are expected to grow exponentially due to increasing model complexity, widespread adoption, and the shift toward AI “agents” that perform tasks autonomously. Key projections include:

![Alt text](https://rishijeet.github.io/images/2025/Screenshot%202025-07-26%20at%208.43.39%E2%80%AFPM.png)

- By 2027:

Global Demand: AI data centers could require 68 GW of power, doubling global data center power requirements from 2022. Training runs for advanced models may demand up to 1 GW per location, with inference needs growing as AI agents handle billions of daily queries.[](https://www.rand.org/pubs/research_reports/RRA3572-1.html)

- U.S. Demand: Goldman Sachs Research forecasts a 50% increase in data center power demand by 2027, with AI contributing 27% of the total (up from 14% in 2023). This translates to 84 GW globally, with the U.S. accounting for a significant share.[](https://www.goldmansachs.com/insights/articles/ai-to-drive-165-increase-in-data-center-power-demand-by-2030)

- Eric Schmidt’s Estimate: Schmidt’s claim of an additional 92 GW needed in the U.S. aligns with projections for AI-driven demand, equivalent to powering four to five projects on the scale of OpenAI’s Stargate (15-25 GW).[](https://www.cfr.org/blog/america-may-not-need-massive-energy-build-out-power-ai-revolution)

- By 2030:

Global Demand: The International Energy Agency (IEA) projects global data center electricity demand to reach 945 TWh (slightly more than Japan’s current consumption), with AI-optimized data centers quadrupling in power needs.[](https://www.iea.org/news/ai-is-set-to-drive-surging-electricity-demand-from-data-centres-while-offering-the-potential-to-transform-how-the-energy-sector-works)

- U.S. Demand: U.S. data centers are expected to account for nearly half of the growth in national electricity demand, rising from 3-4% of total power in 2023 to 11-12% by 2030. This could require an additional 50 GW of capacity, with investments exceeding $500 billion in data center infrastructure alone (excluding grid upgrades).[](https://www.mckinsey.com/industries/private-capital/our-insights/how-data-centers-and-the-energy-sector-can-sate-ais-hunger-for-power)

- Training Needs: By 2030, training a single large AI model could demand up to 8 GW, equivalent to eight nuclear reactors, if current scaling trends continue.[](https://www.rand.org/pubs/research_reports/RRA3572-1.html)

- By 2035:

Global Demand: If AI adoption and computational growth continue at current rates (doubling every 100 days), data center power demand could grow 160-165% from 2023 levels, reaching 3-4% of global electricity.[](https://www.goldmansachs.com/insights/articles/ai-to-drive-165-increase-in-data-center-power-demand-by-2030)[](https://www.goldmansachs.com/insights/articles/AI-poised-to-drive-160-increase-in-power-demand)

- U.S. Demand: The U.S. could see data center power consumption triple, potentially requiring 100 GW of additional capacity, as suggested by Schmidt’s estimate and supported by Duke University’s analysis of existing grid “headroom.”[](https://www.cfr.org/blog/america-may-not-need-massive-energy-build-out-power-ai-revolution)

### Energy Bottlenecks

![Alt text](https://rishijeet.github.io/images/2025/Screenshot%202025-07-26%20at%208.46.11%E2%80%AFPM.png)

- Infrastructure Constraints: The U.S. power grid faces challenges in congestion, reliability, and transmission capacity. Current grid upgrades are insufficient to meet AI-driven demand, with new transmission line construction dropping from 4,000 miles in 2013 to 1,000 miles annually today.[](https://www.energypolicy.columbia.edu/projecting-the-electricity-demand-growth-of-generative-ai-large-language-models-in-the-us/)[](https://www.forbes.com/sites/arielcohen/2024/05/23/ai-is-pushing-the-world-towards-an-energy-crisis/)

- Energy Source Limitations: Renewable energy (solar, wind) is intermittent, requiring expensive storage solutions or backup gas/diesel generators, which conflict with zero-carbon goals. Nuclear power, while reliable, takes nearly a decade to scale, making it a medium-term solution.[](https://www.mckinsey.com/industries/private-capital/our-insights/how-data-centers-and-the-energy-sector-can-sate-ais-hunger-for-power)[](https://energy.mit.edu/news/the-multi-faceted-challenge-of-powering-ai/)

- Geographic Challenges: Data centers are concentrated in regions like Northern Virginia (consuming electricity equivalent to 800,000 homes), straining local grids and causing price hikes for residents.[](https://www.forbes.com/sites/arielcohen/2024/05/23/ai-is-pushing-the-world-towards-an-energy-crisis/)

## Shaping the Future Energy Landscape

### Strategies to Meet Demand

![Alt text](https://rishijeet.github.io/images/2025/Screenshot%202025-07-26%20at%208.46.26%E2%80%AFPM.png)

- Renewable Energy Investments: Companies like Microsoft, Google, and Amazon are investing heavily in renewables. Microsoft’s 10.5 GW deal and Google’s $75 billion AI infrastructure budget signal a shift toward carbon-free energy, though intermittency remains a challenge.[](https://www.energypolicy.columbia.edu/projecting-the-electricity-demand-growth-of-generative-ai-large-language-models-in-the-us/)[](https://www.technologyreview.com/2025/05/20/1116327/ai-energy-usage-climate-footprint-big-tech/)

- Nuclear Power Revival: Hyperscalers are turning to nuclear energy for reliable, high-capacity power. Microsoft’s Three Mile Island deal and Meta’s exploration of nuclear options in Louisiana highlight this trend. Small modular reactors and geothermal energy are also being evaluated.[](https://energy.mit.edu/news/the-multi-faceted-challenge-of-powering-ai/)[](https://www.rand.org/pubs/research_reports/RRA3572-1.html)

- Energy Efficiency: Innovations like Google’s 40% reduction in data center energy use through AI-driven cooling and more efficient chips (e.g., DeepSeek’s potential efficiency gains) could mitigate demand growth. Shared data centers and cloud computing can further reduce energy waste.[](https://www.weforum.org/stories/2024/04/how-to-manage-ais-energy-demand-today-tomorrow-and-in-the-future/)

- Grid Flexibility: Duke University’s report suggests that existing U.S. grid “headroom” could support 100 GW of new data center capacity if consumption is managed during peak hours. This requires data centers to adopt flexible load scheduling.[](https://www.cfr.org/blog/america-may-not-need-massive-energy-build-out-power-ai-revolution)

### Economic and Social Impacts

![Alt text](https://rishijeet.github.io/images/2025/Screenshot%202025-07-26%20at%208.46.38%E2%80%AFPM.png)

- Cost Increases: The $500 billion+ investment in data center infrastructure could lead to higher electricity bills for consumers, as utilities pass on grid upgrade costs. Meta’s Louisiana project, for instance, may raise rates after 15 years if gas turbines remain in use.[](https://www.technologyreview.com/2025/05/20/1116272/ai-natural-gas-data-centers-energy-power-plants/)

- Geopolitical Implications: If U.S. energy constraints persist, companies may build data centers abroad (e.g., Malaysia), risking national security and AI leadership. Schmidt’s emphasis on energy as a bottleneck underscores the need for domestic investment to maintain competitiveness.[](https://www.rand.org/pubs/research_reports/RRA3572-1.html)

- Environmental Concerns: AI’s energy demands could double data center carbon emissions by 2030, with a “social cost” of $125-140 billion unless mitigated by renewables or nuclear power. Natural gas plants, planned to meet immediate needs, could lock in emissions for decades.[](https://www.goldmansachs.com/insights/articles/ai-to-drive-165-increase-in-data-center-power-demand-by-2030)[](https://www.technologyreview.com/2025/05/20/1116272/ai-natural-gas-data-centers-energy-power-plants/)

### Policy and Innovation Needs

- Government Action: President Biden’s Executive Order (January 2025) aims to accelerate AI infrastructure development by leasing federal lands for gigawatt-scale data centers powered by clean energy. The Defense Production Act could address energy shortfalls.[](https://rpower1.com/articles/the-power-of-ai-building-the-energy-infrastructure-for-americas-ai-revolution/)

- Infrastructure Upgrades: Over $800 billion in transmission and distribution investments are needed in Europe alone, with similar needs in the U.S. to support AI growth.[](https://www.goldmansachs.com/insights/articles/AI-poised-to-drive-160-increase-in-power-demand)

- Transparency: Researchers and the IEA call for greater transparency from AI companies on energy consumption to improve planning and mitigate environmental impacts.[](https://www.nature.com/articles/d41586-025-00616-z)[](https://www.iea.org/news/ai-is-set-to-drive-surging-electricity-demand-from-data-centres-while-offering-the-potential-to-transform-how-the-energy-sector-works)

## Critical Analysis

- Schmidt’s 92 GW Estimate: While ambitious, Schmidt’s projection aligns with estimates like RAND’s 68 GW by 2027 and Goldman Sachs’ 100 GW by 2030, though it assumes aggressive AI adoption. Duke University’s claim of existing grid capacity suggests this demand could be met without massive new infrastructure, but only with significant flexibility in data center operations.[](https://www.cfr.org/blog/america-may-not-need-massive-energy-build-out-power-ai-revolution)[](https://www.rand.org/pubs/research_reports/RRA3572-1.html)[](https://www.goldmansachs.com/insights/articles/ai-to-drive-165-increase-in-data-center-power-demand-by-2030)

- Uncertainties: Estimates vary widely due to unpredictable AI efficiency gains (e.g., DeepSeek’s potential), adoption rates, and infrastructure development timelines. Overbuilding natural gas plants risks stranded assets if AI demand slows.[](https://www.technologyreview.com/2025/05/20/1116272/ai-natural-gas-data-centers-energy-power-plants/)

- Environmental Trade-offs: The reliance on natural gas to meet immediate needs conflicts with zero-carbon goals, potentially locking in emissions for decades. Nuclear and renewable solutions are promising but face scalability and cost challenges.[](https://www.technologyreview.com/2025/05/20/1116272/ai-natural-gas-data-centers-energy-power-plants/)[](https://energy.mit.edu/news/the-multi-faceted-challenge-of-powering-ai/)

- Data Gaps: Lack of transparency from companies like OpenAI hinders accurate forecasting. More granular data on training and inference energy use is needed to refine projections.[](https://www.technologyreview.com/2025/05/20/1116327/ai-energy-usage-climate-footprint-big-tech/)

## Conclusion

The AI revolution, driven by hyperscalers like Microsoft, Google, Meta, Amazon, and OpenAI, is pushing energy demands to unprecedented levels, with current U.S. data center consumption at 4.4% of national electricity and projected to reach 11-12% by 2030. Schmidt’s estimate of an additional 92 GW by 2035 underscores the scale of the challenge, requiring investments in renewables, nuclear power, and grid upgrades. While innovations in efficiency and flexible grid management offer hope, the risk of cost increases, environmental impacts, and geopolitical shifts looms large. To maintain AI leadership and sustainability, the U.S. must prioritize energy infrastructure development, transparency, and strategic policy interventions to balance growth with environmental and economic stability.
